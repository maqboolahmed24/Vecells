# Shared Operating Contract For Prompts 164 To 171

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-163`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch has two responsibilities:
1. finish Phase 1 by integrating the real intake backend and the real patient shell, then run the hard verification, accessibility, performance, resilience, and exit-gate work needed to prove the Red Flag Gate is genuinely complete; and
2. begin Phase 2 by freezing the shared trust/capability kernel and the NHS login plus local-session contract that later identity and telephony implementation tracks must obey.

Tasks in this batch:
- `164`: integrate the full Phase 1 intake backend, patient shell, and notification worker
- `165`: run the Phase 1 red-flag decision-table and malicious-upload suites
- `166`: run the Phase 1 duplicate-submit, refresh, replay, and collision-review suites
- `167`: run the Phase 1 end-to-end channel and accessibility regression suites
- `168`: run the Phase 1 submission-burst performance and resilience suites
- `169`: issue the evidence-driven Phase 1 exit-gate verdict
- `170`: freeze the Phase 2 trust contract, capability gates, and identity-authority rules
- `171`: freeze the Phase 2 NHS login auth-transaction and local-session contracts

Before executing any task in this batch, verify that the outputs from tasks `001-163` exist, remain internally coherent, and still bind to the canonical blueprint corpus. If a prerequisite artifact is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently repair the dependency chain with local invention.

At minimum, require these upstream outputs to remain usable:
- tasks `001-020`: scope, glossary, state atlas, dependency inventory, safety/privacy posture, ADRs, milestones, traceability, and Phase 0 entry criteria
- tasks `021-040`: provider assumptions, browser-automation onboarding, simulator-first integration strategy, and degraded defaults
- tasks `041-061`: repository topology, runtime/publication substrate, lifecycle law, trust-zone boundaries, release/freeze rules, and the Phase 0 parallel-gate baseline
- tasks `062-102`: canonical domain aggregates, governors, eventing, simulators, runtime infrastructure, release publication, backfill, recovery, and verification substrate
- tasks `103-120`: design tokens, UI contract kernel, shell law, accessibility contract, route guards, selected-anchor law, telemetry/automation vocabulary, and seeded shell surfaces
- tasks `121-138`: assurance packs, privacy/DPIA seed, Phase 0 verification suites, release candidate freeze, and Phase 0 exit-gate outputs
- tasks `139-145`: Phase 1 journey/schema lock, question-definition and taxonomy contracts, attachment/quarantine rules, urgent-diversion rulebook, the Phase 1 parallel gate, autosave backend, and submit-readiness validation
- tasks `146-154`: attachment pipeline, contact-preference backend, immutable promotion, normalization, synchronous safety, urgent/receipt grammar, ETA/minimal status truth, notification dispatch, and promoted-draft supersession
- tasks `155-163`: patient intake mission frame, progressive questions, quiet autosave, file-upload states, contact editor, urgent diversion surface, routine receipt surface, minimal tracking, and sign-in/resume postures

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim/sequence discipline
- `prompt/checklist.md` for canonical task ordering and gate discipline
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for this repo

Authoritative source order:
1. `phase-1-the-red-flag-gate.md` for tasks `164-169`, especially `## 1B`, `## 1C`, `## 1D`, `## 1E`, `## 1F`, and `## 1G`
2. `phase-2-identity-and-echoes.md` for tasks `170-171`, especially `## 2A` and `## 2B`
3. `phase-0-the-foundation-protocol.md`, especially canonical lifecycle, replay, duplicate, safety, access-grant, route-intent, identity-binding, session, patient-receipt, and patient-recovery objects and algorithms
4. `platform-frontend-blueprint.md`, `patient-portal-experience-architecture-blueprint.md`, and `patient-account-and-communications-blueprint.md` for same-shell continuity, status-strip law, selected-anchor preservation, macro-state mapping, secure-link/auth return, patient degraded-mode authority, communications/receipt semantics, and recovery posture
5. `platform-runtime-and-release-blueprint.md` for runtime-publication bundles, release parity, route freeze, recovery disposition, and fail-closed writable posture
6. `phase-cards.md` for the programme-level Phase 1 and Phase 2 scope, algorithm, and mandatory tests
7. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `accessibility-and-content-system-contract.md`, and `uiux-skill.md` for exact visual, spacing, typography, accessibility, content, and automation law
8. outputs from tasks `139-163`, especially the Phase 1 freeze contracts and frontend/backend implementation prompts that this batch merges and verifies
9. `forensic-audit-findings.md` as mandatory patch law, especially Findings `06`, `10`, `11`, `25`, `50`, `53`, `55`, `59`, `61`, `62`, `64`, `82`, `85`, `86`, `87`, `88`, `89`, `97`, `99`, `101`, `105`, `116`, `117`, `118`, and `120`
10. `blueprint-init.md` and `vecells-complete-end-to-end-flow.md` / `.mmd` as top-level cross-phase references that must not override higher-authority files

Non-authoritative but required external references for refinement only:
- GOV.UK Design System guidance for one-question-per-page flows, check-answers, confirmation pages, and file-upload usability
- NHS digital service-manual guidance and W3C WCAG 2.2 success criteria for accessibility, focus visibility, target sizing, consistent help, redundant entry, and accessible authentication
- Playwright documentation for isolated browser contexts, user-visible locators, auto-waiting, accessibility testing, and ARIA snapshot regression
- NHS login documentation, OpenID Connect Core, RFC 7636 (PKCE), and the OAuth 2.0 Security BCP for Phase 2 auth/session hardening
These references refine UX, testing, and security posture. They never override the Vecells source algorithm.

Non-negotiable interpretation rules:
- The Phase 1 patient journey is one continuity-preserving shell. No task in `164-169` may replace it with detached confirmation pages, generic error pages, or route-local success islands for the same lineage.
- `SubmissionEnvelope` remains the only draft truth, `SubmissionPromotionRecord` remains the only exactly-once bridge into `Request`, and any replayed or refreshed submit must return the prior authoritative settlement chain rather than generating second writes or second notifications.
- `urgent_diversion_required` and `urgent_diverted` are separate durable truths. UI, events, and tests must preserve that distinction exactly.
- `Request.workflowState = triage_ready` is illegal until a real `TriageTask` exists.
- `PatientReceiptConsistencyEnvelope` is the shared public truth for receipt and minimal tracking. No route or shell in this batch may invent a separate ETA or state meaning.
- Notification `queued`, `provider accepted`, `delivery evidenced`, and `authoritative outcome` are distinct. Transport acceptance alone is never patient-reassuring truth.
- All browser-visible recovery, downgrade, secure-link, auth-return, or stale-token states must preserve the same anchor and last-safe summary where the source algorithm allows it. Recovery cannot silently discard context.
- Tasks `170-171` may not collapse authentication, patient linking, ownership claim, public/secure-link scope, capability, and local session into one step. They are distinct authorities with different evidence and failure modes.
- Only `IdentityBindingAuthority` may advance or supersede `IdentityBinding`. `CapabilityDecision`, `PatientLink`, `Session`, `PostAuthReturnIntent`, and `AccessGrant` consume that authority; they do not replace it.
- Unknown route profiles, stale binding fences, stale session epochs, stale grant envelopes, stale manifest/channel posture, or unclassified protected jobs must fail closed.
- OIDC and local-session logic must be isolated behind dedicated bridge/session layers. Do not scatter security-sensitive decisions through route handlers.
- For browser-visible work, use `Playwright_or_other_appropriate_tooling` from the start, prefer user-visible locators and accessibility semantics, use isolated browser contexts, avoid fixed sleeps, and publish deterministic `data-testid` markers only where user-facing semantics are insufficient.
- Any chart, heatmap, diagram, or visual proof artifact must include adjacent table/list parity and must fail closed to the tabular surface when parity drifts.

Backend quality law for this batch:
- explicit domain/application/infrastructure separation
- append-only authoritative records instead of mutable status shortcuts
- deterministic idempotency, compare-and-swap or fence checks where lineage integrity matters, and replay-safe command handling
- PHI, identity evidence, and contact values must never leak into logs, metrics labels, DOM attributes, URLs, screenshots, or telemetry payloads
- external I/O must stay behind simulator-replaceable interfaces
- reason codes must be machine-readable for blocked, degraded, replayed, denied, stale, and recovery-required states
- fail closed on stale publication, stale trust, stale continuity evidence, or stale delivery truth

Frontend and browser-surface quality law for this batch:
- preserve the `Quiet_Clarity_Intake` visual language from tasks `155-163`
- keep one dominant action and bounded helper text
- no dashboard sprawl, celebratory success chrome, toast storms, banner stacks, or decorative charts
- mobile first, keyboard complete, reduced-motion correct, and sticky controls unobscuring focused inputs or live regions
- any verification lab, review board, or atlas must feel premium, exact, and product-native rather than like a default test runner skin

Gap handling:
- If a prerequisite artifact is missing or contradictory, emit `PREREQUISITE_GAP_*` and stop the affected task.
- If the source algorithm leaves a merge, testing, or contract seam under-specified, resolve it now as a bounded, source-traceable contract family and record `GAP_RESOLVED_*`.
- If performance, resilience, or auth/security budgets are not explicit, derive the smallest defensible bounded budget set, record `GAP_RESOLVED_*_BUDGET_*`, and keep the assumptions machine-readable.
- Keep `Mock_now_execution` and `Actual_production_strategy_later` separate. Mock-now means real product behavior backed by contract-faithful simulators. Actual-production strategy means later live-provider/auth/channel hardening that preserves the same public semantics.

Output discipline:
- Create or update real repository artifacts, validators, tests, and browser-visible evidence surfaces. Do not leave critical behavior as TODO prose.
- Every task must publish machine-readable outputs that later gates can consume directly.
- Any browser-visible artifact must read from the same machine-readable truth that the tests and validators assert; do not hard-code “green” UI labels into HTML evidence boards.
```
