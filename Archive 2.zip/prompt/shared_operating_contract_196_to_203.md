# Shared Operating Contract For Prompts 196 To 203

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `188` to `195`. This batch turns the newly frozen Phase 2 identity, grant, session, telephony, and portal contracts into the actual patient-facing portal experience, then closes the loop with gated browser-automation prompts for external NHS login and provider-console configuration.

The tasks covered here are:

- `196_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_authenticated_patient_home_and_status_tracker_uplift`
- `197_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_request_claim_resume_and_identity_hold_postures`
- `198_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_mobile_sms_continuation_flow_for_callers`
- `199_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_signed_in_request_creation_and_saved_context_restore`
- `200_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_contact_claim_visibility_and_preference_separation_ui`
- `201_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_cross_channel_receipt_and_status_parity_surfaces`
- `202_seq_phase2_use_Playwright_or_other_appropriate_tooling_browser_automation_to_configure_nhs_login_redirects_scopes_and_test_users`
- `203_seq_phase2_use_Playwright_or_other_appropriate_tooling_browser_automation_to_configure_telephony_sms_and_email_webhook_settings`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `195` as the guaranteed completed foundation for this batch.

You must assume the following earlier work is authoritative and available:

- Phase 1 canonical intake contracts and premium shell outputs from `140`, `144`, `147`, `154`, `155`, `156`, `157`, `158`, `159`, `160`, `161`, `162`, and `163`
- Phase 2 auth, trust, identity, claim, and portal-projection outputs from `170`, `171`, `172`, `174`, `175`, `176`, `177`, `178`, `179`, `180`, `181`, `182`, `183`, `184`, and `185`
- Phase 2 audit and telephony execution outputs from `186`, `187`, `188`, `189`, `190`, `191`, `192`, `193`, `194`, and `195`

Tasks `196` to `201` are the active parallel frontend block inside this batch. Do not assume a sibling prompt from that same block has already been executed unless its outputs are physically present and coherent in the repository.

If a sibling task output from this batch is absent, stale, or contradictory, do not block. Publish the smallest correct seam, adapter, or temporary contract and record a machine-readable artifact named:

- `PARALLEL_INTERFACE_GAP_PHASE2_<AREA>.json`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, and `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth. External guidance refines implementation quality, accessibility, provider hardening, and test technique, but it must never override the local model.

Use this priority order:

1. `blueprint/phase-2-identity-and-echoes.md`
2. `blueprint/patient-account-and-communications-blueprint.md`
3. `blueprint/patient-portal-experience-architecture-blueprint.md`
4. `blueprint/phase-0-the-foundation-protocol.md`
5. `blueprint/platform-frontend-blueprint.md`
6. `blueprint/phase-cards.md`
7. `blueprint/callback-and-clinician-messaging-loop.md`
8. `blueprint/accessibility-and-content-system-contract.md`
9. `blueprint/design-token-foundation.md`
10. `blueprint/canonical-ui-contract-kernel.md`
11. `blueprint/forensic-audit-findings.md`
12. Prompt outputs from `170` to `195`
13. Prompt outputs from `196` to `201` when present and internally coherent

## 3. Mandatory interpretation laws for this batch

### 3.1 The authenticated portal is projection-driven, not page-driven

The patient shell may not infer status, visibility, writable posture, callback readiness, receipt semantics, or recovery state from route names, cached payload fragments, or local optimistic assumptions.

Patient-facing home, request list, request detail, recovery, and contact surfaces must resolve through the published projection families, especially:

- `PatientPortalEntryProjection`
- `PatientHomeProjection`
- `PatientSpotlightDecisionProjection`
- `PatientPortalNavigationProjection`
- `PatientRequestsIndexProjection`
- `PatientRequestDetailProjection`
- `PatientAudienceCoverageProjection`
- `PatientActionRecoveryProjection`
- `PatientIdentityHoldProjection`
- `PatientReachabilitySummaryProjection`
- `PatientContactRepairProjection`
- `PatientSecureLinkSessionProjection`

### 3.2 Same shell, same lineage, same recovery law still applies

Claim, resume, sign-in uplift, secure-link continuation, stale-link recovery, rebind, reachability repair, and session-expiry recovery are not permission to throw the patient into a generic landing page.

When the same request lineage and continuity key are still current, the UI must preserve:

- the same `PersistentShell`
- the same `PatientNavReturnContract`
- the same `PatientRequestReturnBundle` where applicable
- the selected anchor or last-safe summary when lawful
- one bounded next-safe action instead of detached navigation

### 3.3 Signed-in request creation reuses the same Phase 1 intake path

There is one canonical intake model.

Signed-in start-request, continue-draft, SMS continuation, support-assisted continuation, and authenticated resume must all converge on the same:

- `SubmissionEnvelope`
- question-definition and intake bundle contracts
- upload semantics
- autosave semantics
- submission promotion rules
- receipt and status semantics

Do not create a second authenticated intake schema, a second draft shell, or a second request creation API just because the user is signed in.

### 3.4 Keep the three patient-contact truths separate

You must preserve the explicit local rule that these are not interchangeable:

- NHS login contact claims
- patient-chosen Vecells communication preferences
- PDS or GP demographic contact rows when enabled

The UI may compare, explain, or reconcile them, but it must never silently merge them, imply that editing one automatically updates the others, or use stale data from one source to mask problems in another.

### 3.5 Seeded telephony continuation is privileged and tightly bounded

For mobile continuation surfaces:

- `continuation_seeded_verified` may reveal previously captured context only after seeded eligibility is already settled and the bound handset is verified
- `continuation_challenge` may reveal no pre-existing patient data before challenge success
- `manual_only` is a routing outcome, not a redeemable patient surface
- step-up, rebind, stale-link recovery, and sign-in uplift must preserve the same mobile shell when the same lineage remains valid

### 3.6 Home is not a dashboard playground

The patient-account blueprint is explicit: the live signed-in home is a quiet, governed surface.

Do not place charts, meters, carousel rotations, or dense admin-dashboard widgets on the actual patient home.

Use diagrams, matrices, and charts only in supporting atlas, gallery, or control-board artifacts under `docs/frontend/`, never as a substitute for the production patient shell.

### 3.7 Cross-channel parity is semantic, not cosmetic drift

Web, authenticated, phone, SMS continuation, embedded, and recovery entry points may vary in context, but they must resolve through the same canonical receipt, ETA bucket, promise state, recovery posture, and request-status truth.

Helpful provenance notes are allowed.
Channel-specific semantics drift is not.

### 3.8 External configuration tasks are mock-first and gated-live

Tasks `202` and `203` must produce executable local configuration twins, dry-run manifests, validation tooling, and Playwright automation now.

Real console mutation is only allowed when all required credentials, approvals, and explicit live-mutation flags are present. Without them, the task must still complete through dry-run simulation, selector capture, redacted evidence, and typed manifests.

### 3.9 Provider configuration stops at the edge

External provider consoles may only target the typed edge endpoints and signed callback handlers that were frozen earlier.

Do not register internal worker URLs, queue consumers, private admin routes, or non-edge endpoints in NHS login, telephony, SMS, or email provider consoles.

### 3.10 Playwright is mandatory in this batch

Use Playwright from the beginning for:

- all patient-facing frontend tasks in `196` to `201`
- all browser-automation configuration tasks in `202` and `203`
- any HTML atlas, gallery, control board, or diagnostic surface

Other tooling may supplement it, but Playwright is the primary proof mechanism.

## 4. External guidance that may refine implementation

Use official sources to strengthen implementation quality, not to replace the blueprint.

### 4.1 NHS login and NHS App guidance

Respect current official guidance for:

- the standard NHS login button and branding posture
- requesting only the data needed for the transaction
- mock authorisation and test-user flows
- redirect URI strategy and `state` usage
- partner responsibility for local session management and logout
- responsive-web expectations for NHS App integration
- separation between NHS login contact claims and PDS or GP contact data

### 4.2 GOV.UK and NHS service patterns

Use current official service guidance for:

- one-question-per-page or one-decision-per-step patient flows
- preserving entered values after validation
- check-answers posture for short and medium transactional journeys
- confirmation pages that say what happens next
- plain-language error and recovery content

### 4.3 WCAG 2.2 and semantic accessibility

All patient and operator-facing surfaces in this batch must explicitly cover:

- focus not obscured
- target size minimum
- redundant entry avoidance where appropriate
- accessible authentication expectations
- keyboard-only usage
- reduced-motion support
- role, name, value, and live-region correctness

### 4.4 Playwright guidance

Use current Playwright practices for:

- role-based locators
- screenshot assertions where appropriate
- ARIA snapshot or equivalent semantic assertions
- accessibility scanning and deterministic automation anchors

### 4.5 OAuth, OIDC, and security guidance

For auth and configuration tasks, follow current best practice for:

- authorization-code flow hardening
- PKCE
- nonce and state binding
- replay resistance
- redirect safety
- deny-by-default authorization
- strict session and logging hygiene

### 4.6 Telephony, SMS, and email provider guidance

For provider-console tasks, follow current official provider guidance for:

- webhook signature validation
- replay protection
- recording or call-status callbacks where relevant
- telephony gather or IVR callback posture where relevant
- email event webhook signature or public-key verification where relevant

## 5. Delivery format rules

Every prompt in this batch must produce all of the following:

1. production-shaped code, not pseudocode
2. contract-first schema or interface artifacts for each new durable object or external seam
3. task-specific architecture, frontend, security, and operations docs
4. machine-readable analysis artifacts for matrices, parity tables, and edge cases
5. unit, integration, replay, and browser tests where applicable
6. explicit reason codes and deterministic failure states
7. no placeholder TODOs, no silent fallback logic, and no generic `catch and continue` behavior on critical posture transitions

If a task includes a visual artifact, it must also include:

- an HTML artifact under `docs/frontend/`
- keyboard-accessible interaction design
- reduced-motion support
- adjacent table or list parity for every diagram, matrix, or chart
- Playwright assertions for both behavior and visual-state parity when interactive

## 6. Cross-task invariants

All tasks in this batch must preserve the following invariants.

- The same `PersistentShell` and same-lineage recovery principle from Phase 0 and Phase 1 still applies.
- No patient-visible state may reveal more detail than the current `PatientAudienceCoverageProjection` allows.
- No authenticated state may be treated as permission for full detail by default.
- No PHI-bearing or writable state may appear while `PatientIdentityHoldProjection`, `PatientDegradedModeProjection`, current release posture, or current route-intent posture says otherwise.
- No stale public, continuation, or claim grant may revive writable state after supersession.
- No patient-visible action may survive stale `sessionEpoch`, stale `subjectBindingVersion`, stale `manifestVersionRef`, stale `RouteIntentBinding`, or stale `lineageFenceEpoch`.
- No receipt, status chip, request row, or detail header may contradict the canonical `PatientReceiptConsistencyEnvelope`, `PatientReceiptEnvelope`, or authoritative request-status projection.
- No contact blocker may stay hidden in secondary disclosure when it blocks the current patient path.
- No raw tokens, secrets, webhook bodies, callback signatures, full phone numbers, or full patient identifiers may appear in logs, screenshots, HTML, query strings, or exported artifacts.

## 7. Required implementation style

Prefer:

- projection-first composition over controller-local trimming
- typed state models over boolean soups
- same-shell morphs over route resets
- compare-and-set or append-only settlement over optimistic overwrite
- quiet visual hierarchy over dashboard clutter
- one dominant action per governed region
- visible provenance and bounded disclosure over hidden inference
- deterministic test anchors over brittle DOM text matching

## 8. Gap-resolution artifacts

When the blueprint implies a necessary policy table, timeout, recovery code, or UI copy family but does not fully name it, introduce the smallest source-faithful artifact and record it as:

- `GAP_RESOLVED_PHASE2_<AREA>_<TOPIC>.json`

Every gap-resolution artifact must include:
`taskId`, `sourceAmbiguity`, `decisionTaken`, `whyThisFitsTheBlueprint`, `operationalRisk`, and `followUpIfPolicyChanges`.

## 9. What “done” means for this batch

A task in this batch is complete only when:

- the implementation follows the local blueprint literally where the blueprint is explicit
- all new contracts are versioned and machine-readable
- frontend behavior is proven with Playwright where required
- replay, refresh, duplicate, stale-link, and cross-device cases are covered by tests
- any missing sibling surface is explicitly bridged through a published seam or gap artifact
- later tasks can consume the outputs without inventing new semantics
