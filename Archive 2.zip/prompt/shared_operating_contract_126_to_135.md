# Shared Operating Contract For Prompts 126 To 135

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-125`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch closes the Phase 0 foundation runway. It finishes the remaining assurance foundation (`126`), then sequentially fuses the already-built domain kernel, runtime-publication spine, shell contracts, simulator estate, release tuple, exit demonstration, and first mandatory Phase 0 verification suites (`127-135`).

Tasks in this batch:
- `126`: privacy threat model and DPIA backlog
- `127`: `Playwright_or_other_appropriate_tooling` integrate domain kernel, runtime-publication, and shell manifests
- `128`: seed synthetic reference flow through gateway, command API, and projection worker
- `129`: validate adapter simulators and seeded external contracts
- `130`: `Playwright_or_other_appropriate_tooling` finalize audience-surface runtime bindings and publication parity
- `131`: finalize release-candidate freeze and environment-compatibility evidence
- `132`: finalize Phase 0 exit artifacts and happy/unhappy-path demonstration
- `133`: `Playwright_or_other_appropriate_tooling` run domain-transition and event-schema compatibility suites
- `134`: `Playwright_or_other_appropriate_tooling` run route-intent, projection-freshness, and scoped-mutation-gate suites
- `135`: `Playwright_or_other_appropriate_tooling` run adapter-replay, duplicate-cluster, quarantine, and fallback-review suites

Before executing any task in this batch, verify that the outputs from tasks `001-125` exist, remain internally coherent, and are still source-traceable. If a prerequisite output is missing, stale, contradictory, or no longer binds to the canonical blueprint corpus, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently re-invent earlier work and pretend the dependency chain is intact.

At minimum, require these upstream outputs to remain usable:
- tasks `001-005`: requirement registry, summary reconciliation, scope boundary, personas/channels/surfaces, and request-lineage model
- tasks `006-010`: glossary, state atlas, dependency inventory, safety/privacy posture, and data-classification posture
- tasks `011-020`: platform baselines, ADRs, milestones, risks, traceability, and the Phase 0 entry gate
- tasks `021-040`: external-dependency inventory, provider strategies, simulator-first posture, onboarding checkpoints, degraded defaults, and external-contract assumptions
- tasks `041-055`: repository topology, scaffolded apps/services/packages, runtime topology, trust boundaries, event namespace, FHIR strategy, frontend-manifest strategy, release/publication parity strategy, design-publication strategy, WORM audit posture, acting-scope tuple, and lifecycle/closure law
- tasks `056-061`: scoped-mutation law, route-intent law, adapter profile law, verification ladder, simulator strategy, backup/restore tuple, and the Phase 0 parallel gate
- tasks `062-075`: canonical aggregates, identity/access/duplicate/lease/settlement/queue/reservation/freeze-trust foundations and orchestrators
- tasks `076-095`: closure, access authority, safety/evidence orchestration, deterministic rebuilds, simulator backplanes, runtime foundations, gateway surfaces, CI/CD, observability, publication bundle, and backfill runners
- tasks `096-105`: client cache/live-channel law, watch tuples, degradation execution, topology publication checks, SBOM/signature verification, backup/restore baseline, canary harness, design tokens, canonical UI kernel, and shared primitives
- tasks `106-115`: persistent shell framework, shell-truth components, selected-anchor law, artifact shell, posture library, accessibility harness, route guards, frontend manifest validation, automation/telemetry vocabulary, and patient shell seed routes
- tasks `116-125`: staff/ops/hub/governance/pharmacy shell seeds, DCB0129 seed pack, DSPT evidence plan, IM1 readiness pack, NHS login onboarding evidence pack, and clinical-risk review cadence/signoff matrix

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim and sequencing protocol
- `prompt/checklist.md` for canonical task ordering
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for the repo

Authoritative source order:
1. `phase-0-the-foundation-protocol.md` for canonical objects, state axes, lifecycle ownership, closure-blocker law, route-intent law, command-settlement law, evidence and replay law, runtime-publication law, release-freeze law, recovery law, privacy and masking rules, simulator-facing adapter rules, and verification requirements.
2. `platform-runtime-and-release-blueprint.md` for `FrontendContractManifest`, `RuntimePublicationBundle`, `ReleasePublicationParityRecord`, `AudienceSurfaceRuntimeBinding`, `ReleaseRecoveryDisposition`, release-contract verification, environment-ring proof, preview/recovery posture, and runtime/publication fail-closed semantics.
3. `platform-frontend-blueprint.md` for shell topology, `PersistentShell`, `CasePulse`, `ProjectionFreshnessEnvelope`, `SelectedAnchor`, `FrontendContractManifest`, UI telemetry disclosure, route/runtime binding behavior, and browser-verification law.
4. `phase-cards.md` for the canonical Phase 0 algorithm, synthetic-flow expectation, unhappy-path proof obligations, release-candidate freeze tuple, and the list of mandatory tests that must pass before Phase 0 completion.
5. `blueprint-init.md` for programme-wide scope and current baseline assumptions, especially simulator-first delivery, route/publication truth, support and privacy boundaries, and assistive/privacy/DPIA posture.
6. Domain-specific and assurance sources as required by the current task, including:
   - `phase-1-the-red-flag-gate.md`
   - `phase-2-identity-and-echoes.md`
   - `patient-portal-experience-architecture-blueprint.md`
   - `patient-account-and-communications-blueprint.md`
   - `staff-operations-and-support-blueprint.md`
   - `operations-console-frontend-blueprint.md`
   - `governance-admin-console-frontend-blueprint.md`
   - `phase-8-the-assistive-layer.md`
   - `phase-9-the-assurance-ledger.md`
7. `forensic-audit-findings.md` as mandatory patch law for privacy drift, stale writable posture, duplicate-review visibility, fallback review, publication parity, shell trust envelopes, and missing unhappy-path proof.
8. `vecells-complete-end-to-end-flow.md` and `.mmd` as audited cross-phase flow references that must not override higher-authority source files.

Non-negotiable interpretation rules:
- This batch is an integration-and-proof batch, not a fresh greenfield design batch. Reuse and fuse the artifacts already published by earlier tasks. Do not fork contract names, schema owners, shell laws, or release laws.
- Keep `Mock_now_execution` separate from `Actual_production_strategy_later` whenever the task touches simulators, onboarding, provider dependencies, or release evidence. Mock-now means typed simulators, seeded contracts, and locally provable evidence that is honest about being non-production. Actual-production strategy means the later live-provider or live-release path that must preserve the same contract names and tuple structure.
- No route, shell, dashboard, test, or demo may infer writable or calm posture from transport health, local cache, seed data, or compiled frontend code. Current `AudienceSurfaceRuntimeBinding`, `RuntimePublicationBundle`, `ReleasePublicationParityRecord`, `ReleaseApprovalFreeze`, and relevant trust/freeze verdicts are the only authorities.
- All unhappy-path invariants named by the blueprint must stay visible in this batch: duplicate replay, collision review, quarantine, fallback review, repair hold, stale publication, recovery-only posture, and confirmation-blocked truth are first-class proof obligations, not edge notes.
- `LifecycleCoordinator` remains the only authority that derives canonical closure and milestone completion. Synthetic flows, demos, and tests may open blockers, holds, or child-case truth, but they may not let downstream code close the request directly.
- Privacy, minimum necessary, acting scope, break-glass, and disclosure-fence rules are not documentation garnish. This batch must encode them into machine-readable rows, validation logic, runtime bindings, and tests.
- Any browser-viewable artifact produced in this batch must consume the published token graph, profile-resolution law, and quiet-clarity interaction semantics from earlier Phase 0 prompts. Do not introduce one-off CSS, generic admin dashboards, decorative gradients, or chart-heavy noise.
- Every diagram, heatmap, or timeline must have adjacent table/list parity. Visual proof without accessible text/tabular parity is invalid.
- Use `Playwright_or_other_appropriate_tooling` from the start for any browser-viewable artifact and for any shell- or route-sensitive proof path. All such artifacts must have stable `data-testid` markers, keyboard support, reduced-motion coverage, and deterministic scenario fixtures.

Frontend and experience quality law for any UI or browser-viewable artifact in this batch:
- visual language: `Signal Atlas Live` with the `Quiet Clarity` overlay
- tone: premium, calm, exact, low-noise, analytical, and clearly product-native
- avoid: commodity dashboard kits, giant KPI tiles, loud status colors, marketing gradients, or decorative motion
- typography, spacing, density, radius, and motion must come from the canonical token graph from tasks `103-105`
- if a fallback hex seed is needed for fast local rendering, it must align to the published token seeds from task `103` and be documented as a bounded local mirror rather than a new token system
- every UI surface must explain its tuple or proof basis visibly: route/shell/runtime/release/trust/source scenario metadata must be inspectable in-product

Testing law:
- prefer deterministic seeded fixtures over random integration state
- use schema- and snapshot-based contract verification where the blueprint names immutable bundles or parity digests
- include negative-path tests for stale, superseded, conflicting, and blocked states rather than only nominal success
- when a UI artifact visualizes proof, the underlying proof data must also be available as machine-readable JSON/CSV and as accessible table text

Delivery law:
- create or update code, docs, data artifacts, and validation helpers together
- deterministic order and stable identifiers are mandatory
- every generated artifact must include traceability to source file + heading/logical block + upstream task ref where applicable
```