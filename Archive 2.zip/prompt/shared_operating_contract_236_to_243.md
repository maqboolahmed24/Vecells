# Shared Operating Contract For Prompts 236 To 243

These prompts continue the established roadmap immediately after `228` to `235`.

All work in this batch is backend-first Phase 3 implementation work.
Do **not** waste task budget on decorative UI builds, fake browser flows, or speculative frontend polish.
If a task needs a small internal state diagram, sequence diagram, or admin-only review artifact for documentation, keep it support-grade and secondary to executable backend code.

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `235` as the intended completed foundation for this batch.

That foundation includes:

- Phase 0 lifecycle, idempotency, mutation-gating, evidence, safety, access-grant, audit, release, recovery, and continuity kernels
- Phase 1 intake, safety, duplicate, notification, continuity, and release work
- Phase 2 identity, auth, telephony, portal, support, patient-account, and cross-channel convergence work
- Phase 3 freeze packs `226` and `227`
- Phase 3 consequence and first-kernel packs `228` to `235`

### If `228` to `235` are logically required but physically absent

The archive you are working in may still contain empty prompt files for some upstream tasks even though the roadmap has already advanced past them.
Do not block on that mismatch.

Use this fallback order:

1. local algorithm files under `blueprint/`
2. any validated repository artifacts already implementing the same contracts
3. the expected outputs implied by prompts `226` to `235`

When an upstream artifact is missing, contradictory, empty, or only partly implemented, publish the smallest correct seam or reconstruction note in a machine-readable file named:

- `PARALLEL_INTERFACE_GAP_PHASE3_<AREA>.json`

Each such file must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, `followUpAction`.

Do not weaken safety, lease, or continuity rules just because an upstream document is missing.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may improve security posture, distributed-systems reliability, provider-boundary handling, and implementation detail, but they must never override the local model.

Use this priority order:

1. `blueprint/phase-3-the-human-checkpoint.md`
2. `blueprint/callback-and-clinician-messaging-loop.md`
3. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
4. `blueprint/staff-workspace-interface-architecture.md`
5. `blueprint/phase-0-the-foundation-protocol.md`
6. `blueprint/phase-2-identity-and-echoes.md`
7. `blueprint/phase-1-the-red-flag-gate.md`
8. `blueprint/patient-account-and-communications-blueprint.md`
9. `blueprint/patient-portal-experience-architecture-blueprint.md`
10. `blueprint/platform-runtime-and-release-blueprint.md`
11. `blueprint/forensic-audit-findings.md`
12. validated outputs from prompts `170` to `235` when present and internally coherent

## 3. Batch dependency map

### 3.1 `236` establishes the canonical more-info timer and reminder kernel

Task `236` owns:

- `MoreInfoCycle`
- `MoreInfoReplyWindowCheckpoint`
- `MoreInfoReminderSchedule`
- supersession of older cycles
- reminder suppression, expiry, quiet-hours handling, and callback-fallback entry conditions

Tasks `237` and `242` must consume that kernel rather than recomputing due windows locally.

### 3.2 `237` is the only accepted patient-reply assimilation and re-safety path

Task `237` owns:

- `MoreInfoResponseDisposition`
- accepted-versus-blocked reply routing
- `EvidenceAssimilationRecord`
- `MaterialDeltaAssessment`
- re-safety preemption
- supervisor churn-guard for repeated reopen loops

Tasks `238`, `239`, `240`, `241`, `242`, and `243` must treat materially new patient detail as going through `237` before routine consequence continues.

### 3.3 `238` is the live endpoint-decision fence

Task `238` owns executable `DecisionEpoch`, `EndpointDecisionBinding`, supersession, and preview-safe route fencing.
Tasks `239` and `240` must use those exact decision and epoch objects rather than creating endpoint-local substitutes.

### 3.4 `239` is the only approval and urgent-escalation kernel

Task `239` owns executable `ApprovalCheckpoint`, approval burden evaluation, urgent-contact attempts, and urgent outcome routing.
Tasks `240`, `241`, and `242` must consume those authoritative states rather than inferring approval or escalation from notes or queue badges.

### 3.5 `240` owns direct resolution and clean downstream seed generation

Task `240` turns a valid unsuperseded `DecisionEpoch` into:

- direct-resolution artifacts
- callback or message seeds
- `BookingIntent`
- `PharmacyIntent`
- summary-first outcome artifacts
- handoff-safe lineage links

Task `241` must reopen against those artifacts when later drift invalidates them.

### 3.6 `241` owns governed reopen and next-task launch leases

Task `241` owns:

- `TriageReopenRecord`
- reopen-from-resolved or reopen-from-handoff paths
- stale-owner recovery joins
- guarded `NextTaskLaunchLease`

Task `242` must bind calm completion and next-task posture to those leases rather than inventing queue-local readiness.

### 3.7 `242` owns authoritative completion calmness and continuity evidence

Task `242` owns:

- `TaskCompletionSettlementEnvelope`
- `WorkspaceContinuityEvidenceProjection`
- `OperatorHandoffFrame`
- continuity-backed next-task readiness

No local success toast, outbox enqueue, provider acknowledgement, or queue prefetch may replace that authority.

### 3.8 `243` owns the executable callback domain

Task `243` owns the live callback case implementation that later message/support tasks will build around:

- `CallbackCase`
- `CallbackIntentLease`
- `CallbackAttemptRecord`
- `CallbackExpectationEnvelope`
- `CallbackOutcomeEvidenceBundle`
- `CallbackResolutionGate`

Later tasks `244` to `248` must integrate with that domain rather than forking a second callback model.

## 4. Mandatory interpretation laws for this batch

### 4.1 `MoreInfoReplyWindowCheckpoint` is the sole timer truth

Patient due-state copy, staff due chips, reminder eligibility, expiry posture, late-review grace, secure-link recovery, and queue resumption must all derive from the current checkpoint.
Client clocks, link TTLs, cached task badges, or provider timestamps may not redefine actionability.

### 4.2 Cycle, schedule, disposition, and assimilation are different objects

Do not collapse:

- the existence of a more-info request
- the current reply window
- reminder orchestration
- the patient reply disposition
- evidence assimilation
- re-safety settlement

Each needs its own durable, replay-safe authority.

### 4.3 Materially new evidence preempts routine consequence

Any materially new patient reply, callback outcome, or clinically meaningful thread delta must settle evidence assimilation, material-delta assessment, classification, safety preemption, and updated `SafetyDecisionRecord` before routine consequence continues.

### 4.4 `DecisionEpoch` is the sole consequence fence

Endpoint selection, approval, escalation, direct resolution, callback creation, clinician-message creation, booking/pharmacy handoff seeds, and reopen invalidation must all bind one current unsuperseded `DecisionEpoch` or fail closed.

### 4.5 Approval, escalation, callback, and direct-resolution domains are peers

Do not flatten these domains into task booleans or timeline prose.
Each has its own lifecycle objects, leases, settlements, and recovery rules.

### 4.6 `LifecycleCoordinator` remains the only request-closure authority

No task-local worker, callback engine, approval service, or downstream handoff service may close the request directly.

### 4.7 Every mutation must present the live fence tuple

At minimum, mutating commands in this batch must validate the live tuple required for that action, including where applicable:

- `ownershipEpoch`
- `fencingToken`
- `LineageFence.currentEpoch`
- `safetyDecisionEpoch`
- current review or governing-object version
- current route/publication/trust tuple
- current queue-rank snapshot for next-task actions

### 4.8 Outbound effects must be transaction-safe and replay-safe

Whenever a mutation writes durable domain state **and** emits events, notifications, reminder jobs, handoff messages, or provider dispatches, use one transactional-outbox or equivalent single-source-of-truth pattern.
Never dual-write domain state and external side effects optimistically.

### 4.9 Provider callbacks are evidence inputs, not closure truth

Telephony or messaging provider status, AMD results, webhook deliveries, and transport acknowledgements may widen or settle transport posture, but they may not directly imply callback completion, message review, or request closure.
Everything must reconcile through the canonical adapter, evidence, and resolution objects.

### 4.10 Webhook security is mandatory

All provider callback endpoints must:

- terminate over HTTPS
- validate provider signatures with the official SDK or supported verification mechanism
- tolerate added parameters without breaking verification
- treat unsigned, invalid, stale, or ambiguous callbacks as fail-closed inputs

### 4.11 Logs and audit are separate concerns

Keep append-only domain audit for causal truth.
Keep operational/security logs for diagnostics.
Do not leak secrets, tokens, health data, contact details, raw transcripts, or session identifiers into logs when audit or masked references are sufficient.

### 4.12 Completion calmness is governed, not inferred

Quiet completion, next-task readiness, and operator reassurance may advance only from authoritative completion settlement plus current continuity evidence.
Local acknowledgement, queue refresh, warmed preview data, or external provider acceptance is not enough.

### 4.13 Browser automation is not the main evidence channel in this batch

These are backend tasks.
Primary proof must come from migrations, validators, unit tests, integration tests, concurrency tests, replay tests, and worker-failure tests.
If you create a tiny internal admin harness, do not let that replace backend verification.

## 5. Shared engineering requirements

### 5.1 Clock discipline

Use authoritative server time in UTC for persisted timestamps.
If quiet-hours, preferred callback windows, or patient-facing local times are needed, resolve the display timezone explicitly and persist the resolved policy context used for the calculation.

### 5.2 Idempotency and compare-and-set

Every externally triggerable mutating command in this batch must be idempotent.
Every worker retry, webhook replay, duplicate staff click, or duplicate patient submit must either reuse the existing authoritative record or fail closed without creating a second side effect.

### 5.3 Property and concurrency testing are mandatory

For every task in this batch, include property or state-machine tests and at least one concurrency or replay suite covering fence drift, stale owner, duplicate submit, or duplicate callback conditions.

### 5.4 Migrations must be forward-safe

Schema changes must be additive or carefully staged.
Do not require destructive migration steps to satisfy this batch.
If rollback is not straightforward, publish explicit rollback notes and compatibility guards.

### 5.5 Performance and worker safety

Schedulers, reminder workers, callback workers, and reconciliation workers must be restart-safe and horizontally safe.
No in-memory scheduler state may be the sole authority for reminder or callback truth.

## 6. External implementation posture that may improve the code but not override the algorithm

Use current best practice where helpful:

- deny-by-default authorization and permission validation on every request
- structured security logging with masking/redaction and verification under test
- transactional outbox for state-plus-event atomicity
- saga-style orchestration or equivalent compensating-flow discipline for downstream handoff seeds
- signed webhook verification and TLS hygiene
- provider status and AMD treated as evidence inputs rather than direct business truth

## 7. Batch done condition

This batch is complete only when tasks `236` to `243` collectively provide:

- one executable more-info kernel
- one executable re-safety return path
- one executable endpoint/epoch engine
- one executable approval and urgent-escalation kernel
- one executable direct-resolution and handoff-seed engine
- one executable reopen and next-task lease kernel
- one executable completion and continuity evidence kernel
- one executable callback domain

with repository code, migrations, validators, and tests—not just prose.
