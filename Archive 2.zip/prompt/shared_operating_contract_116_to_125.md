# Shared Operating Contract For Prompts 116 To 125

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-115`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch continues the active Phase 0 parallel block immediately after the patient shell seed. It has two tightly coupled responsibilities:
1. finish the remaining audience-shell seeds for Phase 0 by proving that staff, operations, hub, governance, and pharmacy shells can all run on the same continuity/runtime/publication law while remaining visually and operationally distinct
2. stand up the long-lead assurance substrate that later release, onboarding, and live-operations work will depend on

Tasks in this batch:
- `116`: `Playwright_or_other_appropriate_tooling` staff shell seed routes and mock projections
- `117`: `Playwright_or_other_appropriate_tooling` operations shell seed routes and mock projections
- `118`: `Playwright_or_other_appropriate_tooling` hub shell seed routes and mock projections
- `119`: `Playwright_or_other_appropriate_tooling` governance shell seed routes and mock projections
- `120`: `Playwright_or_other_appropriate_tooling` pharmacy shell seed routes and mock projections
- `121`: DCB0129 hazard-log and clinical-safety-case structure
- `122`: DSPT gap assessment and evidence plan
- `123`: IM1 prerequisite and SCAL readiness pack
- `124`: NHS login onboarding evidence pack
- `125`: clinical-risk review cadence and signoff matrix

Before executing any task in this batch, verify that the outputs from tasks `001-115` exist, remain internally coherent, and are still traceable to the canonical blueprint corpus. If a prerequisite output is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently regenerate earlier work and pretend the dependency chain is intact.

At minimum, require these upstream outputs to be present and usable:
- tasks `001-005`: requirement registry, summary reconciliation, scope boundary, persona/channel/surface inventory, request-lineage model
- tasks `006-010`: domain glossary, state/invariant atlas, dependency inventory, safety/privacy posture
- tasks `011-020`: cloud/runtime/frontend/tooling baselines, ADR set, milestones, risks, traceability, and the Phase 0 entry gate
- tasks `021-040`: external dependency strategies, provider scorecards, mock-versus-live provider strategy, simulator backlog, approval checkpoints, and degraded defaults
- tasks `041-055`: repository topology, scaffolded apps/services/packages, runtime topology, trust boundaries, event namespace, FHIR strategy, frontend-manifest strategy, release/publication parity, design publication, WORM audit, acting-scope model, lifecycle and closure law
- tasks `056-061`: scoped mutation gate, route-intent law, adapter profile law, verification ladder, seed/simulator strategy, backup/restore tuple, and the active parallel gate
- tasks `062-075`: submission/evidence/FHIR/API/identity/reachability/duplicate/lease/settlement/queue/reservation/freeze-trust primitives and orchestrators
- tasks `076-085`: lifecycle closure record, access-grant authority, evidence and safety orchestration, deterministic rebuilds, simulator backplanes, network and storage foundations
- tasks `086-095`: object storage and retention, eventing and cache baselines, secrets and KMS, gateway surfaces, CI/CD and preview environments, observability SDK, runtime publication bundle, migrations and projection backfill
- tasks `096-105`: client cache/live-channel law, watch tuples, dependency degradation execution, topology publication checks, SBOM/signature verification, backup/restore baseline, non-production canary, design-token foundation, canonical UI kernel, and shared primitives
- tasks `106-115`: persistent shells, shell-truth components, selected-anchor and return law, artifact shell, posture library, accessibility harness, route guards, frontend manifest validation, automation/telemetry vocabulary, and the patient shell seed routes

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim and sequencing protocol
- `prompt/checklist.md` for canonical task ordering
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for the repo

Authoritative source order:
1. `phase-0-the-foundation-protocol.md` for canonical objects, state axes, lifecycle ownership, continuity law, shell law, route-intent law, command-settlement law, projection/runtime/publication law, assurance/resilience law, and the staff/hub/support/operations experience algorithm.
2. `platform-frontend-blueprint.md` for shell topology, continuity key rules, `PersistentShell`, `CasePulse`, `DecisionDock`, `SelectedAnchor`, `RouteFamilyOwnershipClaim`, `FrontendContractManifest`, staff/hub/support/operations algorithms, artifact/visibility/recovery rules, and browser verification law.
3. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `uiux-skill.md`, and `accessibility-and-content-system-contract.md` for premium calm visual language, token law, surface semantics, typography, spacing, shell profiles, motion, accessibility, automation anchors, and chart/table parity law.
4. Staff and specialist shell blueprints where relevant:
   - `staff-workspace-interface-architecture.md`
   - `staff-operations-and-support-blueprint.md`
   - `operations-console-frontend-blueprint.md`
   - `governance-admin-console-frontend-blueprint.md`
   - `pharmacy-console-frontend-architecture.md`
   - `phase-5-the-network-horizon.md` for hub-shell route and projection semantics
5. Identity, booking, communications, and pharmacy phase files where seed-route semantics depend on them:
   - `phase-1-the-red-flag-gate.md`
   - `phase-2-identity-and-echoes.md`
   - `phase-3-the-human-checkpoint.md`
   - `phase-4-the-booking-engine.md`
   - `phase-5-the-network-horizon.md`
   - `phase-6-the-pharmacy-loop.md`
   - `callback-and-clinician-messaging-loop.md`
   - `self-care-content-and-admin-resolution-blueprint.md`
6. Assurance and standards sources inside the local blueprint:
   - `phase-cards.md`
   - `blueprint-init.md`
   - `phase-1-the-red-flag-gate.md`
   - `phase-2-identity-and-echoes.md`
   - `phase-8-the-assistive-layer.md`
   - `phase-9-the-assurance-ledger.md`
   - `platform-admin-and-config-blueprint.md`
7. `forensic-audit-findings.md` as mandatory patch law for continuity drift, stale writable posture, route/runtime/publication mismatches, evidence and signoff drift, and misleading UI calmness.
8. `vecells-complete-end-to-end-flow.md` and `.mmd` as audited cross-phase flow references that must not override higher-authority source files.

Non-negotiable interpretation rules:
- `shellType = staff` is not the same as `shellType = support`. Task `116` seeds the clinical/reviewer workspace shell only. Support is a separate shell family and stays out of scope here except for clearly bounded launch placeholders.
- `shellType = operations`, `shellType = hub`, `shellType = governance`, and `shellType = pharmacy` are distinct audience surfaces with distinct continuity frames, consistency projections, and runtime bindings. They may share primitives, but they may not collapse into one generic admin shell.
- Seed routes are not throwaway mockups. They must be real shells wired to the shared shell framework, runtime bindings, selected-anchor law, posture library, manifest validation, automation anchors, and accessibility harness.
- Same continuity key, same shell. Queue/task switches, child-route entry, degraded recovery, and deep-link re-entry must all preserve shell truth, selected-anchor truth, focus truth, and status truth unless a canonical invalidation rule requires bounded downgrade.
- `CasePulse`, the shared status strip rendered through `AmbientStateRibbon` plus `FreshnessChip`, one current `DecisionDock`, and the active `SelectedAnchor` must remain causally honest across all seed shells.
- `StatusStripAuthority`, `ProjectionFreshnessEnvelope`, `AudienceSurfaceRuntimeBinding`, `RuntimePublicationBundle`, `ReleaseApprovalFreeze`, `ChannelReleaseFreezeRecord`, and `AssuranceSliceTrustRecord` remain the only authorities for calm or writable posture. Local component state, cached green badges, transport success, or mock data cannot independently imply fresh or writable posture.
- Every seed shell must be visibly unique and premium, but all shells must still read as one governed product family. Avoid generic dashboard kits, flat commodity admin layouts, and card-wall sameness.
- Where a shell blueprint under-specifies copy, iconography, or layout detail, preserve the governing continuity/truth distinction first, then close the gap with bounded `GAP_RESOLUTION_*` records rather than inventing contradictory behavior.
- Assurance tasks are implementation work, not prose-only note taking. They must create machine-readable registers, traceability matrices, template artifacts, validation scripts, and deterministic evidence-assembly helpers.
- Assurance tasks must preserve one explicit separation between:
  - `Mock_now_execution`: the real scaffolding, seeded registers, placeholder evidence bundles, mock provider dossiers, and local simulator proofs required to unblock MVP engineering now
  - `Actual_production_strategy_later`: the versioned, external-assurance, and provider-onboarding path that will be followed when live onboarding becomes feasible
- Actual production strategy must version official framework assumptions. Do not hard-code one permanent SCAL, DSPT, DCB, or NHS login process snapshot into the repo without a standards-version field and explicit review date.
- No prompt in this batch may treat NHS login success as clinical authorization, IM1 as a guaranteed capability without pairing evidence, or mock provider evidence as if it were already accepted by NHS England or a GP supplier.
- No prompt in this batch may permit self-approval for safety-critical or release-critical signoff. Independent review and no-self-approval rules must be explicit wherever approval graphs or signoff matrices are created.

Frontend and experience quality law:
- visual language: `Signal Atlas Live` with the `Quiet Clarity` overlay
- default tone: premium, restrained, clinical, low-noise, spatially memorable
- no commodity “analytics dashboard” look
- create one subtle shell-specific monoline insignia per shell family; it must feel like a product identity marker, not a startup logo splash
- typography, spacing, radius, contrast, and motion must come from the canonical token graph
- use the canonical type roles: `display 40/48`, `headline 32/40`, `title 24/32`, `section 20/28`, `body 16/24`, `body.sm 14/20`, `label 12/16`
- use the shell profiles from `design-token-foundation.md`:
  - `profile.staff_workspace`
  - `profile.operations_console`
  - `profile.hub_desk`
  - `profile.governance_admin`
  - `profile.pharmacy_console`
- color must be expressed through semantic token families and the canonical tone ladder, not route-local hex values:
  - canvas and shell tones from neutral/graphite `98/96/92`
  - interactive panels from neutral `96/92/88`
  - info emphasis from `signal/info`
  - warnings from `caution/triage`
  - blockers from `critical/exception`
  - authoritative settled success only from `success/confirmation`
- use charts, diagrams, and mini-visualizations only when they carry real operational value and always pair them with textual summaries and table/list fallbacks
- `mission_stack` is the only legal narrow-screen fold; folding must preserve dominant action, selected anchor, and same-shell continuity
- motion must stay within canonical durations `120ms`, `180ms`, `240ms`, `320ms` and support reduced-motion equivalence

Assurance and architecture quality law:
- generate evidence structures that are deterministic, diffable, and versioned
- every hazard, control, prerequisite, and signoff step must trace back to blueprint source(s), requirement IDs, and if relevant the current standards version map
- differentiate supplier/manufacturer obligations from deploying-organisation obligations
- define ownership, due dates, evidence state, review state, and renewal cadence for every assurance artifact
- model no-self-approval, independent safety review, scope checks, and freeze checks explicitly
- where current official process or documentation could change, add `standards_version`, `reviewed_at`, and `source_note` fields instead of baking assumptions into free text

Testing and verification law:
- Every frontend task in this batch must create:
  - unit tests
  - integration tests
  - accessibility assertions
  - `Playwright_or_other_appropriate_tooling` end-to-end suites
  - screenshot or gallery verification for the shell’s key viewports
- Use Playwright for DOM-stable navigation, keyboard/focus verification, route continuity, breakpoint checks, reduced-motion checks, and seeded-state regression.
- If a shell includes charts, matrices, or ranking visuals, Playwright must verify their paired summary and table/list fallback.
- Assurance tasks must create validation scripts that fail when required fields, version metadata, owners, traceability links, or review-state fields are missing.

Repository expectations:
- Create artifacts under `docs/architecture/`, `docs/assurance/`, `data/analysis/`, `data/assurance/`, `tools/analysis/`, `tools/assurance/`, and the relevant app/package paths.
- Keep outputs deterministic and machine-readable.
- Use repository-relative links inside generated docs.
- Prefer JSON, CSV, YAML, or JSONL for registries and matrices.

Definition of success for this batch:
- the remaining Phase 0 shells are seeded with premium, governed, same-shell route families
- the assurance workstream is no longer a vague future obligation; it has concrete registers, evidence packs, validation scripts, cadence rules, and source-traceable structure
- later live integration and release tasks can extend these outputs rather than replacing them
```
