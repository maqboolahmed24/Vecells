# Shared Operating Contract For Prompts 204 To 211

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `196` to `203`. This batch has two jobs:

1. finish Phase 2 honestly by running the hard verification block for identity, session, telephony, parity, optional PDS, and duplicate-follow-up re-safety, then issuing the formal Phase 2 exit decision
2. open the next cross-cutting patient-account and support-surface work package, and begin the first two backend projection tracks that will power the later patient portal routes

The tasks covered here are:

- `204_seq_phase2_Playwright_or_other_appropriate_tooling_testing_run_auth_replay_session_expiry_identity_mismatch_and_logout_suites`
- `205_seq_phase2_Playwright_or_other_appropriate_tooling_testing_run_ivr_webhook_audio_integrity_and_continuation_access_grant_suites`
- `206_seq_phase2_Playwright_or_other_appropriate_tooling_testing_run_wrong_patient_repair_and_web_phone_parity_regression_suites`
- `207_seq_phase2_Playwright_or_other_appropriate_tooling_testing_run_pds_feature_flag_and_duplicate_followup_resafety_suites`
- `208_seq_phase2_exit_gate_approve_identity_and_echoes_completion`
- `209_seq_crosscutting_open_patient_account_and_support_surface_tracks_gate`
- `210_par_crosscutting_track_backend_build_patient_spotlight_decision_projection_and_quiet_home_logic`
- `211_par_crosscutting_track_backend_build_request_browsing_detail_and_typed_patient_action_routing_projections`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `203` as the guaranteed completed foundation for this batch.

You must assume the following earlier work is authoritative and available:

- Phase 2 trust, auth, linkage, grant, and session outputs from `170` to `186`
- Phase 2 telephony, continuation, and convergence outputs from `187` to `194`
- Phase 2 patient-facing portal and provider-configuration outputs from `195` to `203`

Tasks `204` to `208` are sequential verification and gate tasks. They must test the real repository state and may implement bounded fixes where the suites expose contract drift.

Task `209` opens the next parallel implementation block. It must publish seam ownership, dependency edges, and merge rules for tasks `210` to `222`.

Tasks `210` and `211` are only the first two backend tasks in that cross-cutting block. Do not assume outputs from sibling tasks `212` to `222` already exist unless they are physically present and internally coherent.

If a sibling task output from the new cross-cutting block is absent, stale, or contradictory, do not block. Publish the smallest correct seam, adapter, or temporary contract and record a machine-readable artifact named:

- `PARALLEL_INTERFACE_GAP_CROSSCUTTING_<AREA>.json`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, and `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth. External guidance refines implementation quality, security, accessibility, provider hardening, and browser-proof technique, but it must never override the local model.

Use this priority order:

1. `blueprint/phase-2-identity-and-echoes.md`
2. `blueprint/patient-account-and-communications-blueprint.md`
3. `blueprint/patient-portal-experience-architecture-blueprint.md`
4. `blueprint/callback-and-clinician-messaging-loop.md`
5. `blueprint/staff-operations-and-support-blueprint.md`
6. `blueprint/phase-0-the-foundation-protocol.md`
7. `blueprint/phase-cards.md`
8. `blueprint/platform-runtime-and-release-blueprint.md`
9. `blueprint/platform-frontend-blueprint.md`
10. `blueprint/accessibility-and-content-system-contract.md`
11. `blueprint/design-token-foundation.md`
12. `blueprint/canonical-ui-contract-kernel.md`
13. `blueprint/forensic-audit-findings.md`
14. validated prompt outputs from `170` to `203`
15. validated prompt outputs from `204` to `211` when present and internally coherent

## 3. Mandatory interpretation laws for this batch

### 3.1 Phase 2 exits only on the Phase 2 algorithm, not on wishful completion language

Tasks `204` to `208` must prove the exact Phase 2 exit conditions from `phase-2-identity-and-echoes.md`, especially `2H`.

Do not invent a softer definition of done.
Do not count code merge as proof.
Do not blur simulator-backed validation, provider-console dry runs, or mock-authorisation evidence into later production proof.

### 3.2 Same shell, same lineage, same anchor still applies

Auth callback recovery, session expiry, logout, wrong-patient hold, claim step-up, secure-link rebound, telephony continuation redemption, request-detail child routing, and cross-channel recovery are not permission to dump the user into a generic landing page.

When the same request lineage, continuity tuple, or selected anchor is still valid, the UI must preserve:

- the same `PersistentShell`
- the same `PatientNavReturnContract`
- the same `PatientRequestReturnBundle` where applicable
- the same selected anchor or last safe summary
- one bounded next safe action instead of detached navigation

### 3.3 Web and phone are one canonical intake and status system

Phase 2 may add auth, telephony, continuation, and authenticated access, but it does not create a second request model.

Web submit, authenticated uplift, telephony continuation, seeded or challenge SMS links, and late phone follow-ups must still converge on the same:

- `SubmissionEnvelope`
- canonical normalization path
- duplicate-classification rules
- safety-preemption rules
- request promotion semantics
- receipt and status truth families

Parity is semantic, not cosmetic.

### 3.4 Auth, session, and logout are local responsibilities at the relying service boundary

NHS login is the upstream identity platform, not the owner of the product’s internal session lifecycle.

The local platform must own:

- callback-consumption fencing
- state and nonce replay protection
- session establishment
- session rotation
- local expiry and timeout behavior
- subject-switch and wrong-patient fencing
- logout invalidation
- same-shell recovery after expiry, logout, or mismatch

### 3.5 Optional PDS is a bounded enrichment seam, not a replacement trust source

The optional PDS seam may enrich match confidence or demographic freshness only through the local blueprint rules.

It may not:

- replace NHS login or local identity-binding authority
- silently widen patient visibility
- silently overwrite patient-chosen Vecells contact preferences
- erase the distinction between NHS login claims, user preferences, and demographic rows
- become a hidden hard dependency when the feature flag is off

### 3.6 Home is governed quiet clarity, not dashboard filler

For tasks `209` to `211`, remember the patient-account blueprint law:

- the live patient home is a quiet, governed surface
- `PatientSpotlightDecisionProjection` is the only authority for spotlight ownership
- `PatientQuietHomeDecision` is the only legal quiet-home source
- charts, meters, admin widgets, or generic dashboard filler do not belong on the actual patient home

Use diagrams, matrices, and charts only in supporting atlas or board artifacts under `docs/frontend/`, never as a substitute for the production patient shell.

### 3.7 Request list, request detail, and patient actions are projection-first

For task `211`, request rows, detail headers, lineage strips, related-work cards, action CTAs, settlement banners, and recovery states may not be derived from route-local joins or controller trimming.

They must resolve through the typed projection family, especially:

- `PatientRequestsIndexProjection`
- `PatientRequestLineageProjection`
- `PatientRequestSummaryProjection`
- `PatientRequestDetailProjection`
- `PatientRequestDownstreamProjection`
- `PatientNextActionProjection`
- `PatientActionRoutingProjection`
- `PatientActionSettlementProjection`
- `PatientSafetyInterruptionProjection`
- `PatientRequestReturnBundle`

### 3.8 One dominant action per patient shell

The spotlight card and request-detail header may each expose only one dominant CTA at a time, and that action must be derived from the current live capability or routing envelope.

Repair, consent, identity-hold, stale continuity, or safety interruption beats stale optimistic actionability every time.

### 3.9 Mock-now and actual-later must stay explicit

This batch must preserve the established two-lane discipline:

- **mock-now**: simulator-backed, local-twin, or dry-run proof that runs in the repository now
- **actual-later**: real provider, real credential, onboarding, and live-environment work that will reuse the same contracts later

Do not disguise dry-run provider work, mock-auth flows, or simulated telephony callbacks as live production evidence.

### 3.10 Playwright is mandatory in this batch

Use Playwright from the beginning for:

- all browser-visible testing labs in `204` to `207`
- all interactive gate boards in `208` and `209`
- every HTML atlas or diagnostic surface in `210` and `211`

Other tooling may supplement Playwright, but Playwright is the primary proof mechanism for browser-facing artifacts.

## 4. External guidance that may refine implementation

Use official sources to strengthen implementation quality. They refine, but do not replace, the local blueprint.

### 4.1 NHS login and NHS App guidance

Respect current official guidance for:

- NHS login using OIDC
- the NHS login button being visible, standard, and not customisable
- partner responsibility for local session management and logout
- the mock authorisation service and test users for automated testing
- NHS login not replacing PDS
- NHS App integration standards for accessibility, usability, clinical safety, and privacy where relevant

### 4.2 OAuth and session security guidance

Use current official OAuth and security guidance for:

- state and nonce integrity
- PKCE and code-flow hardening
- callback replay resistance
- session fixation resistance
- timeout, logout, and stale-session invalidation
- deny-by-default authorization
- structured security logging
- test coverage for session timeout and authorization weaknesses

### 4.3 Telephony and email provider guidance

Use current official provider guidance for:

- signed webhook validation
- request verification
- voice status callbacks
- recording status callbacks
- IVR gather behavior
- signed email-event webhook verification and public-key retrieval where supported

### 4.4 Playwright and accessibility guidance

Use current official guidance for:

- screenshot diffs with `toHaveScreenshot`
- ARIA snapshots
- accessibility-testing support
- reduced-motion-safe interaction proofs
- semantic diagram-to-table parity
- WCAG 2.2 expectations, especially when testing browser surfaces

## 5. Hard evidence and remediation rules

### 5.1 A failed suite is not a report-only outcome

If tasks `204` to `207` expose an actionable defect inside the repository-owned system, fix it now and regenerate the proof pack.

Valid remediation includes:

- callback-consumption fencing
- session invalidation fixes
- stale-route recovery fixes
- signature-validation correction
- idempotency and replay-hardening fixes
- projection parity fixes
- duplicate-classification fixes
- feature-flag isolation fixes

Do not soften the suite to avoid the defect.

### 5.2 Exit-gate verdicts must fail closed

Task `208` may return `approved`, `go_with_constraints`, or `withheld`.

It may not use vague language such as “mostly done”.

### 5.3 Cross-cutting parallel work must open on explicit seams

Task `209` must publish:

- task ownership
- dependency edges
- merge gates
- interface seams
- mock-now vs actual-later boundaries
- allowed parallel neighbors
- forbidden ownership overlap

Parallel work must not start from intuition or oral tradition.

## 6. Deliverable placement expectations

Unless a prompt explicitly overrides this, prefer these paths:

- governance and programme packs under `docs/governance/` or `docs/programme/`
- test and performance packs under `docs/tests/`
- architecture contracts under `docs/architecture/`
- security-specific writeups under `docs/security/`
- premium visual atlases, labs, and gate boards under `docs/frontend/`
- machine-readable matrices under `data/analysis/` or `data/test/`
- validators under `tools/analysis/` or `tools/test/`
- Playwright suites under `tests/playwright/`

## 7. Cross-batch continuity reminders

- Earlier prompt outputs remain authoritative unless the current batch explicitly supersedes them.
- If you find naming drift between adjacent blueprints, resolve it with a typed adapter or alias contract rather than creating a third competing contract family.
- When moving from Phase 2 exit to cross-cutting patient account work, preserve the same identity, continuity, release, and trust tuples. The new portal surfaces are consumers of Phase 2 truth, not replacements for it.
