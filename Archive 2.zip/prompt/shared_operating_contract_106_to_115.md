# Shared Operating Contract For Prompts 106 To 115

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the live coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-105`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

These prompts continue the active Phase 0 frontend parallel block after the token graph, canonical UI kernel, and shared primitive layer have been published. This batch turns those shared contracts into reusable shell truth, status truth, continuity truth, artifact truth, route-posture truth, accessibility truth, browser-authority truth, automation truth, and the first patient-shell seed routes.

Tasks in this batch:
- `106`: persistent shell framework for patient, staff, operations, hub, governance, and pharmacy
- `107`: shared status strip, `CasePulse`, and `FreshnessChip` components
- `108`: `SelectedAnchor` and return-contract state manager
- `109`: artifact presentation, governed preview, download, print, handoff, and return-safe outbound navigation shell
- `110`: shared loading, empty, error, stale, blocked, and recovery postures
- `111`: accessibility semantic-coverage and focus-management harness
- `112`: route guard and feature-flag plumbing bound to runtime publication law
- `113`: `FrontendContractManifest` codegen and runtime validation
- `114`: automation-anchor and UI-telemetry vocabulary layer
- `115`: patient-shell seed routes and mock projections

Before executing any task in this batch, verify that the outputs from tasks `001-105` exist, remain internally coherent, and are still traceable to the canonical blueprint corpus. If a prerequisite output is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently regenerate earlier work and pretend the dependency chain is intact.

At minimum, require these upstream outputs to be present and usable:
- tasks `001-005`: requirement registry, summary reconciliation, scope boundary, audience/surface inventory, request-lineage model
- tasks `006-010`: glossary, state/invariant atlas, external dependency inventory, safety/privacy/data posture
- tasks `011-020`: cloud/runtime/frontend/tooling baselines, ADRs, milestones, risks, traceability, and the Phase 0 gate
- tasks `021-040`: external dependency strategies, provider scorecards, mock-versus-live provider strategies, simulator backlog, degraded defaults
- tasks `041-055`: repository topology, scaffolded apps/services/packages, runtime topology, trust boundaries, event namespace, FHIR strategy, frontend-manifest strategy, release/publication parity strategy, design publication strategy, WORM audit, acting-scope law, lifecycle and closure law
- tasks `056-061`: scoped mutation gate, route-intent law, adapter profile law, verification ladder, seed/simulator strategy, backup/restore tuple, and the active parallel gate
- tasks `062-075`: submission/evidence/FHIR/API/identity/reachability/duplicate/lease/settlement/queue/reservation/freeze-trust primitives and orchestrators
- tasks `076-085`: fallback closure rules, identity repair and access-grant authority, evidence and safety orchestration, deterministic rebuilds, simulator backplanes, core networking, transactional and FHIR storage foundations
- tasks `086-095`: object storage and retention, eventing and cache baselines, secrets and KMS, gateway surfaces, CI/CD and preview environments, observability SDK, runtime publication bundle, migration and projection-backfill runner
- tasks `096-105`: client cache and live-channel law, watch tuples, dependency degradation execution, topology publication checks, provenance and SBOM, backup/restore baseline, non-production canary, design-token foundation, canonical UI kernel, and shared primitives

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim and sequencing protocol
- `prompt/checklist.md` for canonical task ordering
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for the repo

Authoritative source order:
1. `phase-0-the-foundation-protocol.md` for canonical objects, state axes, invariants, lifecycle ownership, route-intent law, command-settlement law, evidence law, continuity law, artifact law, release-trust law, and foundational runtime contracts.
2. `platform-frontend-blueprint.md` for shell continuity, topology, shell-family ownership, route-family ownership, same-shell morphing, `StatusStripAuthority`, `CasePulse`, `DecisionDock`, `SelectedAnchorPolicy`, `SurfacePostureFrame`, artifact-surface rules, accessibility coverage hooks, automation hooks, and front-end verification law.
3. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `uiux-skill.md`, and `accessibility-and-content-system-contract.md` for visual language, state semantics, kernel propagation, accessibility and content law, automation anchors, telemetry vocabulary, motion law, and premium calm layout.
4. Audience and specialist shell blueprints where relevant:
   - `patient-portal-experience-architecture-blueprint.md`
   - `patient-account-and-communications-blueprint.md`
   - `staff-operations-and-support-blueprint.md`
   - `staff-workspace-interface-architecture.md`
   - `operations-console-frontend-blueprint.md`
   - `governance-admin-console-frontend-blueprint.md`
   - `pharmacy-console-frontend-architecture.md`
   - `phase-5-the-network-horizon.md` for hub-shell behavior
5. `platform-runtime-and-release-blueprint.md` for `FrontendContractManifest`, `AudienceSurfaceRuntimeBinding`, route-freeze and recovery law, publication parity, browser-boundary authority, and runtime publication tuples.
6. Relevant phase files where route meaning matters:
   - `phase-1-the-red-flag-gate.md`
   - `phase-2-identity-and-echoes.md`
   - `phase-3-the-human-checkpoint.md`
   - `phase-4-the-booking-engine.md`
   - `phase-5-the-network-horizon.md`
   - `phase-6-the-pharmacy-loop.md`
   - `phase-7-inside-the-nhs-app.md` only where constrained or embedded behavior matters
   - `phase-8-the-assistive-layer.md`
   - `phase-9-the-assurance-ledger.md`
7. `forensic-audit-findings.md` as mandatory patch law for continuity proof, shell truth, artifact truth, accessibility truth, route/runtime authority, and degraded-mode correctness.
8. `phase-cards.md`, `blueprint-init.md`, and `vecells-complete-end-to-end-flow.md` as summary and cross-phase alignment inputs that must not override higher-authority sources.

Non-negotiable interpretation rules:
- The same `shellContinuityKey` must reuse the same `PersistentShell`; adjacent states of the same active object must morph in place rather than reset, reload, or reroute to detached pages.
- If continuity is preserved, `CasePulse`, the shared status strip implemented through `AmbientStateRibbon` plus `FreshnessChip`, one current `DecisionDock`, and the active `SelectedAnchor` must remain causally honest and visually present.
- `StatusStripAuthority` and `ProjectionFreshnessEnvelope` are the only shell-level owners for save, sync, freshness, pending, and recovery cues. Transport health alone is never enough to render fresh or writable posture.
- `SelectedAnchor`, `NavigationStateLedger`, route adjacency, return contracts, restore plans, and focus restore are not convenience enhancements. Browser history alone is never authoritative continuity.
- Artifact behavior is summary-first. Preview, download, print, export, browser handoff, and cross-app handoff are separate permissions that remain live only while the current `ArtifactModeTruthProjection`, parity digest, grants, masking, channel posture, and return-safe continuity still validate.
- Loading, empty, partial-visibility, stale, blocked, read-only, and recovery states must render through one `SurfacePostureFrame` or equivalent posture contract. Full-page blank resets, decorative empty dashboards, and untyped generic error pages are invalid.
- `AccessibilitySemanticCoverageProfile`, `AutomationAnchorProfile`, `SurfaceStateSemanticsProfile`, `SurfaceStateKernelBinding`, and the current `DesignContractPublicationBundle` must stay on the same published tuple. Route-local ARIA patches or test-only selectors are invalid substitutes.
- `AudienceSurfaceRuntimeBinding` is the only machine-readable verdict for calm or writable browser posture. Feature gates, route guards, manifests, shell code, and gateways must fail closed to `read_only`, `recovery_only`, or `blocked` when that binding drifts.
- “Feature flag” in this batch means a published, runtime-bound capability switch that is subordinate to route contracts, runtime publication, release/channel freeze, and trust posture. Local boolean flags or per-route hidden toggles are forbidden.
- Every prompt in this batch must keep `Mock_now_execution` separate from `Actual_production_strategy_later`. Mock-now outputs must be high fidelity, schema-compatible, and visually credible enough that later live integration does not require a redesign.

Frontend and experience quality law:
- visual language: `Signal Atlas Live` with the `Quiet Clarity` overlay
- premium but restrained: no commodity dashboard kits, no decorative gradients, no gamified KPI tiles, no card wallpaper, no badge storms
- default feel: precise, clinical, calm, spatially memorable, and low-noise
- typography, spacing, radius, motion, pane widths, breakpoints, and density must come from the canonical token graph
- use the exact canonical type roles: `display 40/48`, `headline 32/40`, `title 24/32`, `section 20/28`, `body 16/24`, `body.sm 14/20`, `label 12/16`
- use the canonical breakpoint lattice and pane widths from the token foundation
- no local px tables, hex codes, radius ladders, shadow stacks, or semantic-color systems
- charts, matrices, and diagrams are allowed only when they clarify meaning and must always ship with summary and table fallback from the same truth tuple
- a subtle `Signal Atlas Live` mark is allowed in galleries, studios, and specimen shells, but it must not create a separate brand-color system
- `Playwright_or_other_appropriate_tooling` must drive development, specimen capture, regression coverage, accessibility checks, and DOM-marker verification from the first usable route onward

Execution standards:
- Parse and honor every relevant markdown and mermaid source under `blueprint/`.
- Build machine-readable outputs in addition to human-readable summaries.
- Every derived artifact must include explicit traceability back to source file plus heading or logical block.
- Every unresolved issue must be emitted as one of `GAP_*`, `CONFLICT_*`, `ASSUMPTION_*`, `RISK_*`, or `FOLLOW_ON_DEPENDENCY_*`.
- Prefer checked-in JSON, YAML, CSV, JSONL, HTML, TypeScript, or Python artifacts that are deterministic and diffable.
- If you generate shell studios, component labs, harnesses, observatories, or specimen pages, add automated verification for them.

Validation standards:
- If a machine-readable contract or matrix is generated, add a validator that fails on missing source refs, stale digests, invalid tuple joins, or incomplete route coverage.
- If a browser-viewable artifact is generated, validate it with `Playwright_or_other_appropriate_tooling` for landmark structure, keyboard flow, focus restore, DOM-marker stability, reduced-motion equivalence, and breakpoint behavior.
- If a task produces route-safe writable or calm posture, include failure-path coverage proving stale, degraded, blocked, or recovery posture overrides the calm or writable state.
- If a task touches artifacts, route guards, or runtime binding, include tests for same-shell fallback and return-safe continuity.

Definition of success for this batch:
- Phase 0 now has a real cross-audience shell framework, real shared shell-truth components, real continuity and anchor memory, governed artifact behavior, typed shared route postures, an executable accessibility harness, bound route guards, generated browser manifests, a stable automation and telemetry vocabulary, and a premium patient-shell seed implementation that later phases can extend without rewriting the shell law.
```
