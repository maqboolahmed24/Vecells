# Shared Operating Contract For Prompts 212 To 219

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `204` to `211`. This batch has three linked jobs:

1. finish the patient-account backend projection family so the portal has one lawful source for more-info, callback, contact-repair, health-record, and communications-timeline truth
2. realize the first cross-cutting patient-facing portal routes on top of those projections with premium, minimalist, continuity-safe UI
3. open the support-desk data foundation for ticket lineage, subject history, controlled resend, delivery repair, and replay-safe recovery without creating a second system of record

The tasks covered here are:

- `212_par_crosscutting_track_backend_build_more_info_response_thread_callback_status_and_contact_repair_projections`
- `213_par_crosscutting_track_backend_build_health_record_projection_and_record_artifact_parity_witness`
- `214_par_crosscutting_track_backend_build_communications_timeline_and_message_callback_visibility_rules`
- `215_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_patient_home_requests_and_request_detail_routes`
- `216_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_more_info_response_callback_status_and_contact_repair_views`
- `217_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_health_record_and_communications_timeline_views`
- `218_par_crosscutting_track_backend_build_support_lineage_binding_ticket_projection_and_subject_history_queries`
- `219_par_crosscutting_track_backend_build_controlled_resend_delivery_repair_and_support_replay_foundations`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `211` as the guaranteed completed foundation for this batch.

You must assume the following earlier work is authoritative and available:

- Phase 1 and Phase 2 request, continuity, receipt, identity, auth, telephony, and portal foundations from `140` to `208`
- the cross-cutting gate and seam ownership published in `209`
- patient-home and request-detail projection work from `210` and `211`

This batch intentionally mixes backend and frontend work inside one cross-cutting wave.

### Patient backend track

- `212`
- `213`
- `214`

### Patient frontend track

- `215`
- `216`
- `217`

### Support backend track

- `218`
- `219`

Do not assume sibling outputs from tasks `220` to `222` already exist.
Those support frontend tasks are downstream consumers of the work you create here.

If a sibling or future-track output is absent, stale, contradictory, or underspecified, do not block.
Publish the smallest correct seam, adapter, placeholder contract, or compatibility note and record a machine-readable artifact named:

- `PARALLEL_INTERFACE_GAP_CROSSCUTTING_<AREA>.json`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External guidance refines implementation quality, accessibility, provider hardening, and browser-proof technique, but it must never override the local model.

Use this priority order:

1. `blueprint/patient-account-and-communications-blueprint.md`
2. `blueprint/patient-portal-experience-architecture-blueprint.md`
3. `blueprint/callback-and-clinician-messaging-loop.md`
4. `blueprint/staff-operations-and-support-blueprint.md`
5. `blueprint/phase-0-the-foundation-protocol.md`
6. `blueprint/platform-frontend-blueprint.md`
7. `blueprint/platform-runtime-and-release-blueprint.md`
8. `blueprint/accessibility-and-content-system-contract.md`
9. `blueprint/design-token-foundation.md`
10. `blueprint/canonical-ui-contract-kernel.md`
11. `blueprint/phase-cards.md`
12. validated prompt outputs from `170` to `211`
13. validated prompt outputs from `212` to `219` when physically present and internally coherent

## 3. Mandatory interpretation laws for this batch

### 3.1 One patient shell still governs the account experience

Patient home, requests, request detail, more-info response, callback status, contact repair, records, and communications are not separate mini-products.

When the same request lineage, conversation cluster, record anchor, or repair case remains current, the product must preserve:

- one stable patient shell
- one lawful return contract
- one selected anchor or last safe summary
- one dominant next-safe action
- continuity-safe child-route transitions instead of detached landing pages

### 3.2 More-info is a child surface inside the request shell, not a detached workflow

`respond to more-info` must resolve through the owning request detail shell.
A deep link may exist, but it must canonicalize back into the owning request shell and preserve the same `PatientRequestReturnBundle`, anchor, and continuity evidence whenever the active lineage is unchanged.

Do not invent a standalone “more info app”.

### 3.3 Callback, repair, and consent must obey blocker dominance

If current reachability, consent, verification, or callback-window truth says the patient cannot safely reply, await callback, or continue, the dominant action must switch to the relevant blocker or recovery path.

Do not leave stale `Reply now`, `Reschedule callback`, or reassuring closed-state copy live beside a blocker.

### 3.4 Records are source-authoritative, not summary-authoritative

Structured summaries, charts, tables, previews, downloads, print views, and browser handoff must remain subordinate to source artifact authority plus the current parity witness and visibility gates.

If parity, release, audience, or step-up posture drifts, degrade in place to verified summary, provisional summary, source-only summary, table-only, placeholder, or recovery-only.
Do not leave a richer record posture live because a stale view was already mounted.

### 3.5 Communications visibility must degrade to governed placeholders, not omission

If content cannot be shown because of audience, step-up, repair, identity-hold, or recovery posture, the cluster, callback case, or reminder context must remain present as a governed placeholder with safe next-step guidance.

Do not hide active work items.
Do not leak richer preview than the current visibility envelope allows.

### 3.6 Request actions, returns, and continuity are projection-first

For all patient frontend tasks in this batch, the authoritative navigation and action inputs are the typed projection family already frozen by `210` and `211`, plus the new family from `212` to `214`.

No route may reconstruct its own truth through ad hoc joins, optimistic browser state, or controller-local trimming.

### 3.7 Support tickets are not a second system of record

`SupportTicket` is the workspace frame.
`SupportLineageBinding` is the canonical join.
`SupportLineageArtifactBinding` is the provenance join.
The support desk may summarize, stage, and recover work, but it may not locally replace request, message, callback, identity, or artifact truth.

### 3.8 Controlled resend and replay may not fork from the canonical communication chain

Every controlled resend, reissue, channel change, callback reschedule, attachment recovery, replay checkpoint, replay restore, and support receipt must stay bound to the same current governing chain:

- `MessageDispatchEnvelope`
- latest delivery evidence bundle
- latest expectation envelope
- latest resolution gate
- current support-lineage binding
- current actionable scope member
- current mask scope and disclosure ceiling

Duplicate operator clicks, webhook retries, and replay restore may not create second external side effects or second timeline truth.

### 3.9 Summary-first and mask-scope discipline applies to support history

Support subject history and ticket context must begin with masked, compact summaries and widen only through the current context binding, disclosure record, and mask scope.
Do not dump a sprawling dossier by default.

### 3.10 Mock-now and actual-later must stay explicit

Build repository-runnable, simulator-backed, and test-fixture-backed proof now.
Keep live-provider, live-credential, or production-console work as explicit later reuse of the same contracts.
Do not blur dry-run proof into production evidence.

### 3.11 Playwright is mandatory across this batch

Playwright is mandatory for:

- every frontend build task in `215` to `217`
- every atlas, board, or browser-visible artifact in `212` to `214` and `218` to `219`
- screenshot baselines, ARIA snapshots, and accessibility assertions for critical states

Other tooling may supplement Playwright, but it may not replace it as the primary browser-proof tool.

### 3.12 Provider metadata and webhook hygiene are non-negotiable

When building delivery-repair and replay foundations:

- validate inbound webhook signatures using the provider’s supported mechanism
- treat provider callbacks as untrusted until signature, timestamp, and tuple reconciliation succeed
- do not place PHI or PII in SendGrid categories, unique arguments, or other provider metadata fields that are explicitly not treated as PII
- keep correlation IDs, idempotency keys, and dispatch references provider-safe and non-sensitive

## 4. Batch dependency map

### 4.1 `215` consumes `210`, `211`, and bounded seams from `212` to `214`

If `212` to `214` are not fully ready, `215` must still ship the home, requests, and request-detail routes with governed placeholders instead of blocking or inventing route-local semantics.

### 4.2 `216` depends primarily on `212`, secondarily on `211` and `214`

More-info, callback status, and contact repair must all render from the backend truth objects and continuity rules, not from frontend timers or ad hoc URL state.

### 4.3 `217` depends primarily on `213` and `214`

The records surfaces must obey record parity and visibility.
The communications surfaces must obey the communications timeline and visibility contract.
If optional charts cannot keep parity, the UI must stay table-first or summary-first.

### 4.4 `218` and `219` must publish support contracts that `220` to `222` can consume directly

Do not ship backend support work as opaque service internals only.
Publish stable query shapes, analysis artifacts, and browser-readable atlases that later support frontend prompts can implement against without inventing new semantics.

## 5. External guidance that may refine implementation

Use official sources to strengthen implementation quality.
They refine, but do not replace, the local blueprint.

### 5.1 GOV.UK and NHS service guidance

Use current official guidance for:

- one question or decision per step when the interaction benefits from focus
- check-answers before confirmation for smaller or medium transactions
- confirmation pages that explain what happens next, when, and how the user can keep a record
- always showing an error summary on validation errors and preserving the ability to edit previously entered information
- WCAG 2.2 compliance across design, content, development, and testing

### 5.2 Playwright guidance

Use current Playwright guidance for:

- screenshot comparisons
- ARIA snapshots
- accessibility testing
- keyboard and regression proof around dynamic state changes

### 5.3 OAuth, session, logging, and provider guidance

Use current official guidance for:

- OAuth 2.0 security best current practice
- server-side session timeout and invalidation
- structured security logging and correlation IDs
- Twilio webhook signature validation and status callbacks
- SendGrid signed event webhook verification and public-key retrieval
- SendGrid warnings that categories and unique arguments are not treated as PII

## 6. Shared UI and content posture for patient-facing work

Patient-facing UI in this batch must feel:

- calm
- premium
- minimal
- deliberate
- clinically serious without becoming cold
- clearly unlike generic AI dashboards

Use the design-token foundation first.
If concrete fallback values are needed while wiring, keep them consistent across `215` to `217` and then map them back to tokens.

Global patient-surface fallback values you may use if tokens are absent:

- background canvas: `#F6F8FB`
- primary panel: `#FFFFFF`
- elevated tint: `#EEF3F9`
- strong text: `#102033`
- body text: `#425466`
- hairline border: `#D9E1EA`
- accent indigo: `#495FEA`
- accent teal: `#0E8C87`
- warning amber: `#B7791F`
- danger oxblood: `#B42318`
- success pine: `#127A5A`

Typography fallback if tokens are absent:

- `InterVariable, Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`

Dimensional fallback if tokens are absent:

- shell band: `64px`
- max content width: `1240px`
- comfort body column: `720px`
- details side rail: `304px`
- spotlight radius: `18px`
- standard panel radius: `16px`
- compact chip radius: `999px`
- desktop gutter: `32px`
- mobile gutter: `16px`

Motion fallback:

- `140ms` to `180ms` for opacity and transform transitions
- max translate distance `8px`
- no spring or bounce
- respect `prefers-reduced-motion` by removing non-essential motion

### 6.1 Appropriate charts and diagrams

Use charts only where the local algorithm explicitly allows them.

Allowed examples in this batch:

- record-result trend visualization only when current parity permits it and a table-first equivalent is present
- callback-window or repair-state diagram in atlas artifacts
- support replay and lineage diagrams in atlas artifacts

Not allowed:

- dashboard filler charts on the live patient home
- decorative charts that imply certainty or parity the backend has not proved

### 6.2 Logo and identity restraint

If you need a mark for atlas or shell framing, use a restrained monoline Vecells glyph or wordmark.
Avoid cliché healthcare crosses, glossy gradients, mascot illustrations, or generic AI sparkle motifs.

## 7. Required evidence package pattern

Every task in this batch must leave behind:

1. production code or prompt artifact required by the task
2. architecture notes
3. security or safety notes
4. one browser-readable atlas or board artifact
5. machine-readable analysis matrices or case files
6. repository-native tests
7. a Playwright spec for the atlas or live route states it introduces

If a task cannot fully complete because a sibling seam is genuinely missing, the output must still be runnable and must publish a crisp gap artifact instead of silently stubbing behavior.
