# Shared Operating Contract For Prompts 146 To 155

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-145`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch has two responsibilities:
1. finish the remaining Phase 1 backend intake pipeline from attachment ingress through contact preference capture, immutable submit promotion, canonical normalization, synchronous safety, urgent/receipt settlement, triage handoff, confirmation dispatch, and post-promotion resume blocking; and
2. publish the first real patient-facing intake mission frame so later Phase 1 step and outcome routes can inherit one premium same-shell composition instead of fragmenting into generic wizard pages.

Tasks in this batch:
- `146`: backend attachment upload, scan, quarantine, and `DocumentReference` pipeline
- `147`: backend contact preference capture and masked storage
- `148`: backend immutable submission snapshot freeze and promotion transaction
- `149`: backend deterministic free-text and structured-answer normalization into canonical request shape
- `150`: backend rule-based synchronous safety engine
- `151`: backend urgent-diversion settlement and receipt grammar
- `152`: backend triage task creation, ETA engine, and minimal status tracking
- `153`: backend confirmation-notification dispatch and observability
- `154`: backend promoted-draft token supersession and resume blocking
- `155`: `Playwright_or_other_appropriate_tooling` patient intake mission frame frontend

Before executing any task in this batch, verify that the outputs from tasks `001-145` exist, remain internally coherent, and still bind to the canonical blueprint corpus. If a prerequisite artifact is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently re-invent earlier work and pretend the dependency chain is intact.

At minimum, require these upstream outputs to remain usable:
- tasks `001-005`: requirement registry, summary reconciliation, scope boundary, personas/channels/surfaces, and request-lineage model
- tasks `006-010`: glossary, state atlas, external dependency inventory, safety/privacy posture, and PHI classification posture
- tasks `011-020`: platform baselines, ADRs, milestones, risk/watchlist, traceability, and Phase 0 entry approval
- tasks `021-040`: simulator-first provider strategy, mock-vs-actual dependency decisions, contract assumptions, and degraded-mode defaults
- tasks `041-055`: repository topology, service/package scaffolds, runtime/publication strategy, lifecycle/closure law, tenant isolation, and mutation-gate foundations
- tasks `062-102`: canonical domain aggregates, projection worker substrate, simulator backplanes, runtime substrate, publication bundle law, schema/backfill runners, degradation execution, SBOM/signature verification, backup/recovery baseline, and canary harness
- tasks `103-120`: token foundation, UI kernel, shared primitives, shell skeletons, status-strip law, selected-anchor law, artifact shell law, accessibility harness, route guards, frontend manifest validation, automation vocabulary, and seed audience shells
- tasks `121-145`: Phase 0 assurance packs, privacy/DPIA start, Phase 0 merge/verification work, Phase 0 exit gate, Phase 1 freeze contracts, urgent-diversion rulebook, parallel-intake gate, draft lease/autosave implementation, and backend validation/readiness implementation

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim/sequence protocol
- `prompt/checklist.md` for canonical task ordering and gate discipline
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for this repo

Authoritative source order:
1. `phase-1-the-red-flag-gate.md` for the canonical Phase 1 intake, attachment, submit, safety, receipt, ETA, status, and observability algorithm. In particular, honor `## 1B`, `## 1C`, `## 1D`, `## 1E`, `## 1F`, and `## 1G`.
2. `phase-0-the-foundation-protocol.md` for canonical `SubmissionEnvelope`, `SubmissionPromotionRecord`, `Request`, `RequestLineage`, `EvidenceCaptureBundle`, `EvidenceSnapshot`, `NormalizedSubmission`, `SafetyDecisionRecord`, `UrgentDiversionSettlement`, `PatientReceiptConsistencyEnvelope`, `AccessGrantScopeEnvelope`, `AccessGrantSupersessionRecord`, `ContactRouteSnapshot`, `ReachabilityAssessmentRecord`, `ArtifactPresentationContract`, `OutboundNavigationGrant`, and route/continuity/release law.
3. `platform-frontend-blueprint.md`, `patient-portal-experience-architecture-blueprint.md`, and `patient-account-and-communications-blueprint.md` for patient-shell continuity, `PersistentShell`, `SelectedAnchor`, status-strip law, route-family ownership, receipt/status visibility, communication receipt semantics, and same-shell recovery law.
4. `platform-runtime-and-release-blueprint.md` for `AudienceSurfaceRuntimeBinding`, `RuntimePublicationBundle`, `ReleasePublicationParityRecord`, `RouteFreezeDisposition`, `ReleaseRecoveryDisposition`, and fail-closed runtime/publication behavior.
5. `phase-cards.md` for the programme-level Phase 1 scope, tests, and simulator-first baseline.
6. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `accessibility-and-content-system-contract.md`, and `uiux-skill.md` for detailed patient-facing visual-language, motion, spacing, typography, accessibility, content, and automation-anchor law.
7. `forensic-audit-findings.md` as mandatory patch law, especially Findings `03`, `04`, `09`, `10`, `11`, `12`, `25`, `61`, `62`, `81`, `82`, `105`, `118`, and `120`.
8. `blueprint-init.md` and `vecells-complete-end-to-end-flow.md` / `.mmd` as top-level cross-phase references that must not override higher-authority source files.

Non-negotiable interpretation rules:
- Draft truth remains on `SubmissionEnvelope`. No task in this batch may create a parallel draft aggregate or infer request creation from client state.
- Immutable submission evidence must freeze before normalization or routing. `EvidenceCaptureBundle` and `EvidenceSnapshot` are not optional implementation details.
- `Request.workflowState = submitted` is a required durable barrier. No task in this batch may skip from draft-like state straight to `intake_normalized`, `triage_ready`, or any child workflow state.
- Quarantine-first attachment handling is mandatory. Raw object-store URLs, raw attachment IDs, or unscanned files may never appear as trusted patient or staff artifacts.
- Contact preference capture is not the same thing as verified route truth. Preference choice, route existence, route verification, and current reachability risk must remain distinct. Any delivery-dependent calmness later in Phase 1 must still bind `ContactRouteSnapshot` and `ReachabilityAssessmentRecord` or fail closed.
- Hidden superseded answers may stay in audit history, but they may not re-enter active summary, normalization, safety, ETA, or receipt semantics.
- `urgent_diversion_required` and `urgent_diverted` are separate durable states. Patient-facing urgent advice may not imply issued settlement until `UrgentDiversionSettlement(settlementState = issued)` exists.
- Non-urgent flow is not complete until a real `TriageTask` exists. Only then may the request become `triage_ready` and only then may a normal receipt/ETA promise become authoritative.
- ETA must be conservative, monotone in queue rank, bucketized, and explicitly uncertainty-aware. A single optimistic timestamp or silent promise oscillation is forbidden.
- Notification dispatch must keep `local acknowledgement`, `transport acceptance`, `delivery evidence`, and `authoritative outcome` distinct. Queueing or vendor acceptance alone may not create calm success truth.
- Governed promotion must supersede active draft-resume grants and active `DraftSessionLease`s in the same transaction as request creation. A promoted lineage may never reopen as a second mutable draft lane.
- Keep `Mock_now_execution` and `Actual_production_strategy_later` separate whenever a task touches simulator-backed scanning, notifications, embedded/auth seams, or future live providers. Mock-now means real product behavior backed by contract-faithful simulators. Actual-production strategy means the later live-provider path that preserves the same public schemas and semantic tuple structure.
- Any browser-viewable artifact in this batch must use `Playwright_or_other_appropriate_tooling` from the start, expose deterministic `data-testid` markers, support full keyboard operation, honor reduced-motion, and provide table/list parity for any chart, diagram, or visual summary.
- Do not ship generic wizard chrome, templated SaaS cards, or decorative marketing surfaces. Premium minimalism here means exact hierarchy, strong whitespace, quiet confidence, governed recovery, and distinctive product-native patient tooling.

Backend quality law for this batch:
- use explicit domain/application/infrastructure separation
- prefer append-only evidence and settlement records over mutable status toggles
- use deterministic idempotency keys and replay-safe command handling
- enforce concurrency with version checks, fencing, or compare-and-swap where lineage integrity depends on it
- keep PHI out of logs, metrics labels, URLs, DOM attributes, and telemetry payloads
- make all external I/O replaceable by simulator adapters behind small interfaces
- emit machine-readable reason codes for blocked, degraded, recovery, and collision paths
- favor fail-closed recovery over optimistic calmness when runtime, publication, safety, or delivery truth is stale or partial

Frontend and experience quality law for browser-viewable artifacts in this batch:
- visual language: `Quiet_Clarity_Intake`
- tone: premium, calm, exact, health-literate, low-noise, and continuity-aware
- avoid: template step wizards, noisy progress bars, generic dashboard cards, toast storms, detached success pages, or stacked alert banners
- if a local bootstrap token seed is needed before the canonical token package compiles, use this aligned seed and document it as temporary bootstrap only:
  - canvas `#F7F8FA`
  - shell `#EEF2F6`
  - panel `#FFFFFF`
  - inset `#E8EEF3`
  - text strong `#0F1720`
  - text default `#24313D`
  - text muted `#5E6B78`
  - border subtle `#D8E0E8`
  - accent live `#2F6FED`
  - accent safe `#117A55`
  - accent pending `#B7791F`
  - accent blocked `#B42318`
  - accent continuity `#5B61F6`
- typography should resolve through the design-token foundation first; if a bootstrap stack is required, use the system sans stack already established in the earlier prompt packs and preserve these role sizes:
  - display `40/48`
  - headline `32/40`
  - title `24/32`
  - section `20/28`
  - body `16/24`
  - body.sm `14/20`
  - label `12/16`

Definition of done for the batch:
- the repository can safely capture attachments, contact preferences, immutable submit snapshots, canonical normalization, synchronous safety, urgent or receipt settlement, triage handoff, confirmation messaging, and stale-draft blocking on the same authoritative lineage
- the patient intake shell has one premium, same-shell mission frame that later Phase 1 routes can inherit without redesign
- every new artifact is source-traceable, testable, and simulator-first while preserving the live-provider seams needed later
```
