# Shared Operating Contract For Prompts 260 To 267

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `252` to `259`.

This batch completes the first serious Phase 3 staff and patient-facing consequence surfaces:

1. approval, escalation, changed-work recovery, and focus-protected workspace continuity
2. callback and clinician-messaging operational views
3. self-care and bounded admin-resolution consequence views
4. patient conversation continuity across more-info, callback, and clinician messaging
5. governed support replay and linked-context investigation surfaces

All tasks in this batch are frontend implementation tasks with mandatory proof through Playwright.
Do not spend task budget on decorative experiments, detached page families, or generic “dashboard” patterns.
If a task needs an atlas, diagram, or internal explainer, keep it secondary to executable UI, route contracts, state handling, and test proof.

The tasks covered here are:

- `par_260_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_approval_inbox_and_escalation_surfaces`
- `par_261_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_changed_since_seen_and_review_resumed_recovery_flow`
- `par_262_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_workspace_focus_protection_buffered_queue_change_and_next_task_posture`
- `par_263_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_callback_management_views_and_attempt_outcome_capture`
- `par_264_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_clinician_messaging_thread_and_delivery_repair_views`
- `par_265_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_self_care_advice_issue_and_admin_resolution_views`
- `par_266_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_patient_conversation_surface_for_more_info_callback_and_message_updates`
- `par_267_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_support_desk_replay_and_linked_context_views_for_triage_failures`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `259` as the intended completed foundation for this batch.

That foundation includes at minimum:

- Phase 0 shell, route, mutation, artifact, continuity, visibility, publication, trust, and audit law
- Phase 1 intake, safety, duplicate, notification, and patient continuity work
- Phase 2 identity, telephony, portal, patient-account, support, and cross-channel continuity work
- cross-cutting support and patient-account work from `210` to `225`
- Phase 3 backend kernels `231` to `254`
- Phase 3 frontend workspace kernels `255` to `259`, especially:
  - `255` workspace shell, route family, and navigation ledger
  - `256` queue workboard, preview pocket, and selected-anchor continuity
  - `257` active task shell, `CasePulse`, and `DecisionDock`
  - `258` rapid entry, more-info stage, and endpoint reasoning
  - `259` attachment viewer and patient-response thread

### If any upstream implementation is missing, empty, or contradictory

Do not block on archive mismatch.

Use this fallback order:

1. local algorithm files under `blueprint/`
2. coherent repository code already implementing the same contract
3. the expected outputs implied by prompts `244` to `259`

When an upstream artifact is logically required but physically absent, publish the smallest correct seam or reconstruction note in a machine-readable file named:

- `PARALLEL_INTERFACE_GAP_PHASE3_FRONTEND_<AREA>.json`

Every such artifact must include:

- `taskId`
- `missingSurface`
- `expectedOwnerTask`
- `temporaryFallback`
- `riskIfUnresolved`
- `followUpAction`

Do not weaken route continuity, settlement fencing, visibility law, message/callback truth, replay restore law, or patient-safe wording just because an upstream file is missing.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may improve frontend craft, interaction density, accessibility, responsiveness, and test discipline, but they must never override the local model.

Use this priority order:

1. `blueprint/staff-workspace-interface-architecture.md`
2. `blueprint/phase-3-the-human-checkpoint.md`
3. `blueprint/callback-and-clinician-messaging-loop.md`
4. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
5. `blueprint/patient-account-and-communications-blueprint.md`
6. `blueprint/staff-operations-and-support-blueprint.md`
7. `blueprint/platform-frontend-blueprint.md`
8. `blueprint/canonical-ui-contract-kernel.md`
9. `blueprint/design-token-foundation.md`
10. `blueprint/patient-portal-experience-architecture-blueprint.md`
11. `blueprint/phase-0-the-foundation-protocol.md`
12. `blueprint/platform-runtime-and-release-blueprint.md`
13. `blueprint/phase-9-the-assurance-ledger.md`
14. validated prompt outputs from `108`, `109`, `220` to `259` when physically present and internally coherent

## 3. Batch dependency map

### 3.1 `260` owns approval inbox and escalation routes inside the workspace shell

Task `260` owns:

- `/workspace/approvals` and `/workspace/escalations`
- approval inbox row grammar, filter model, and sorting posture
- `ApprovalReviewFrame` rendering
- urgent escalation stage and contact-attempt capture views
- stale, superseded, and stale-recoverable approval rendering

Tasks `261` and `262` may consume approval route continuity, but they may not redefine approval truth or escalation authority.

### 3.2 `261` owns changed-since-seen and resumed-review recovery

Task `261` owns:

- `/workspace/changed`
- `EvidenceDeltaPacket` as the visible changed-evidence contract
- delta-first resume landing rules
- superseded-context comparison and acknowledgement posture
- recommit gating when consequential change remains unresolved

Task `261` must not collapse changed work into a generic badge or background refresh.

### 3.3 `262` owns focus protection, buffered queue change, and next-task posture

Task `262` owns:

- `WorkspaceFocusProtectionLease`
- `ProtectedCompositionState`
- `QueueChangeBatch`
- post-completion stability posture
- `NextTaskPrefetchWindow`
- `NextTaskLaunchLease` rendering and block reasons

Task `262` must preserve drafts, compare posture, selected anchors, and same-shell return context under refresh, reconnect, and queue churn.

### 3.4 `263` owns callback operational views

Task `263` owns:

- callback worklist and detail surfaces
- schedule, reschedule, cancel, and stale-promise posture
- attempt timeline and attempt-outcome capture
- route-repair dominant-action surfaces
- visibility of `CallbackIntentLease`, `CallbackAttemptRecord`, `CallbackExpectationEnvelope`, `CallbackOutcomeEvidenceBundle`, and `CallbackResolutionGate`

Task `263` must not present a dialer-first or transport-first view of callback truth.

### 3.5 `264` owns clinician-messaging thread and delivery-repair views

Task `264` owns:

- in-shell clinician-message thread rendering
- visible truth ladder across drafted, sent, delivered, disputed, repaired, and stale states
- repair-scope and delivery-dispute stages
- resend, reissue, channel-change, and attachment-recovery controls when permitted
- use of `MessageDispatchEnvelope`, `MessageDeliveryEvidenceBundle`, `ThreadExpectationEnvelope`, and `ThreadResolutionGate`

Task `264` must not imply message success from provider acceptance alone.

### 3.6 `265` owns self-care issue and bounded admin-resolution consequence views

Task `265` owns:

- self-care preview and issue stage
- admin-resolution preview, waiting, blocked, complete, and reopen stages
- visible dependency blocker rendering
- completion-artifact summaries and patient expectation summaries
- same-shell stale-recoverable consequence posture

Task `265` consumes `SelfCareBoundaryDecision`, `AdviceRenderSettlement`, `AdviceAdminDependencySet`, and `AdminResolutionSettlement`.
It must not blur self-care and bounded admin work into one consequence path.

### 3.7 `266` owns the patient conversation route family

Task `266` owns:

- patient conversation routes for more-info, callback status, message updates, and contact repair
- request-return continuity inside the patient shell
- patient composer, receipt, callback status, and chronology rendering
- blocked-action context and dominant contact-repair action
- use of `PatientRequestReturnBundle`, `PatientMoreInfoStatusProjection`, `ConversationThreadProjection`, `PatientReceiptEnvelope`, `ConversationCommandSettlement`, `PatientCallbackStatusProjection`, and `PatientContactRepairProjection`

Task `266` must not degrade into a generic message center or detached conversation app.

### 3.8 `267` owns support replay and linked-context investigation views

Task `267` owns:

- support replay entry and replay session surfaces
- masked evidence-boundary rendering
- linked conversation, history, and knowledge child views
- delta-review, draft-hold, and restore posture
- use of `SupportReplaySession`, `SupportReplayEvidenceBoundary`, `SupportReplayDeltaReview`, `SupportReplayDraftHold`, and `SupportReplayRestoreSettlement`

Task `267` must preserve support-shell continuity and may not bypass replay restore or masking law through deep-link shortcuts.

## 4. Mandatory interpretation laws for this batch

### 4.1 Same-shell continuity is mandatory

Approval, escalation, changed-review, callback, clinician messaging, self-care/admin consequence, patient conversation, and support replay must remain within their governing shell and route family.
Do not fork detached mini-apps, modal-only substitutes, or “open in new page” escapes for core work.

### 4.2 `DecisionEpoch`, approval gates, and settlement records remain authoritative

Visible confidence, enabled actions, and completion messaging must bind the live canonical fence and settlement objects.
UI calmness must freeze when tuple drift, supersession, or stale-recoverable state exists.

### 4.3 `EvidenceDeltaPacket` is the only changed-review truth contract

Changed-since-seen copy, highlights, resume routing, and recommit gating must derive from the current delta packet.
Do not recompute “what changed” separately in each view.

### 4.4 Focus protection is a first-class state, not a toast

Protected composition, buffered queue change, quiet return, and next-task readiness must be durable, inspectable, and reversible.
Do not auto-advance, silently drop drafts, or swap the task context while the operator is composing or comparing.

### 4.5 Callback and message transport are not outcome truth

Provider acceptance, ringing, webhook delivery, or optimistic transport success may widen or settle transport posture, but they may not imply callback resolution, successful message review, or request closure by themselves.

### 4.6 Self-care and bounded admin consequence must stay distinct

Copy, color, layout, and flow may feel related, but they may not hide the difference between informational self-care and bounded admin-resolution.
Dependency instability or reopen triggers must freeze stale consequence rather than smoothing it over.

### 4.7 Patient conversation is a governed continuity surface

The patient conversation surface must prioritize reassurance, orientation, and actionability without false calm.
It must preserve request or cluster return context and elevate contact repair when the current route is no longer safe.

### 4.8 Support replay is controlled restoration work

Replay must freeze live updates, preserve masking, stage delta review explicitly, and restore live work only after revalidation.
Do not treat replay as a raw log viewer or an unrestricted support cockpit.

## 5. Implementation and proof rules

### 5.1 Playwright is mandatory

Every task in this batch must use Playwright as the primary development and regression proof harness.
Another browser tool may supplement it, but it may not replace Playwright as the main proof surface.

### 5.2 Route and DOM contracts must be stable

Interactive route families, shell landmarks, task regions, promoted action docks, timeline sections, and evidence panels must expose stable selectors and deterministic DOM structure suitable for regression testing.

### 5.3 Accessibility is part of the contract

Use semantic landmarks, heading discipline, keyboard-complete flows, visible focus, and screen-reader-safe status updates.
Dense operational interfaces must remain navigable without pointer-only affordances.

### 5.4 Responsive behavior must preserve the same truth model

Narrow layouts may restack or collapse secondary context, but they may not hide blockers, stale state, route repair, or authoritative settlement.

### 5.5 Atlas artifacts are support-grade, not the product

If a task emits a visual atlas, state diagram, or browser-viewable map, validate it with Playwright for landmark structure, selector stability, and route navigation integrity.
Those artifacts support implementation; they do not replace it.
