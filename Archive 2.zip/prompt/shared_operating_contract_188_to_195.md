# Shared Operating Contract For Prompts 188 To 195

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `180` to `187`. This batch finishes the Phase 2 telephony execution path from canonical phone ingress through evidence readiness, seeded or challenge continuation, duplicate-safe convergence, and late-evidence re-safety handling. It also builds the first production-grade signed-out auth callback and recovery experience that sits on top of the earlier NHS login, session, capability, and ownership contracts.

The tasks covered here are:

- `188_par_phase2_track_telephony_build_call_session_state_machine_and_menu_selection_capture`
- `189_par_phase2_track_telephony_build_caller_verification_and_captured_identifier_pipeline`
- `190_par_phase2_track_telephony_build_recording_fetch_worker_and_audio_quarantine_storage`
- `191_par_phase2_track_telephony_build_transcript_readiness_fact_extraction_and_evidence_readiness_assessments`
- `192_par_phase2_track_telephony_build_seeded_vs_challenge_sms_continuation_access_grants`
- `193_par_phase2_track_telephony_build_one_pipeline_convergence_into_canonical_submission_promotion`
- `194_par_phase2_track_telephony_build_duplicate_attachment_and_resafety_trigger_handling_for_phone_followups`
- `195_par_phase2_track_Playwright_or_other_appropriate_tooling_frontend_build_real_sign_in_callback_and_signed_out_recovery_experience`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `174` as the only guaranteed completed foundation for this batch.

You must assume the following earlier work is already authoritative and available:

- `170` trust contract and capability-gate freeze
- `171` NHS login auth transaction and local session contracts
- `172` patient-linkage, match-model, and optional PDS seam freeze
- `173` telephony call-session and evidence-readiness contract freeze
- `174` Phase 2 shared interface registry and parallel gate

Tasks `175` to `187` belong to the same broader Phase 2 parallel block and are not guaranteed to exist when any single prompt in this batch executes. If outputs from `175` to `187` are present and coherent, consume them. If they are absent, stale, or contradictory, do not block. Instead publish the smallest correct seam, contract, or adapter needed for your task and record a machine-readable gap artifact named with the form:

- `PARALLEL_INTERFACE_GAP_PHASE2_<AREA>.json`

Every such gap artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, and `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth. External guidance may refine implementation quality, accessibility, provider hardening, or testing technique, but it must never override the local model.

Use this priority order:

1. `blueprint/phase-2-identity-and-echoes.md`
2. `blueprint/phase-0-the-foundation-protocol.md`
3. `blueprint/phase-cards.md`
4. `blueprint/patient-account-and-communications-blueprint.md`
5. `blueprint/patient-portal-experience-architecture-blueprint.md`
6. `blueprint/platform-frontend-blueprint.md`
7. `blueprint/accessibility-and-content-system-contract.md`
8. `blueprint/design-token-foundation.md`
9. `blueprint/canonical-ui-contract-kernel.md`
10. `blueprint/callback-and-clinician-messaging-loop.md`
11. Prompt outputs from `170` to `174`
12. Prompt outputs from `175` to `187` when present and internally coherent

## 3. Phase 2 interpretation laws for this batch

The following interpretations are mandatory across every task in this batch.

### 3.1 Telephony edge, call state, transcript readiness, evidence readiness, continuation eligibility, and promotion are separate concepts

Do not collapse them.

- provider callbacks terminate at the telephony edge
- canonical telephony events are the only inputs allowed deeper into the platform
- `CallSession.callState` explains channel progress, not patient trust or submission promotability
- `TelephonyTranscriptReadinessRecord` describes transcript job and coverage posture, not safety usability by itself
- `TelephonyEvidenceReadinessAssessment` is the sole authority on whether phone evidence is `awaiting_*`, `manual_review_only`, `urgent_live_only`, or `safety_usable`
- `TelephonyContinuationEligibility` is the sole authority on whether bounded seeded or challenge continuation may be offered
- canonical `SubmissionIngressRecord`, `NormalizedSubmission`, duplicate policy, and promotion rules decide request creation and receipt semantics

A call must not be seeded or promoted from `recording_expected`, `recording_available`, `evidence_preparing`, `evidence_pending`, `urgent_live_only`, or `continuation_eligible`.

### 3.2 Telephony identity evidence may inform binding, but may never bind locally

Telephony verification contributes candidate evidence, confidence, and destination posture. It may not directly mutate durable lineage binding, durable `patientRef`, request ownership, or session identity outside `IdentityBindingAuthority`.

`IdentityBindingAuthority` remains the only authority that can append a new binding version or compare-and-set `Request.patientRef` or `Episode.patientRef`.

### 3.3 Seeded continuation requires more than a successful call

A seeded SMS continuation is allowed only when all of the following are simultaneously true for the latest settled facts:

- `TelephonyContinuationEligibility.eligibilityState = eligible_seeded`
- the destination posture proves safe delivery to the intended patient
- the current authority-settled identity binding and route fences still match
- the current `AccessGrantScopeEnvelope` can be frozen to the exact route tuple and lineage
- the redemption path validates session epoch, subject binding version, lineage fence, release posture, and any channel posture required by the local model

`manual_only` creates no redeemable grant. Challenge continuation may exist without revealing seeded patient data.

### 3.4 All channels converge through one intake path

Self-service, telephony capture, secure-link continuation, and support-assisted capture all converge through the same Phase 0 intake model.

Every channel must resolve through:

- one immutable frozen capture bundle
- one immutable `EvidenceSnapshot`
- one immutable `SubmissionIngressRecord`
- one canonical `NormalizedSubmission`
- one duplicate-resolution path
- one exact-once promotion rule
- one receipt and status consistency grammar

There is no phone-only request schema, no phone-only receipt model, and no phone-only safety shortcut.

### 3.5 Late phone or SMS evidence must use canonical evidence assimilation and re-safety

Any post-submit or already-linked phone follow-up that can alter evidence meaning, chronology, contradiction burden, contact risk, or routine-bypass posture must settle:

- one `EvidenceClassificationDecision`
- one `MaterialDeltaAssessment`
- one `EvidenceAssimilationRecord`

and, when required, one `SafetyPreemptionRecord` plus the resulting `SafetyDecisionRecord`.

Exact or semantic replay returns the settled assimilation chain. It must not mint a second preemption path.

### 3.6 Same-shell continuity still applies in signed-out and recovery states

Signed-out, callback, timeout, consent, subject-conflict, stale-return, and recovery states must preserve same-lineage shell continuity whenever the local model allows it.

Do not redirect to generic home, blank landing, or a fresh anonymous shell while the same request lineage, return intent, or continuity key is still current. Recover in place through a bounded same-shell recovery posture.

### 3.7 Visibility, logging, and token hygiene are non-negotiable

Do not leak:

- raw OIDC tokens or raw claims
- raw telephony provider payloads
- full phone numbers
- full NHS numbers
- unmasked patient identifiers
- signed continuation URLs
- raw evidence blobs

into logs, traces, analytics labels, screenshots, metrics tags, HTML, URLs, or test snapshots. Use refs, hashes, masked fragments, and governed diagnostic views only.

## 4. External guidance that may refine implementation

Use the following sources only to strengthen implementation details and hardening. They do not override the local blueprint.

- Official NHS login guidance for button usage, transaction semantics, mock authorisation testing, the rule that partner services own session management and logout, and the rule that NHS login contact details are not equivalent to PDS or GP data.
- Official NHS and GOV design guidance for buttons, error summary, error messages, question-page structure, preserving entered values after validation, and plain-language accessibility.
- Official Playwright guidance for screenshot assertions, ARIA snapshots or equivalent semantic assertions, role-based locators, and accessibility testing.
- OAuth 2.0 Security Best Current Practice and PKCE guidance for callback hardening, state and nonce handling, replay resistance, and redirect safety.
- Official provider webhook and telephony guidance, including request-signature validation, call-status callbacks, recording-status callbacks, and IVR or gather behavior, if you choose a concrete provider adapter such as Twilio.
- OWASP guidance on authorization, session management, logging, TLS, cryptographic storage, and secure use of structured events.

## 5. Delivery format rules

Every prompt in this batch must produce all of the following:

1. production-shaped code, not pseudocode
2. contract-first schema or interface artifacts for every new durable object or external seam
3. task-specific architecture, API, operations, and security documentation
4. machine-readable analysis artifacts for edge cases, reason matrices, and replay or disorder cases
5. unit, integration, replay, and disorder tests
6. explicit reason codes and deterministic failure states
7. no placeholder TODOs, no silent fallback logic, and no UI state inferred from query parameters alone

If a task emits a visual contract, board, atlas, or showcase, it must also include:

- an HTML artifact under `docs/frontend/`
- keyboard-accessible interaction design
- reduced-motion support
- adjacent table or list parity for any diagram
- Playwright tests that assert both behavior and visual-state parity when the artifact is interactive

## 6. Cross-task invariants

All tasks in this batch must preserve the following invariants.

- The same `PersistentShell` and same-lineage recovery principle from Phase 0 and Phase 1 still applies.
- Every patient-visible state must derive from authoritative reason codes, capability posture, session posture, return-intent posture, and the latest settled lineage facts. The frontend may soften wording; it may not invent trust outcomes.
- Exact replay of any already-settled action must return the settled result, not open a second session, a second request, a second receipt, or a second safety chain.
- Any telephony or callback flow that loses trust, freshness, release parity, subject match, or route authority must degrade to bounded recovery or read-only posture in the same shell rather than widening access or redirecting blindly.
- Unknown routes, stale fences, mismatched binding versions, mismatched session epochs, superseded grants, replayed redemptions, missing continuity witnesses, or unresolved degradation fail closed.
- No task may treat “authenticated” as meaning “full patient detail is visible”.
- No task may expose routine or calm reassurance while a relevant `EvidenceAssimilationRecord`, `MaterialDeltaAssessment`, `SafetyPreemptionRecord`, `SafetyDecisionRecord`, or `UrgentDiversionSettlement` is still pending.
- One request lineage gets one canonical promotion, one canonical receipt grammar, and one authoritative status projection family.

## 7. Required implementation style

Prefer:

- central policy engines over controller-local checks
- append-only records over in-place mutation where the model calls for history
- compare-and-set fences over optimistic last-write-wins behavior
- typed adapters and typed events over vendor SDK leakage
- deterministic reason codes over ad hoc booleans
- documented state machines and machine-readable matrices over prose-only assumptions
- Playwright-driven browser proof for all frontend work in this batch, especially task `195`

## 8. If the algorithm is incomplete

You must identify and close local gaps while staying faithful to the source algorithm.

When the blueprint implies a needed seam but does not name a durable object, policy table, timeout, or replay rule, introduce the smallest correct artifact and record it with a machine-readable gap-resolution artifact named:

- `GAP_RESOLVED_PHASE2_<AREA>_<TOPIC>.json`

Every gap-resolution artifact must include:
`taskId`, `sourceAmbiguity`, `decisionTaken`, `whyThisFitsTheBlueprint`, `operationalRisk`, and `followUpIfPolicyChanges`.
