# Shared Operating Contract For Prompts 220 To 227

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `212` to `219`.
This batch has three linked jobs:

1. finish the cross-cutting patient/support implementation block by building the remaining staff and support frontends
2. merge, test, and formally gate the whole patient-account plus support baseline against the already-frozen Phase 2 identity and status truth
3. open Phase 3 safely by freezing the first two human-checkpoint contract packs before parallel implementation begins

The tasks covered here are:

- `220_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_staff_start_of_day_operations_and_support_entry_surfaces`
- `221_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_support_workspace_shell_and_omnichannel_ticket_views`
- `222_par_crosscutting_track_Playwright_or_other_appropriate_tooling_frontend_build_support_masking_read_only_fallback_and_contextual_playbook_panels`
- `223_seq_crosscutting_merge_Playwright_or_other_appropriate_tooling_integrate_patient_account_and_support_surfaces_with_phase2_identity_and_status_models`
- `224_seq_crosscutting_Playwright_or_other_appropriate_tooling_testing_run_patient_account_support_and_record_artifact_continuity_suites`
- `225_seq_crosscutting_exit_gate_approve_portal_and_support_baseline_completion`
- `226_seq_phase3_freeze_triage_contract_workspace_state_model_and_review_session_rules`
- `227_seq_phase3_freeze_queue_ranking_fairness_duplicate_cluster_and_more_info_contracts`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `219` as the guaranteed completed foundation for this batch.

You must assume the following earlier work is authoritative and available:

- Phase 1 and Phase 2 request, continuity, identity, telephony, recovery, provider-boundary, and hardening work from `140` to `208`
- the cross-cutting gate and interface registry from `209`
- patient-account backend and frontend work from `210` to `217`
- support lineage, ticket, resend, delivery-repair, and replay foundations from `218` and `219`

The work splits into two internal waves:

### Cross-cutting completion wave

- support entry and workspace frontends: `220` to `222`
- cross-cutting merge, verification, and exit gate: `223` to `225`

### Phase 3 opening wave

- triage and workspace freeze pack: `226`
- queue/fairness/duplicate/more-info freeze pack: `227`

Do not assume later Phase 3 outputs from `228+` already exist.
Those later tasks are downstream consumers of the contract packs you publish here.

If a sibling or future-track output is absent, stale, contradictory, or underspecified, do not block.
Publish the smallest correct seam, adapter, placeholder contract, or compatibility note and record a machine-readable artifact named:

- `PARALLEL_INTERFACE_GAP_CROSSCUTTING_<AREA>.json` for tasks `220` to `225`
- `PARALLEL_INTERFACE_GAP_PHASE3_<AREA>.json` for tasks `226` to `227`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may refine implementation quality, accessibility, browser-proof technique, and shell composition patterns, but they must never override the local model.

Use this priority order:

1. `blueprint/staff-operations-and-support-blueprint.md`
2. `blueprint/operations-console-frontend-blueprint.md`
3. `blueprint/patient-account-and-communications-blueprint.md`
4. `blueprint/patient-portal-experience-architecture-blueprint.md`
5. `blueprint/staff-workspace-interface-architecture.md`
6. `blueprint/callback-and-clinician-messaging-loop.md`
7. `blueprint/phase-3-the-human-checkpoint.md`
8. `blueprint/phase-0-the-foundation-protocol.md`
9. `blueprint/platform-frontend-blueprint.md`
10. `blueprint/platform-runtime-and-release-blueprint.md`
11. `blueprint/accessibility-and-content-system-contract.md`
12. `blueprint/design-token-foundation.md`
13. `blueprint/canonical-ui-contract-kernel.md`
14. `blueprint/forensic-audit-findings.md`
15. validated prompt outputs from `170` to `219`
16. validated prompt outputs from `220` to `227` when physically present and internally coherent

## 3. Mandatory interpretation laws for this batch

### 3.1 Staff start-of-day is a quiet workbench, not a dashboard wall

`/workspace` must foreground one recommended queue, one next-safe action, compact interruptions, and a calm working context.
Do not explode the screen into equal-priority KPI cards, decorative analytics, or a green-health wallpaper.

### 3.2 `/ops/overview` is a live control surface, not BI

The operations entry must obey the quiet mission-control contract from `operations-console-frontend-blueprint.md`:
dense, calm, anomaly-first, intervention-aware, and useful even during partial stale states.
No poster-sized metrics, rotating carousels, or animation-led monitoring theatrics.

### 3.3 Support is a ticket-centric same-shell workspace

Support routes must behave like one governed ticket interface around `SupportTicketWorkspaceProjection`, `SupportLineageBinding`, and `SupportOmnichannelTimelineProjection`.
Do not treat support as loosely related read-only pages, patient pages with relabelled copy, or a second system of record.

### 3.4 Entry surfaces and work surfaces are different products with shared grammar

Entry surfaces are compact, scanning-oriented, and routing-oriented.
Ticket and task work surfaces are anchor-preserving, chronology-preserving, and consequence-oriented.
Do not collapse them into one overloaded everything page.

### 3.5 Same shell, same anchor, same continuity tuple

Across `/workspace/*`, `/ops/*`, `/ops/support/*`, and patient/support cross-links, preserve the current shell when the governing continuity tuple remains valid.
Refresh, deep link, back/forward, replay, observe, or read-only recovery must degrade in place before they eject to detached pages.

### 3.6 Masking, disclosure, and read-only fallback preserve chronology and place

When content is masked, withheld, observe-only, replay-frozen, scope-drifted, or capability-downgraded:

- preserve chronology
- preserve the user’s current anchor where lawful
- preserve the strongest confirmed artifact
- show the shortest safe reacquire or recovery route
- never leak richer data through layout gaps, badges, hover states, or stale caches

### 3.7 Knowledge and playbook assists are governed support actions

`SupportKnowledgeStackProjection`, `SupportKnowledgeAssistLease`, `SupportSubjectContextBinding`, and `SupportContextDisclosureRecord` govern what may be shown and widened.
Do not let macros, playbooks, or history expansion behave like untracked local UI affordances.

### 3.8 Patient and support surfaces must consume the same Phase 2 trust and status truth

No patient route, staff route, support route, or record-artifact surface in this batch may invent its own identity, session, capability, linkage, repair, or request-status semantics.
All such logic must consume the Phase 2 truth already frozen by `170` to `208`.

### 3.9 Merge, test, and gate tasks must remediate repository-owned defects

Tasks `223` to `225` are not reporting exercises.
If the repository fails the algorithm, fix the repository or fail closed.
Do not weaken the suites or soften the gate to make the batch look complete.

### 3.10 Phase 3 freeze tasks are contract-publication tasks

Tasks `226` and `227` must publish machine-readable schemas, registries, formulas, event vocabularies, and bounded state atlases.
They are not the place to improvise implementation shortcuts, UI-only semantics, or local heuristics.

### 3.11 Mock-now and actual-later must stay explicit

Repository-runnable proof, simulator-backed proof, and board/atlas proof are valid when the task explicitly allows them.
Do not mislabel simulator, fixture, or dry-run evidence as live operational evidence.

### 3.12 Playwright is mandatory for browser-visible work

Playwright is mandatory for:

- frontend build tasks `220` to `222`
- merge, continuity, and exit-board tasks `223` to `225`
- interactive atlas boards in `226` and `227`

Other tooling may supplement Playwright, but it may not replace it as the primary browser-proof mechanism.

## 4. Shared design, content, and accessibility laws

### 4.1 Design research is required, not optional

For every browser-facing task in this batch, review a small set of strong references before implementation and document the structural ideas reused.
Good reference classes include:

- regulated service patterns with plain-language focus and bounded recovery
- persistent-shell product architecture patterns
- modern omnichannel support workspace patterns
- data-dense but quiet control-room surfaces

Borrow structure, restraint, and interaction logic.
Do not imitate vendor branding or ship a generic AI-admin look.

### 4.2 Minimalist premium means restrained, not empty

The visual grammar should be:

- calm
- precise
- high-contrast
- editorial where patient-facing
- operational where staff-facing
- roomy enough to feel intentional
- dense enough to be useful
- never neon
- never gamified

### 4.3 Use diagrams only where they improve comprehension

Allowed diagram classes include:

- bottleneck or capacity ribbons on operations entry
- chronology braids on support tickets
- confidence, fairness, and state atlases in architecture boards
- compact lane or dependency diagrams in integration and gate artifacts

Every diagram must have adjacent table/list parity.
No diagram may carry meaning absent from machine-readable or screen-reader-safe parity surfaces.

### 4.4 Accessibility and content rules are non-negotiable

Across browser-facing work:

- use one question or one decision focus per page or stage where that reduces cognitive load
- use a single check-answers moment immediately before confirmation for small or medium multi-step flows when confirmation exists
- show both an error summary and inline field errors for validation failures
- preserve entered values so users can correct errors without retyping
- provide WCAG 2.2-aware keyboard, zoom, contrast, focus, reduced-motion, and screen-reader behavior
- charts, diagrams, and timelines may never be the only path to meaning

## 5. Batch dependency map

### 5.1 `220` finishes the shared staff and support entry layer

`220` consumes `209`, `210`, `211`, `218`, and `219`.
It may ship governed placeholders for not-yet-landed ticket child views from `221` and `222`, but it may not invent alternate support-home semantics.

### 5.2 `221` is the core support shell and omnichannel conversation plane

`221` depends primarily on `218` and `219`, plus the entry-shell grammar from `220`.
It must stay ticket-centric and same-shell, and it must leave masking, read-only fallback, and contextual knowledge widening ready for `222`.

### 5.3 `222` completes masking, fallback, and contextual assists

`222` depends primarily on `218`, `219`, and `221`.
It must not fork ticket-shell anatomy, route laws, or lineage truth.

### 5.4 `223` is the real cross-cutting merge

`223` integrates tasks `210` to `222` with the Phase 2 trust/status kernel.
It must reconcile patient routes, support routes, records, comms, masking, identity-hold, and recovery truth without reopening the already-frozen domain model.

### 5.5 `224` is the definitive cross-cutting suite

`224` runs the browser-visible and backend-visible continuity suites across patient account, support workspace, communications, and record-artifact parity.
It must remediate defects before producing a passing result.

### 5.6 `225` is the formal baseline gate

`225` may approve, constrain, or withhold the patient/support baseline only by using traceable evidence from `210` to `224`.

### 5.7 `226` and `227` open Phase 3 for safe parallel work

`226` must publish the authoritative triage/workspace state pack consumed by `228+`.
`227` must publish the authoritative queue/fairness/duplicate/more-info pack consumed by `228+`.
Neither task may leave core state vocabularies, formulas, or checkpoint laws as prose-only guesses.

## 6. Validation and artifact expectations

Every task in this batch must:

1. cite the exact local source sections it is implementing
2. publish machine-readable contracts where the roadmap implies a durable interface
3. record every important assumption as either:
   - authoritative source trace
   - explicit temporary seam artifact
   - explicit risk or gate finding
4. keep browser-visible artifacts and machine-readable parity surfaces semantically aligned
5. fail closed when a required authority, publication tuple, continuity tuple, or trust slice is missing

## 7. Definition of success for this batch

This batch succeeds only if:

- support entry and workspace fronts now exist as first-class, premium, continuity-safe product surfaces
- patient account, support, records, and communications have been merged and verified against one Phase 2 truth kernel
- the formal cross-cutting exit gate is honest and machine-auditable
- Phase 3 begins from explicit contract packs instead of from implicit local assumptions
