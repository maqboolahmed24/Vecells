# Shared Operating Contract For Prompts 136 To 145

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-135`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch has two responsibilities:
1. close Phase 0 with the final shell/accessibility/preview smoke proof, release-freeze and recovery rehearsals, and the simulator-first foundation completion gate; and
2. open Phase 1 by freezing the intake journey contract, question taxonomy, attachment/quarantine rules, urgent-diversion rulebook, the parallel Phase 1 gate, and the first two backend implementation tracks.

Tasks in this batch:
- `136`: `Playwright_or_other_appropriate_tooling` shell accessibility, preview-environment, and smoke suites
- `137`: `Playwright_or_other_appropriate_tooling` backup/restore, release-freeze, and non-production canary rehearsals
- `138`: Phase 0 exit gate approval
- `139`: Phase 1 web intake journey contract and submission schema lock
- `140`: Phase 1 request-type taxonomy and questionnaire decision tables
- `141`: Phase 1 attachment acceptance, classification, and quarantine contracts
- `142`: Phase 1 red-flag rulebook and urgent-diversion copy
- `143`: Phase 1 parallel-intake tracks gate
- `144`: backend build of `DraftSessionLease` and autosave API
- `145`: backend build of `SubmissionEnvelope` validation and required-field rules

Before executing any task in this batch, verify that the outputs from tasks `001-135` exist, remain internally coherent, and still bind to the canonical blueprint corpus. If a prerequisite artifact is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently re-invent earlier work and pretend the dependency chain is intact.

At minimum, require these upstream outputs to remain usable:
- tasks `001-005`: requirement registry, summary reconciliation, scope boundary, personas/channels/surfaces, and request-lineage model
- tasks `006-010`: glossary, state atlas, dependency inventory, safety/privacy posture, and data-classification posture
- tasks `011-020`: platform baselines, ADRs, milestones, risks, traceability, and the Phase 0 entry gate
- tasks `021-040`: external dependency inventory, simulator-first provider strategy, onboarding assumptions, manual approval checkpoints, and degraded-mode defaults
- tasks `041-061`: repository topology, service/package scaffolds, runtime/publication/freeze strategy, acting-scope model, lifecycle rules, route-intent law, verification ladder, seed-data/simulator strategy, backup-recovery baseline, and the Phase 0 parallel gate
- tasks `062-082`: canonical aggregates, promotion and replay substrate, identity/access/duplicate/lease/settlement/queue/reservation foundations, and the projection worker substrate
- tasks `083-102`: simulator backplanes, runtime foundations, gateway surfaces, CI/CD, observability, publication bundle, schema/backfill runners, degradation execution, topology publication checks, SBOM/signature verification, backup-restore baseline, and non-production canary harness
- tasks `103-120`: token foundation, UI kernel, shared primitives, persistent shells, shell-truth components, selected-anchor law, artifact shell, posture library, accessibility harness, route guards, frontend manifest validation, automation vocabulary, and shell seed routes for patient, staff, ops, hub, governance, and pharmacy surfaces
- tasks `121-135`: assurance packs, privacy/DPIA start, Phase 0 integration merges, synthetic-flow seeding, simulator validation, runtime/publication parity finalization, Phase 0 exit artifacts, and the first mandatory Phase 0 verification suites

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim and sequencing protocol
- `prompt/checklist.md` for canonical task ordering
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for this repo

Authoritative source order:
1. `phase-0-the-foundation-protocol.md` for canonical object law, state axes, lifecycle ownership, submission/promotion law, replay and idempotency law, continuity proof, artifact and outbound-navigation law, freeze/trust/recovery law, accessibility automation markers, and Phase 0 compatibility bridge rules.
2. `platform-frontend-blueprint.md` for shell topology, route families, `PersistentShell`, `SelectedAnchor`, `SurfacePostureFrame`, `FrontendContractManifest`, route continuity evidence, artifact presentation rules, and browser-verification law.
3. `platform-runtime-and-release-blueprint.md` for `RuntimePublicationBundle`, `ReleasePublicationParityRecord`, `AudienceSurfaceRuntimeBinding`, `ReleaseWatchTuple`, `WaveObservationPolicy`, release-watch evidence cockpit, preview-environment posture, canary/rollback law, and restore/readiness evidence.
4. `phase-1-the-red-flag-gate.md` for the canonical Phase 1 intake, draft, questionnaire, attachment, submit, urgent-diversion, and receipt algorithm.
5. `phase-cards.md` for the programme-level Phase 0 and Phase 1 sequencing, mandatory test lists, simulator-first baseline, and phase gate intent.
6. `patient-portal-experience-architecture-blueprint.md`, `patient-account-and-communications-blueprint.md`, `canonical-ui-contract-kernel.md`, `design-token-foundation.md`, `ux-quiet-clarity-redesign.md`, `accessibility-and-content-system-contract.md`, and `uiux-skill.md` for detailed patient-shell continuity, UX, typography, motion, accessibility, announcement, and automation-anchor law.
7. `forensic-audit-findings.md` as mandatory patch law for urgent-diversion state separation, duplicate-review visibility, attachment-quarantine events, continuity-proof discipline, runtime/publication fail-closed behavior, and intake-resume authority.
8. `blueprint-init.md` and `vecells-complete-end-to-end-flow.md` / `.mmd` as top-level cross-phase references that must not override higher-authority source files.

Non-negotiable interpretation rules:
- This batch is not allowed to break the canonical split between `SubmissionEnvelope` and `Request`. Drafts, unsent evidence, and pre-submit continuity remain on the envelope; governed promotion remains the only legal boundary into `Request`.
- `submitted` is a required durable post-promotion state before normalization or synchronous safety completion. No prompt in this batch may collapse that barrier.
- `Request.workflowState`, `Request.safetyState`, and `Request.identityState` remain orthogonal. Phase 1 must not encode urgent, blocked, or degraded truth by overloading workflow milestones.
- `urgent_diversion_required` and `urgent_diverted` are separate durable states. A user-facing urgent screen may appear only after the current safety chain and `UrgentDiversionSettlement` rules are honored.
- `DraftContinuityEvidenceProjection(controlCode = intake_resume)` is the only authority for authoritative `saved`, writable resume, or quiet recovery posture. Local cache or transport success is descriptive only.
- `IntakeExperienceBundle` must pin question semantics for the lifetime of a draft until a governed migration occurs. Mid-draft config promotion may not silently drift required-field meaning, copy meaning, summary meaning, or normalization meaning.
- `ArtifactPresentationContract` and `OutboundNavigationGrant` are mandatory for attachment previews, receipts, urgent-guidance artifacts, print/download handoff, or embedded/browser exits. Raw object-store URLs are forbidden.
- Same-shell continuity is mandatory across step changes, refresh, resume, urgent diversion, receipt, failed-safe recovery, embedded chrome changes, and stale-route recovery while the same lineage remains recoverable.
- Keep `Mock_now_execution` and `Actual_production_strategy_later` separate whenever a task touches simulator-first delivery, future NHS login uplift, future NHS App embedded posture, or later live-provider dependencies. Mock-now means honest simulator-backed behavior with the real contract names. Actual-production strategy means the later live-provider path that must preserve the same public schemas and semantic tuple structure.
- Any browser-viewable artifact in this batch must use `Playwright_or_other_appropriate_tooling` from the start, expose deterministic `data-testid` markers, support keyboard operation, honor reduced-motion, and provide table/list parity for any visual diagram or heatmap.
- Do not ship generic wizard pages, commodity admin dashboards, or decorative marketing gradients. Premium minimalism here means exact hierarchy, quiet confidence, governed recovery, and distinctive product-native surfaces.

Frontend and experience quality law for browser-viewable artifacts in this batch:
- visual language: `Quiet_Clarity_Intake` for patient-facing work and `Release_Proof_Minimal` for release/governance proof surfaces
- tone: premium, calm, exact, health-literate, low-noise, and continuity-aware
- avoid: template-looking steps, giant KPI tiles, consumer-app confetti, toast storms, uncontrolled empty states, or generic red alert screens
- if a fallback token seed is required for fast local rendering before the canonical token package compiles, use this aligned seed and document it as a local bootstrap only:
  - canvas `#F7F8FA`
  - shell `#EEF2F6`
  - panel `#FFFFFF`
  - inset `#E8EEF3`
  - text strong `#0F1720`
  - text default `#24313D`
  - text muted `#5E6B78`
  - border subtle `#D8E0E8`
  - accent live `#2F6FED`
  - accent safe `#117A55`
  - accent pending `#B7791F`
  - accent blocked `#B42318`
  - accent continuity `#5B61F6`
- typography should resolve through the design-token foundation first; if a bootstrap stack is needed for a static atlas, use `Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif` with clear scale steps and never more than three visible sizes per panel region.
- motion should be subtle and functional. Prefer `120-180ms` opacity/elevation/shape transitions for ordinary morphs, `220ms` inspector reveals, and no position-heavy animation in reduced-motion mode.

Validation law across the batch:
- every task must emit machine-readable truth artifacts, not only prose
- every prompt must include explicit `GAP_*`, `ASSUMPTION_*`, `CONFLICT_*`, and `RISK_*` handling instructions
- any browser-viewable deliverable must be tested with `Playwright_or_other_appropriate_tooling` for landmarks, keyboard, responsive behavior, reduced motion, DOM stability, and diagram/table parity
- every runtime-sensitive or continuity-sensitive claim must trace to the current publication/freeze/trust tuple, not to local compile success or simulator optimism
```
