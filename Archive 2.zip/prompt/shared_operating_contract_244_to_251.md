# Shared Operating Contract For Prompts 244 To 251

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `236` to `243`.

This batch has two tightly linked implementation lanes:

1. finish the executable Phase 3 conversation loop across clinician messaging, delivery evidence, reachability repair, patient threading, and support-side failure handling
2. open the executable Phase 3 self-care and bounded admin-resolution kernel across boundary decisions, advice grants, render settlement, subtype policy, and completion-artifact law

All tasks in this batch are backend-first implementation tasks.
Do **not** spend task budget on decorative UI work, generic dashboarding, or placeholder browser flows.
If a task needs a tiny internal diagram or HTML explainer for architecture review, keep it secondary to executable backend code, migrations, validators, and tests.

The tasks covered here are:

- `par_244_phase3_track_backend_build_clinician_message_thread_state_machine_and_delivery_settlement_chain`
- `par_245_phase3_track_backend_build_reachability_repair_bounce_handling_and_controlled_resend_logic`
- `par_246_phase3_track_backend_build_patient_conversation_digest_and_shared_staff_rules`
- `par_247_phase3_track_backend_build_callback_message_visibility_and_patient_threading_projections`
- `par_248_phase3_track_backend_build_support_handoff_and_resolution_linkage_for_callback_and_message_failures`
- `par_249_phase3_track_backend_build_self_care_boundary_decision_and_advice_eligibility_grants`
- `par_250_phase3_track_backend_build_advice_render_settlement_and_content_approval_binding`
- `par_251_phase3_track_backend_build_admin_resolution_case_profiles_waiting_reason_and_completion_artifact_policies`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `243` as the intended completed foundation for this batch.

That foundation includes at minimum:

- the Phase 0 lifecycle, idempotency, mutation-gating, route-intent, evidence, safety, reachability, access-grant, audit, release, recovery, and continuity kernels
- the Phase 1 intake, safety, duplicate, notification, and continuity work
- the Phase 2 identity, auth, telephony, portal, patient-account, support, and cross-channel work
- the Phase 3 freeze packs `226` to `230`
- the Phase 3 backend kernels `231` to `243`, especially:
  - triage state and lease fencing
  - workspace consistency and trust
  - deterministic queueing
  - duplicate review
  - review-bundle assembly
  - more-info cycle and reply assimilation
  - endpoint decision and decision-epoch fencing
  - approval and urgent escalation
  - direct resolution and downstream seed generation
  - reopen mechanics and next-task launch leases
  - task completion continuity evidence
  - callback domain state, attempt windows, and voicemail policy

### If any upstream implementation is missing, empty, or contradictory

Do not block on archive mismatch.
Use this fallback order:

1. local algorithm files under `blueprint/`
2. coherent repository code already implementing the same contract
3. the expected outputs implied by prompts `236` to `243`

When an upstream artifact is logically required but physically absent, publish the smallest correct seam or reconstruction note in a machine-readable file named:

- `PARALLEL_INTERFACE_GAP_PHASE3_<AREA>.json`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, `followUpAction`.

Do not weaken safety, reachability, lease, continuity, or publication rules just because an upstream file is missing.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may improve webhook hygiene, OAuth and recovery-token discipline, provider-boundary handling, content-approval practice, clinical-safety posture, and structured logging, but they must never override the local model.

Use this priority order:

1. `blueprint/phase-3-the-human-checkpoint.md`
2. `blueprint/callback-and-clinician-messaging-loop.md`
3. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
4. `blueprint/phase-0-the-foundation-protocol.md`
5. `blueprint/staff-operations-and-support-blueprint.md`
6. `blueprint/patient-account-and-communications-blueprint.md`
7. `blueprint/patient-portal-experience-architecture-blueprint.md`
8. `blueprint/staff-workspace-interface-architecture.md`
9. `blueprint/platform-runtime-and-release-blueprint.md`
10. `blueprint/phase-9-the-assurance-ledger.md`
11. `blueprint/forensic-audit-findings.md`
12. validated prompt outputs from `170` to `243` when physically present and internally coherent

## 3. Batch dependency map

### 3.1 `244` owns the executable clinician-message domain

Task `244` owns:

- `ClinicianMessageThread`
- `MessageDispatchEnvelope`
- `MessageDeliveryEvidenceBundle`
- `ThreadExpectationEnvelope`
- `ThreadResolutionGate`
- draft, approval, send, deliver, reply, review, close, reopen, and escalate-to-callback rules
- immutable dispatch-chain truth for clinician-message work

Tasks `245`, `246`, `247`, and `248` must integrate with that domain rather than forking message lifecycle logic.

### 3.2 `245` owns communication reachability repair and controlled resend authorization

Task `245` owns:

- message and callback reachability observations derived from bounce, no-answer, invalid-route, dispute, and verification events
- `ReachabilityAssessmentRecord` refresh for communication dependencies
- `ContactRouteRepairJourney` activation and rebound rules for callback or message promises
- controlled resend, channel-change, and callback-reschedule authorization boundaries
- minimal repair-entry grant posture and repair-token rotation

Tasks `246` to `248` may consume repair posture and repair journeys, but they may not infer healthy contact truth from send success or local support notes.

### 3.3 `246` owns digest grammar, composer law, and loop-specific command settlement

Task `246` owns:

- `PatientConversationPreviewDigest`
- `PatientComposerLease`
- `PatientUrgentDiversionState`
- `ConversationCommandSettlement`
- the one-expanded-composer rule
- the shared patient-and-staff mutation receipt grammar for callback or message actions

Task `246` consumes the unified conversation tuple from `247`.
If `247` is not yet landed, `246` must publish or consume an explicit compatibility seam instead of re-deriving thread or visibility truth locally.

### 3.4 `247` owns the unified patient-thread and visibility tuple

Task `247` owns:

- `PatientConversationCluster`
- `CommunicationEnvelope`
- `ConversationSubthreadProjection`
- `ConversationThreadProjection`
- `PatientCommunicationVisibilityProjection`
- `PatientReceiptEnvelope`
- callback/message visibility gating and continuity-bound thread projection rules

Task `247` must produce the authoritative tuple that `246` consumes for digest and settlement calmness.
Thread, visibility, and receipt tuple drift must freeze posture instead of being smoothed away.

### 3.5 `248` owns support linkage and failure-resolution binding for callback and message work

Task `248` owns:

- communication-failure support handoff seeds
- support-lineage linkage for callback or message repair
- communication-specific use of `SupportActionRecord`, `SupportActionSettlement`, and `SupportResolutionSnapshot`
- manual-handoff and stale-recoverable linkage for callback/message failures
- provenance-safe support summaries and resolution artifacts

Task `248` must consume `219`, `243`, `244`, and `245`; it may not rebuild support foundations from scratch.

### 3.6 `249` owns self-care boundary classification and advice grant issuance

Task `249` owns:

- `SelfCareBoundaryDecision`
- `AdviceEligibilityGrant`
- boundary-tuple hashing and supersession
- advice-eligibility issuance, invalidation, and expiry rules
- legal self-care versus bounded-admin versus clinician-review classification

Tasks `250` and `251` must consume that boundary rather than softening it into wording or subtype labels.

### 3.7 `250` owns advice render settlement and content-approval binding

Task `250` owns:

- `ClinicalContentApprovalRecord`
- `ContentReviewSchedule`
- `AdviceBundleVersion`
- `AdviceVariantSet`
- `AdviceRenderSettlement`
- content-version, approval, publication, and trust binding for visible advice

Task `250` consumes grants from `249`.
It must not let stale or superseded content remain renderable through browser convenience, template caches, or unbound artifacts.

### 3.8 `251` owns admin-resolution subtype and completion-artifact policy

Task `251` owns:

- `AdminResolutionCase`
- `AdminResolutionSubtypeProfile`
- `AdminResolutionCompletionArtifact`
- waiting-reason policy
- completion-artifact policy
- subtype reclassification law and bounded admin-case opening rules

Task `251` must leave dependency evaluation to `252`, patient expectation template bodies to `253`, and final admin settlement or cross-domain re-entry to `254`.

## 4. Mandatory interpretation laws for this batch

### 4.1 Dispatch, delivery evidence, repair, and closure are different authorities

Do not collapse:

- transport acceptance
- delivery evidence
- delivery risk
- reply expectation
- repair posture
- callback expectation
- authoritative review outcome
- final closure

Each requires its own durable authority.

### 4.2 `MessageDispatchEnvelope` is immutable and fence-bound

Duplicate taps, retries, provider replay, or support repair retries that hit the same dispatch fence must reuse the same envelope.
A second live send is forbidden unless the governing gate explicitly authorizes a fresh effect.

### 4.3 `ThreadExpectationEnvelope` is the sole patient-facing message expectation source

Reply-needed, awaiting-review, delivery-repair, review-complete, and closed copy must advance only through `ThreadExpectationEnvelope` or later projection tuples built from it.
Do not infer patient posture from worker state, queue chips, or delivery callbacks alone.

### 4.4 `ThreadResolutionGate` and `CallbackResolutionGate` are the only terminal authorities

Message closure, reopen, callback escalation, callback closure, and repair-route authorization must come through the canonical gates.
No worker, controller, support receipt, or provider webhook may close the loop directly.

### 4.5 Reachability truth comes only from `ReachabilityAssessmentRecord`

Transport acceptance, send attempts, CRM notes, mutable demographics, or provider success hints are not current route truth.
Only append-only reachability assessment on the current route snapshot may decide whether a callback or message promise is clear, at risk, blocked, or disputed.

### 4.6 One current conversation tuple governs calmness

Preview digest, open-thread state, callback status, visibility posture, receipt copy, continuity evidence, and composer affordance must all bind the same current conversation tuple or fail closed into bounded pending, placeholder, or recovery posture.

### 4.7 `DecisionEpoch` remains the sole consequence fence for self-care and admin work

Self-care issue, advice render, admin follow-up opening, admin waiting, patient notification, and admin completion may proceed only while the current unsuperseded `DecisionEpoch`, `lineageFenceEpoch`, and derived `boundaryTupleHash` all still match.

### 4.8 `SelfCareBoundaryDecision` is the sole classifier

Route labels, summary copy, endpoint names, subtype names, or patient-safe wording may soften presentation, but they may not redefine whether work is informational self-care, bounded admin-resolution, or clinician-governed review.

### 4.9 `AdviceEligibilityGrant` is not the same thing as visible advice

Grant issuance only proves that advice *may* be rendered on the current tuple.
Visible advice still requires `AdviceRenderSettlement`, current approval, current publication, current trust, and current boundary compatibility.

### 4.10 `AdminResolutionSubtypeProfile` and `AdminResolutionCompletionArtifact` must stay typed

Generic “waiting” and generic “completed” states are forbidden.
Every waiting posture needs a declared dependency shape, owner, SLA clock source, and expiry or repair rule.
Every completion posture needs a typed artifact and patient-visible expectation binding.

### 4.11 `LifecycleCoordinator` remains the only request-closure authority

Message completion, callback completion, advice render, admin follow-up, support repair, and transport success may settle their own domains, but only `LifecycleCoordinator` may close the parent request.

### 4.12 Every externally triggerable mutation must be idempotent and fence-checked

At minimum, mutating commands in this batch must validate the live tuple required for the action, including where applicable:

- `ownershipEpoch`
- `fencingToken`
- `ReviewActionLease`
- current thread or callback version
- `lineageFenceEpoch`
- `decisionEpochRef`
- current `boundaryTupleHash`
- current publication and trust tuple
- current route or reachability epoch

### 4.13 Transactional outbox or equivalent single-authority publication is mandatory

Whenever a mutation both changes durable domain state and emits events, notifications, support-handoff work, resend jobs, or provider calls, use one transactional outbox or equivalent authoritative publication mechanism.
Do not dual-write.

### 4.14 Provider callbacks are evidence inputs, not business truth

Provider delivery updates, status callbacks, bounces, read receipts, and voice call statuses may widen delivery or reachability posture, but they may not directly imply reviewed, settled, closed, or safe-to-resend business truth.

### 4.15 Webhook and metadata hygiene are mandatory

Webhook endpoints must use HTTPS, validate provider signatures, and fail closed on unsigned, invalid, stale, or ambiguous callbacks.
Do not place PHI, contact details, raw transcripts, or sensitive identifiers into provider metadata fields that are not treated as protected data.

### 4.16 Logs and audit are separate concerns

Keep append-only domain audit for causal truth.
Keep operational or security logs for diagnostics.
Mask or avoid secrets, tokens, PHI, contact details, draft bodies, transcript text, and sensitive identifiers in logs whenever audit references or structured hashes suffice.

### 4.17 Continuity evidence governs calm patient or support posture

Patient conversation calmness, support repair reassurance, and same-shell recovery posture may advance only from current continuity evidence plus current settlement chain.
Local acknowledgement, queue refresh, or provider acceptance is insufficient.

## 5. Shared engineering requirements

### 5.1 Clock discipline

Persist authoritative server timestamps in UTC.
If quiet hours, local-time display, callback windows, or reminder language need timezone context, persist the resolved policy context used for that calculation.

### 5.2 Idempotency and compare-and-set

Every externally triggerable mutating command in this batch must be idempotent.
Duplicate patient submits, duplicate support clicks, worker retries, webhook replays, or stale browser retries must either reuse the same authoritative record or fail closed without creating a second side effect.

### 5.3 Property, concurrency, and replay testing are mandatory

Every task in this batch must include property or state-machine tests and at least one concurrency or replay suite covering stale fences, duplicate submit, worker retry, or callback/message replay.

### 5.4 Migrations must be forward-safe

Schema changes must be additive or carefully staged.
Do not require destructive migration to satisfy this batch.
If rollback needs choreography, publish explicit rollback notes and compatibility guards.

### 5.5 Worker and scheduler safety

Reminder, resend, callback, repair, visibility-refresh, and projection-refresh workers must be restart-safe and horizontally safe.
No in-memory queue or timer may be the sole authority for patient-visible truth.

### 5.6 Content and policy bundles are versioned objects

Advice bundles, variant sets, completion-artifact policies, waiting-reason policies, and subtype profiles must be versioned or safely referenceable.
Never let mutable prose blobs silently redefine a past settlement.

## 6. External implementation posture that may improve the code but not override the algorithm

Use current best practice where it helps, but keep the local blueprint authoritative:

- modern OAuth and recovery-token handling consistent with current OAuth 2.0 security best practice
- structured authorization, session, and logging discipline consistent with OWASP guidance
- official provider SDK or supported signature-validation methods for webhook verification
- signed email-event webhook verification and public-key retrieval for SendGrid-style event streams when email delivery evidence is in scope
- NHS assurance and clinical-safety posture for consequence-bearing patient communications and advice issuance

## 7. Batch-level acceptance expectations

Before any task in this batch is considered done, verify that:

1. no patient-facing calmness or reply-readiness is inferred from transport-only success
2. no resend or callback reschedule path can create two live external effects for the same governing fence
3. stale boundary tuples, stale grants, stale thread tuples, stale route epochs, and stale support bindings fail closed into recovery rather than mutating
4. advice or admin consequence cannot proceed on a superseded `DecisionEpoch`
5. support, patient, and staff projections can all explain the same underlying causal chain without forking chronology or provenance
6. machine-readable gap files exist for any intentionally deferred sibling surface rather than silently weakening the contract
