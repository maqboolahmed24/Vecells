# Shared Operating Contract For Prompts 252 To 259

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `244` to `251`.

This batch finishes the self-care and bounded admin-resolution backend consequence chain, then turns the same source-of-truth contracts into the first real staff-workspace frontend surfaces for Phase 3.

The tasks covered here are:

- `par_252_phase3_track_backend_build_advice_admin_dependency_sets_and_reopen_trigger_evaluation`
- `par_253_phase3_track_backend_build_self_care_outcome_analytics_and_patient_expectation_templates`
- `par_254_phase3_track_backend_build_admin_resolution_settlement_and_cross_domain_reentry_rules`
- `par_255_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_workspace_home_queue_and_task_route_family`
- `par_256_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_queue_workboard_preview_pocket_and_selected_anchor_preservation`
- `par_257_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_active_task_shell_case_pulse_and_decision_dock`
- `par_258_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_rapid_entry_notes_more_info_and_endpoint_reasoning_layer`
- `par_259_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_attachment_viewer_and_patient_response_thread`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `251` as the intended completed foundation for this batch.

That foundation includes at minimum:

- Phase 0 shell, route, artifact, mutation, continuity, publication, release, and audit law
- Phase 1 intake, safety, duplicate, and notification foundations
- Phase 2 identity, session, patient shell, and cross-channel continuity work
- Phase 3 backend kernels `232` to `251`, especially:
  - `232` workspace consistency projection and trust envelope
  - `233` deterministic queue rank snapshots and assignment suggestions
  - `235` review-bundle assembly and `EvidenceDeltaPacket`
  - `236` more-info cycle, reply-window checkpoint, and reminders
  - `237` response assimilation, material delta assessment, and canonical re-safety
  - `238` endpoint decision engine and `DecisionEpoch`
  - `239` approval checkpoint and urgent escalation
  - `240` direct resolution and downstream handoff seed generation
  - `241` reopen mechanics, stale-owner recovery, and next-task launch leases
  - `242` task completion settlement and workspace continuity evidence
  - `243` callback domain state machine
  - `244` clinician-message thread state machine
  - `245` reachability repair and controlled resend logic
  - `246` patient-conversation digest and shared mutation-settlement grammar
  - `247` callback/message visibility and patient-threading projections
  - `248` support linkage for communication failures
  - `249` self-care boundary decision and advice eligibility grants
  - `250` advice render settlement and content-approval binding
  - `251` admin-resolution subtype, waiting-policy, and completion-artifact policy

### If any upstream implementation is missing, empty, or contradictory

Do not block on archive mismatch.

Use this fallback order:

1. local algorithm files under `blueprint/`
2. coherent repository code already implementing the same contract
3. the expected outputs implied by prompts `232` to `251`

When an upstream artifact is logically required but physically absent, publish the smallest correct seam or reconstruction note in a machine-readable file named:

- `PARALLEL_INTERFACE_GAP_PHASE3_SELFCARE_WORKSPACE_<AREA>.json`

Every such artifact must include:

- `taskId`
- `missingSurface`
- `expectedOwnerTask`
- `temporaryFallback`
- `riskIfUnresolved`
- `followUpAction`

Do not weaken continuity, decision-epoch, boundary, publication, trust, reachability, or artifact-presentation law just because an upstream file is missing.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may improve UI craft, dense-table ergonomics, content clarity, and general frontend or security discipline, but they must never override the local model.

Use this priority order:

1. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
2. `blueprint/staff-workspace-interface-architecture.md`
3. `blueprint/phase-3-the-human-checkpoint.md`
4. `blueprint/phase-0-the-foundation-protocol.md`
5. `blueprint/platform-frontend-blueprint.md`
6. `blueprint/canonical-ui-contract-kernel.md`
7. `blueprint/design-token-foundation.md`
8. `blueprint/patient-account-and-communications-blueprint.md`
9. `blueprint/patient-portal-experience-architecture-blueprint.md`
10. `blueprint/callback-and-clinician-messaging-loop.md`
11. `blueprint/platform-runtime-and-release-blueprint.md`
12. `blueprint/phase-9-the-assurance-ledger.md`
13. validated prompt outputs from `108`, `109`, and `232` to `251` when physically present and internally coherent

## 3. Batch dependency map

### 3.1 `252` owns dependency-state truth and reopen-trigger evaluation for self-care and bounded admin work

Task `252` owns:

- `AdviceAdminDependencySet`
- canonical dependency-state evaluation
- blocker classification and dominant recovery route derivation
- reopen-trigger and clinical-reentry-trigger evaluation
- the rule that stale or unstable dependencies freeze advice/admin consequence

Tasks `253` and `254` may consume dependency truth, but they may not redefine whether bounded admin work is still legal.

### 3.2 `253` owns outcome analytics and patient-expectation template bodies

Task `253` owns:

- advice/admin outcome analytics records and watch-window analytics joins
- patient expectation template bodies and registry discipline
- template versioning, locale/channel variants, and expectation rendering inputs
- follow-up watch analytics linkage for self-care and bounded admin consequence

Task `253` must not use analytics as a substitute for operational settlement authority.

### 3.3 `254` owns final admin settlement and cross-domain re-entry

Task `254` owns:

- `AdminResolutionSettlement`
- authoritative result progression for notify, wait, complete, reopen, and stale-recoverable postures
- cross-domain re-entry rules when the boundary reopens or bounded admin work becomes illegal
- settlement-driven update of patient/staff projections and downstream relaunch or requeue rules

Tasks `252` and `253` publish required inputs, but only `254` may finalize admin consequence.

### 3.4 `255` owns the real workspace shell and route family

Task `255` owns:

- `/workspace`, queue, task, more-info, decision, approvals, escalations, changed, and search route-family shelling
- `WorkspaceNavigationLedger`, route adjacency, and shell continuity posture for those routes
- `WorkspaceHomeProjection` rendering
- the shared shell band, nav rail, status strip, and route-family DOM contract

Tasks `256` to `259` build deeper surfaces inside that shell and must not invent detached route families.

### 3.5 `256` owns the queue workboard, preview pocket, and queue-anchor continuity

Task `256` owns:

- `QueueWorkbenchProjection`
- `QueueScanSession`
- `QueuePreviewDigest`
- row grammar, preview-pocket behavior, virtualization, and anchor preservation
- selected-row continuity through reordering, live changes, and open-task transitions

Task `256` consumes the shell and route contracts from `255` and the selected-anchor law from `108`.

### 3.6 `257` owns the active task shell, `CasePulse`, and `DecisionDock`

Task `257` owns:

- `TaskWorkspaceProjection`
- `TaskCanvasFrame`
- task-plane stack composition
- `CasePulse`
- shared status strip integration for active review
- sticky `DecisionDock`
- one-promoted-support-region law inside the task shell

### 3.7 `258` owns rapid-entry composition, more-info side stage, and endpoint reasoning

Task `258` owns:

- `QuickCaptureTray`
- `RapidEntryDraft`
- the more-info and endpoint reasoning child-route layer
- autosave and focus-protection behavior for note entry, reason chips, question sets, consequence preview, and more-info send
- same-shell stale-epoch and stale-lease freeze posture while composing or previewing

### 3.8 `259` owns the attachment viewer and patient-response thread inside the task shell

Task `259` owns:

- attachment digest cards and heavy-viewer entry
- staff-side patient-response thread surface inside the active workspace shell
- artifact viewer integration through the shared artifact shell from `109`
- conversation and visibility projection rendering using tasks `244` to `247`

Task `259` must stay same-shell and summary-first; it may not create detached file pages or message-center detours.

## 4. Mandatory interpretation laws for this batch

### 4.1 `SelfCareBoundaryDecision` remains the sole classifier

Route labels, copy, localized wording, subtype names, UI grouping, and analytics labels may soften presentation, but they may not redefine whether the request is informational self-care, bounded admin-resolution, or clinician-governed review.

### 4.2 `AdviceAdminDependencySet` is the sole reopen fence for advice/admin consequence

Transport acceptance, support notes, local repair banners, or analytics anomalies may explain the situation, but only the canonical dependency set may say whether bounded admin action is still legal or whether the request has crossed back into clinician-governed review.

### 4.3 `DecisionEpoch` remains the sole writable consequence fence

Advice render, admin waiting, admin completion, endpoint preview, approval, escalation, more-info send, and next-task launch may proceed only while the current live `DecisionEpoch` still matches the governing review version, selected anchor, lineage fence, publication tuple, and trust tuple.

### 4.4 `AdminResolutionSettlement` is the sole authoritative admin outcome record

Local receipts, queue-row wording, projection refresh, or internal completion notes do not equal authoritative completion.
Only `AdminResolutionSettlement` may move admin consequence to `patient_notified`, `waiting_dependency`, `completed`, `reopened_for_review`, `blocked_pending_safety`, or `stale_recoverable`.

### 4.5 Analytics are not authority

Outcome analytics, watch windows, click/open counters, or patient-read signals may inform review and improvement, but they may not authorize self-care display, admin completion, or route-level calmness by themselves.

### 4.6 Patient expectation wording must be versioned, typed, and tuple-bound

Expectation text may not be handwritten inline in workers or UI components.
Template selection must be explicit, versioned, locale/channel aware, and bound to the current `boundaryTupleHash`, subtype, artifact type, and visibility posture.

### 4.7 Queue preview is read-only and summary-first

Preview may not mint `ReviewActionLease`, clear changed-since-seen state, hydrate heavy media, or impersonate explicit task-open.

### 4.8 One current workspace shell must preserve continuity

Queue switches, task open, more-info, decision, approvals, escalations, attachment view, and patient-response thread must remain inside one current staff shell while the `workspaceShellContinuityKey` stays valid.

### 4.9 `DecisionDock` is the only dominant commit-ready action region while a task is open

Rows, side stages, support panes, attachment viewers, and assistive or reasoning stubs may offer secondary affordances, but they may not fragment or duplicate the dominant commit path.

### 4.10 Selected anchors and quiet return are governed state, not browser accidents

Queue row, task section, composer insertion point, compare target, viewer focus, and child-route return must bind the authoritative navigation and anchor contracts.
Do not let browser history, hover coincidence, or list re-render decide continuity.

### 4.11 Attachment and thread surfaces are summary-first and contract-governed

Inline digest cards and governed viewers come before bytes, print, or browser handoff.
Visibility, delivery, repair, and reply disposition must derive from the authoritative conversation tuple and artifact contract rather than from ad hoc UI state.

### 4.12 Publication and trust drift must fail closed in place

If trust degrades, publication parity breaks, visibility narrows, or release posture freezes, keep the same shell, preserve the last safe summary, and degrade to read-only, placeholder, or recovery posture.
Do not silently hide relevant context or leave stale controls armed.

## 5. Shared engineering requirements

### 5.1 Backend requirements for `252` to `254`

At minimum:

- explicit domain services and immutable records for dependency, analytics/template, and settlement work
- idempotent command handling with compare-and-set validation on the current tuple
- append-safe audit and transactional outbox or equivalent authoritative publication path
- UTC timestamps with explicit policy-context persistence where local-time interpretation matters
- bounded PHI and PII handling, least-privilege data access, and secret-safe operational logs
- property tests, replay tests, stale-fence tests, and concurrency tests
- forward-safe migrations and restart-safe workers

### 5.2 Frontend requirements for `255` to `259`

At minimum:

- Playwright is mandatory for development and testing
- production code must consume authoritative projections and mutation contracts, not mock-only state
- all surfaces must publish canonical DOM attributes from `canonical-ui-contract-kernel.md`
- virtualization or chunked loading is mandatory where the blueprint requires it
- reduced-motion parity, keyboard parity, focus safety, and screen-reader parity are mandatory
- same-shell recovery must preserve selected anchor, last safe summary, and dominant next action when lawful
- local visual experiments belong in atlas/showcase files, but the repository must also land real route components and tests

### 5.3 Design-token and layout discipline

Use the shared token graph first.
If the graph is missing a semantic or component token, extend the shared graph centrally instead of hard-coding route-local values.

Use the canonical breakpoints and pane tokens, especially:

- breakpoints `xs`, `sm`, `md`, `lg`, `xl`, `2xl`
- shell rail collapsed `72`
- shell rail expanded `280`
- `support.peek = 320`
- `support.open = clamp(320px, 28vw, 400px)`
- `drawer.inline = clamp(360px, 33vw, 480px)`

### 5.4 Visual research posture for frontend tasks

For tasks `255` to `259`, review current official design references before coding and document which interaction ideas were adapted or rejected.
Use them as inspiration only; the local blueprint stays authoritative.

Study at minimum:

- official Linear design writing for quiet hierarchy, reduced visual noise, and the principle that structure should feel present without turning into heavy chrome
- official Vercel dashboard/design material for streamlined sidebar navigation and system-level craft
- official IBM Carbon data-table guidance for dense scanning, toolbar/search behavior, row hover, and width discipline
- official NHS design-system and content-manual guidance for accessibility, consistency, and clear service writing

If a research cue conflicts with the blueprint, reject the cue and explain why in the task’s design notes.

### 5.5 Charts, diagrams, and logo usage

The user wants premium, distinctive surfaces, but the local algorithm forbids gratuitous dashboards.

Therefore:

- do not add production charts where the blueprint explicitly forbids them, such as charts on first-load `WorkspaceHome`
- prefer micro-diagrams, tension bars, timeline ladders, queue-rhythm maps, or compact numeric digests only where the blueprint and current projection support them
- place richer explanatory diagrams in the atlas/showcase documentation for each frontend task
- a minimal route-family crest, workspace monogram, or artifact glyph is allowed if it is quiet, non-brand-confusing, and secondary to the task information

### 5.6 No generic AI-product styling

The frontend tasks must not degenerate into:

- glassmorphism dashboards
- giant empty hero cards
- multi-gradient “AI assistant” panels
- overly saturated chip soup
- speculative analytics that are not sourced from the current projection
- detached wizard flows that break the same-shell law

## 6. Batch-level acceptance expectations

Before any task in this batch is considered done, verify that:

1. bounded admin work cannot continue once the dependency set or boundary tuple becomes unstable
2. analytics and expectation templates do not substitute for authoritative advice/admin settlement
3. admin completion cannot happen without the authoritative settlement and matching completion artifact or expectation binding
4. queue preview remains read-only and does not mint review authority
5. `/workspace/task/:taskId/more-info` and `/workspace/task/:taskId/decision` remain soft child routes of the same shell
6. the active task shell has one dominant action lane and preserves superseded context on delta-first resume
7. protected composition retains drafts, selected anchor, and quiet-return targets when drift invalidates the current lease or epoch
8. attachment and thread surfaces stay same-shell, summary-first, and visibility-safe
9. every frontend task lands real Playwright suites, not screenshots without behavioral proof
10. any intentionally deferred sibling surface is recorded in a machine-readable gap file instead of being silently flattened into generic fallback behavior
