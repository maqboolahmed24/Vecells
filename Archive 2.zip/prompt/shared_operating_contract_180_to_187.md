# Shared Operating Contract For Prompts 180 To 187

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `172` to `179`. This batch finishes the Phase 2 identity control plane that sits on top of the already-frozen trust, auth, session, linkage, evidence-vault, and binding-authority seams, and it opens the first production-shaped telephony ingress surface.

The tasks covered here are:

- `180_par_phase2_track_identity_build_capability_decision_engine_and_scope_envelope_rules`
- `181_par_phase2_track_identity_build_request_claim_redemption_and_access_grant_supersession_workflows`
- `182_par_phase2_track_identity_build_wrong_patient_identity_repair_signal_freeze_and_release_chain`
- `183_par_phase2_track_identity_build_optional_pds_adapter_and_feature_flagged_enrichment_flow`
- `184_par_phase2_track_identity_build_signed_in_request_ownership_and_patient_ref_derivation_rules`
- `185_par_phase2_track_identity_build_authenticated_portal_projection_and_status_access_controls`
- `186_par_phase2_track_identity_build_audit_and_masking_for_identity_events_and_claims`
- `187_par_phase2_track_telephony_build_telephony_edge_and_webhook_ingestion_service`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `174` as the only guaranteed completed foundation for this batch.

You **must** assume the following earlier work is already authoritative and available:

- `170` trust contract and capability-gate freeze
- `171` NHS login auth transaction and local session contracts
- `172` patient-linkage, match-model, and optional PDS seam freeze
- `173` telephony call-session and evidence-readiness contract freeze
- `174` Phase 2 shared interface registry and parallel gate

Tasks `175` to `179` are in the same broader Phase 2 parallel block but are **not guaranteed** to exist when any one of these prompts is executed. If outputs from `175` to `179` are present and coherent, consume them. If they are absent, stale, or contradictory, do **not** block. Instead, publish the smallest correct seam, contract, or adapter needed for your task and record a machine-readable gap artifact named with the form:

- `PARALLEL_INTERFACE_GAP_PHASE2_<AREA>.json`

Every such gap artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, and `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth. External guidance refines implementation quality but never overrides the local model.

Use this priority order:

1. `blueprint/phase-2-identity-and-echoes.md`
2. `blueprint/phase-0-the-foundation-protocol.md`
3. `blueprint/patient-account-and-communications-blueprint.md`
4. `blueprint/platform-frontend-blueprint.md`
5. `blueprint/patient-portal-experience-architecture-blueprint.md`
6. `blueprint/callback-and-clinician-messaging-loop.md`
7. `blueprint/runtime-and-release-blueprint.md`
8. `blueprint/forensic-audit-findings.md`
9. Prompt outputs from `170` to `174`
10. Prompt outputs from `175` to `179` when present and internally coherent

## 3. Phase-2 interpretation laws

The following interpretations are mandatory across every task in this batch.

### 3.1 Identity, auth, linking, capability, session, grant, claim, ownership, and repair are separate concepts

Do not collapse them.

- NHS login authentication identifies a subject.
- Patient matching/linking estimates which patient record is most likely associated with that subject.
- `CapabilityDecision` sets a ceiling for what the current session and route may show or attempt.
- `Session` and `SessionEstablishmentDecision` define the current local runtime posture.
- `AccessGrant` and `AccessGrantScopeEnvelope` govern bounded access and continuation links.
- `IdentityBindingAuthority` is the only authority that can advance durable patient binding or ownership state.
- Wrong-patient correction is not a request state; it is an identity-repair control path with freeze and release settlement.

### 3.2 Capability is a ceiling, not a mutation permit

`CapabilityDecision` may support:
`allow | step_up_required | recover_only | deny`

That verdict **never** by itself authorizes a write.

Any authenticated or link-driven write path must also validate, at minimum:

- current `Session`
- current `SessionEstablishmentDecision`
- current `RouteIntentBinding`
- current `subjectBindingVersion`
- current `sessionEpoch`
- current `LineageFence`
- current `AccessGrantScopeEnvelope` when grant-backed
- current route family, action scope, governing object, release posture, and channel posture

Unknown or unclassified routes deny by default.

### 3.3 Patient identity is authority-derived and append-only

`IdentityBindingAuthority` is the sole durable writer of:

- binding versions
- `bindingState`
- `ownershipState`
- derived `patientRef`
- `subjectBindingVersion`

`PatientLink` is derived, not authoritative.

`Request.patientRef` and `Episode.patientRef` may only change in the same transaction that the authority settles a new binding or correction.

### 3.4 Grants are always envelope-bound and exact-once settled

Every redeemable grant must carry an immutable `AccessGrantScopeEnvelope`.

Every terminal redemption, replacement, rotation, revocation, or supersession must settle via:

- `AccessGrantRedemptionRecord`
- `AccessGrantSupersessionRecord`

Duplicate clicks, replays, refreshes, and cross-device retries must resolve to the already-settled result rather than creating new side effects.

### 3.5 Wrong-patient repair is freeze-first and release-later

When wrong-patient suspicion or confirmed misbinding is raised:

- open or reuse an `IdentityRepairCase`
- settle an `IdentityRepairFreezeRecord`
- advance the lineage fence
- terminate or rotate stale sessions
- supersede live PHI-bearing and transactional grants
- supersede route intents
- freeze non-essential communications
- degrade patient-visible and operator-visible projections to safe hold/recovery surfaces
- only release via a single `IdentityRepairReleaseSettlement`

### 3.6 Optional PDS is bounded and never replaces local authority

PDS access is optional, feature-flagged, onboarding-gated, and legal-basis-aware.

It may enrich confidence and demographics within the boundaries frozen by `172`, but it must not:

- replace the local matching model
- silently overwrite local communication preferences
- treat NHS login contact claims as equivalent to PDS or GP data
- mutate durable patient ownership or patient binding directly

### 3.7 Telephony providers end at the edge

Vendor webhooks and vendor payloads must terminate at the telephony edge.

Inside the platform, only canonical telephony events, typed contract objects, and platform refs may flow deeper.

Do not leak raw provider payloads, vendor URLs, or vendor-specific state into the broader domain model.

## 4. External guidance that may refine implementation

Use the following sources only to strengthen implementation details and security posture. They do not override the local blueprint.

- Official NHS login guidance for consent, age controls, branding, subject data scopes, and the rule that partner services own session management and logout.
- Official NHS login guidance that contact details in NHS login are not equivalent to PDS or GP data and that the same phone number can be used on more than one NHS login account.
- Official PDS access and PDS FHIR guidance for onboarding, legal basis, direct-care use, and demographic retrieval boundaries.
- Official PDS notifications guidance for change feeds, NEMS or MESH delivery, and local authentication and authorization expectations.
- OAuth 2.0 Security Best Current Practice and PKCE guidance for authorization-code flow hardening, replay resistance, transaction binding, and nonce validation.
- OWASP guidance on authorization, session management, logging, cryptographic storage, key management, TLS, and authentication.
- Official provider webhook guidance, including request-signature validation and fast acknowledgment behavior, if you choose a concrete telephony provider adapter such as Twilio.

## 5. Delivery format rules

Every prompt in this batch must produce all of the following:

1. Production-shaped code, not pseudocode.
2. Contract-first schema or interface artifacts for every new durable object or external seam.
3. Architecture and security docs tied to the exact task.
4. Machine-readable analysis artifacts showing edge cases, policy tables, and replay matrices.
5. Tests at unit, integration, and replay/idempotency levels.
6. Explicit reason codes and deterministic failure states.
7. No placeholder TODOs, no “future work” comments in implementation paths, and no silent fallback logic.

If a task includes a visual contract or diagnostic atlas, it must also include:

- an HTML artifact under `docs/frontend/`
- keyboard-accessible interaction design
- reduced-motion support
- Playwright tests that assert both behavioral correctness and visual-state parity

## 6. Cross-task invariants

All tasks in this batch must preserve the following invariants.

- The same `PersistentShell` and same-lineage recovery principle from Phase 1 still applies.
- Public, authenticated, embedded, support, and operator audiences must resolve through explicit visibility policy and coverage rows, not controller-local trimming.
- Raw PHI, tokens, claims, NHS numbers, full phone numbers, vendor webhook payloads, and evidence blobs must not appear in logs, traces, metric labels, URLs, HTML, screenshots, queue names, or alert text. Use refs, hashes, and masked fragments only.
- Every decision that affects read scope, write scope, claim scope, or repair scope must be auditable with policy version, route tuple, binding version, session epoch, and a reason-code set.
- Exact replay of any already-settled action must return the settled result.
- Unknown routes, stale fences, mismatched binding versions, mismatched session epochs, expired scope envelopes, or release mismatches must degrade to `recover_only`, `step_up_required`, or `deny`, never optimistic allow.

## 7. Playwright rule for this batch

Use Playwright whenever a task includes any HTML, browser-delivered state atlas, operator diagnostic surface, or projection-driven UI contract. For backend-only tasks, browser automation is not mandatory unless you build a supporting diagnostic HTML artifact.

## 8. What “done” means for this batch

A task in this batch is only complete when:

- its code follows the local blueprint literally where the blueprint is explicit
- all newly introduced contracts are versioned and machine-readable
- replay, duplicate, stale, and race conditions are proven by tests
- the task publishes any temporary sibling-gap seam explicitly
- the outputs can be consumed by later tasks without inventing missing semantics
