# Shared Operating Contract For Prompts 156 To 163

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-155`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch has one responsibility:
finish the real patient-facing Phase 1 web intake experience so the first live request journey behaves like one governed, premium, same-shell product from first answer through save, upload, contact preference, urgent diversion, receipt, status tracking, sign-in uplift, refresh, and resume recovery.

Tasks in this batch:
- `156`: `Playwright_or_other_appropriate_tooling` request-type selection and progressive question flow
- `157`: `Playwright_or_other_appropriate_tooling` quiet autosave status strip and resume states
- `158`: `Playwright_or_other_appropriate_tooling` file-upload evidence states and error recovery
- `159`: `Playwright_or_other_appropriate_tooling` contact-preference editor and confirmation-copy truth
- `160`: `Playwright_or_other_appropriate_tooling` same-shell urgent-diversion surface
- `161`: `Playwright_or_other_appropriate_tooling` same-shell receipt and ETA surface
- `162`: `Playwright_or_other_appropriate_tooling` minimal track-my-request page
- `163`: `Playwright_or_other_appropriate_tooling` sign-in uplift, refresh, and resume postures

Before executing any task in this batch, verify that the outputs from tasks `001-155` exist, remain internally coherent, and still bind to the canonical blueprint corpus. If a prerequisite artifact is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently replace earlier decisions with new local interpretation.

At minimum, require these upstream outputs to remain usable:
- tasks `001-020`: programme scope, glossary, state atlas, safety/privacy posture, dependency inventory, traceability, and governance baselines
- tasks `021-040`: simulator strategy, dependency/mock posture, degraded defaults, and delivery sequencing
- tasks `041-061`: repository topology, runtime/release/publication, lifecycle, tenancy, and mutation-gate foundations
- tasks `062-102`: canonical aggregates, runtime substrate, projection substrate, schema/backfill runners, degradation execution, verification, and simulator backplanes
- tasks `103-120`: token foundation, UI contract kernel, shell laws, accessibility contract, route guards, selected-anchor law, automation vocabulary, and audience-shell foundations
- tasks `121-145`: Phase 1 freeze contracts, urgent-rulebook/copy, parallel-intake gate, draft/autosave backend, request-type taxonomy/question tables, attachment contracts, and submission-envelope validation
- tasks `146-154`: attachment pipeline, contact-preference backend, immutable submit promotion, normalization, synchronous safety, urgent/receipt grammar, ETA/status truth, notification dispatch, and promoted-draft supersession
- task `155`: the canonical patient intake mission frame shell that every task in this batch must inherit rather than replace

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim/sequence discipline
- `prompt/checklist.md` for canonical task ordering and gate discipline
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for this repo

Authoritative source order:
1. `phase-1-the-red-flag-gate.md`, especially:
   - `## 1A. Journey contract and intake schema lock`
   - `## 1B. Draft lifecycle and autosave engine`
   - `## 1C. World-class intake frame and structured capture`
   - `## 1D. Attachment ingestion pipeline`
   - `## 1E. Submit normalization and synchronous safety engine`
   - `## 1F. Triage handoff, receipt, ETA, and minimal status tracking`
2. `phase-0-the-foundation-protocol.md`, especially:
   - `SubmissionEnvelope`
   - `DraftSaveSettlement`
   - `DraftMergePlan`
   - `DraftRecoveryRecord`
   - `DraftContinuityEvidenceProjection`
   - `UrgentDiversionSettlement`
   - `ContactRouteSnapshot`
   - `PatientReceiptEnvelope`
   - `PatientReceiptConsistencyEnvelope`
   - `PatientNavReturnContract`
   - `RecoveryContinuationToken`
   - `PatientActionRecoveryEnvelope`
   - `PatientShellConsistencyProjection`
   - `PatientEmbeddedSessionProjection`
   - `PatientDegradedModeProjection`
3. `platform-frontend-blueprint.md`, especially:
   - `PersistentShell`
   - `StatusStripAuthority`
   - `SelectedAnchor`
   - `Status suppression algorithm`
   - `Patient macro-state mapping`
   - `Submission to receipt morph algorithm`
   - `Claim, secure-link, and embedded access algorithm`
   - `Verification and Playwright contract`
4. `patient-portal-experience-architecture-blueprint.md` and `patient-account-and-communications-blueprint.md` for patient-shell continuity, utility hierarchy, contact-route truth, action-recovery, identity-hold, and route-return behavior
5. `phase-cards.md` for the Phase 1 patient-experience scope, required tests, and product posture
6. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `accessibility-and-content-system-contract.md`, and `uiux-skill.md` for exact token, spacing, motion, content, accessibility, and calmness rules
7. outputs from tasks `139-155`, especially:
   - `139` public intake route/schema contract
   - `140` request-type taxonomy and question-definition tables
   - `141` attachment acceptance/quarantine contracts
   - `142` urgent-diversion rulebook and copy
   - `144` draft/autosave backend contract
   - `145` submit-readiness and validation truth
   - `147` contact-preference capture and masking boundary
   - `151` outcome grammar
   - `152` ETA and minimal patient status truth
   - `153` confirmation/communication dispatch semantics
   - `154` post-promotion supersession and resume blocking
   - `155` patient intake mission frame shell
8. `forensic-audit-findings.md` as mandatory patch law, especially Findings `11`, `12`, `25`, `61`, `62`, `86`, `87`, `88`, `89`, `97`, `99`, `101`, `105`, `116`, `117`, `118`, and `120`

Non-negotiable interpretation rules:
- Task `155` is the canonical intake shell. No task in this batch may fork a second wizard shell, second confirmation shell, second dashboard shell, or detached generic error page for the same lineage.
- Request-type selection and question progression must be driven from the pinned `IntakeExperienceBundle` plus question-definition metadata. Do not hard-code semantic meaning into route-local JSX/HTML copy.
- The patient experience remains one question or one decision frame at a time. Start with essential questions, keep helper text bounded, reveal dependent inputs in place, and never collapse two semantically distinct questions into one “double-barrelled” control just to save space.
- Autosave truth maps to `DraftSaveSettlement` plus `DraftContinuityEvidenceProjection`, not raw fetch timing. `saving`, `saved`, `review changes`, and `resume safely` must remain distinct from each other.
- File upload is supportive evidence, not the dominant narrative. Upload states must reflect the quarantine-first pipeline and may never expose raw object-store URLs or imply that unscanned evidence is already safe.
- Contact preference, route existence, route verification, reachability risk, delivery acceptance, delivery evidence, and authoritative outcome are distinct truths. Never flatten them into one reassuring sentence.
- `urgent_diversion_required` and `urgent_diverted` are separate durable states. The patient surface must never imply issued urgent advice before `UrgentDiversionSettlement(settlementState = issued)` exists.
- The receipt surface and the track-my-request surface must render the same `PatientReceiptConsistencyEnvelope` and macro-state truth. No channel, page, or shell in this batch may invent a different ETA or status meaning.
- Sign-in uplift, refresh, secure-link re-entry, embedded drift, claim-pending, and stale-token return must preserve the same shell and selected anchor where policy allows. When policy does not allow writable continuation, the shell must morph to bounded recovery or read-only posture rather than redirecting to a generic start/continue page.
- One shell-level status owner only. Shell-wide save/sync/freshness/recovery cues belong to the quiet status strip and nowhere else. Control-level problems stay local.
- Any chart, diagram, or visual summary must have adjacent table/list parity and deterministic automation hooks.
- Every browser-viewable artifact in this batch must use `Playwright_or_other_appropriate_tooling` from the start, expose deterministic `data-testid` markers, support full keyboard operation, honor reduced motion, and surface explicit DOM markers for shell continuity, writable state, route family, anchor state, and surface posture.

Frontend and experience quality law for this batch:
- visual language: `Quiet_Clarity_Intake`
- tone: premium, calm, exact, clinically responsible, plain-language, and continuity-aware
- avoid: generic steppers, commodity SaaS cards, toast storms, stacked banners, noisy progress bars, celebratory success pages, dashboard-style patient status pages, and decorative charts
- where the blueprint leaves micro-behavior or copy posture under-specified, prefer the same public-service interaction patterns the algorithm points toward:
  - one question per step
  - essential-first ordering
  - bounded conditional reveal
  - one check/review surface before confirmation
  - confirmation that says what happened and what happens next
  - plain language and short messages
  - WCAG 2.2-safe focus, targets, redundant-entry handling, and unobscured controls
- if a temporary bootstrap token seed is needed before canonical token compilation, use:
  - canvas `#F7F8FA`
  - shell `#EEF2F6`
  - panel `#FFFFFF`
  - inset `#E8EEF3`
  - text strong `#0F1720`
  - text default `#24313D`
  - text muted `#5E6B78`
  - border subtle `#D8E0E8`
  - accent live `#2F6FED`
  - accent safe `#117A55`
  - accent pending `#B7791F`
  - accent blocked `#B42318`
  - accent continuity `#5B61F6`
- typography must resolve through the token foundation first; if a bootstrap stack is required, preserve:
  - display `40/48`
  - headline `32/40`
  - title `24/32`
  - section `20/28`
  - body `16/24`
  - body.sm `14/20`
  - label `12/16`

Mandatory batch-wide gap closures:
- close the “patient shell continuity is optional” gap by keeping all recoverable states in one governed shell
- close the “quiet saved state can come from local calmness” gap by binding visible saved state to settlement plus continuity evidence
- close the “urgent, receipt, and failed-safe states are just generic outcomes” gap by preserving distinct same-shell grammar and action hierarchy
- close the “receipt, status, and communication can each invent their own truth” gap by rendering one authoritative consistency envelope
- close the “recovery is fragmented across route types” gap by using one bounded degraded/recovery family with last-safe summary and next-safe action
- close the “live announcements can repeat or blur provisional meaning” gap by deduplicating assistive messaging and separating local acknowledgement from authoritative outcome
- close the “visuals can carry unique meaning” gap by providing textual and table parity for every visual summary or diagram
- close the “design tokens drift from code” gap by enforcing tokenized implementation rather than route-local constants once canonical tokens are available

Definition of done for the batch:
- the Phase 1 web intake journey behaves like one premium same-shell patient product from start through post-submit tracking
- every major patient-visible state is source-traceable to the canonical algorithm and machine-readable contracts already frozen in the repo
- recovery, urgent diversion, receipt, tracking, sign-in uplift, and refresh/resume are calm, bounded, accessible, and Playwright-verifiable
```
