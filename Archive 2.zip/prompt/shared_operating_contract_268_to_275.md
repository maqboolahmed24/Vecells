# Shared Operating Contract For Prompts 268 To 275

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `260` to `267`.

This batch closes the Phase 3 workspace loop in three linked passes:

1. accessibility, ergonomics, and governed telemetry hardening across the workspace and support surfaces
2. merge integration across queue, callback, self-care/admin consequence, patient conversation, and staff actions
3. regulated-grade test and assurance suites for queue governance, decisioning, communication integrity, and consequence reopen behavior

This batch mixes frontend hardening, cross-surface integration, and formal test execution.
Do not treat it as a fresh design batch.
The surface families already exist; the work here is to harden, join, validate, and prove them.

The tasks covered here are:

- `par_268_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_accessibility_and_ergonomic_refinements_for_clinical_workspace`
- `par_269_phase3_track_Playwright_or_other_appropriate_tooling_frontend_build_metrics_and_validation_hooks_for_workspace_and_support_flows`
- `seq_270_phase3_merge_integrate_triage_queue_callback_and_self_care_admin_resolution_services`
- `seq_271_phase3_merge_Playwright_or_other_appropriate_tooling_integrate_patient_portal_more_info_and_thread_surfaces_with_workspace_actions`
- `seq_272_phase3_Playwright_or_other_appropriate_tooling_testing_run_queue_fairness_duplicate_clustering_and_stale_owner_recovery_suites`
- `seq_273_phase3_Playwright_or_other_appropriate_tooling_testing_run_more_info_resafety_endpoint_decision_and_approval_suites`
- `seq_274_phase3_Playwright_or_other_appropriate_tooling_testing_run_callback_message_delivery_and_reachability_repair_suites`
- `seq_275_phase3_Playwright_or_other_appropriate_tooling_testing_run_self_care_admin_resolution_and_reopen_regression_suites`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `267` as the intended completed foundation for this batch.

That foundation includes at minimum:

- Phase 0 shell, route-intent, command-settlement, continuity, publication, trust, visibility, audit, and recovery law
- Phase 1 intake, safety, duplicate, notification, and patient recovery foundations
- Phase 2 identity, portal, telephony, conversation, support, and cross-channel continuity work
- cross-cutting patient-account and support surfaces from `210` to `225`
- Phase 3 backend kernels `231` to `254`
- Phase 3 frontend and support surfaces `255` to `267`, especially:
  - `255` workspace shell and route-family ownership
  - `256` queue workboard and anchor preservation
  - `257` active task shell, `CasePulse`, and `DecisionDock`
  - `258` rapid-entry, more-info, and endpoint-reasoning layers
  - `259` attachment and patient-response surfaces
  - `260` approvals and escalations
  - `261` changed-since-seen and resumed-review recovery
  - `262` focus protection, buffered queue change, and next-task posture
  - `263` callback operational views
  - `264` clinician-message thread and repair views
  - `265` self-care and bounded admin consequence views
  - `266` patient conversation route family
  - `267` support replay and linked-context investigation views

### If any upstream implementation is missing, empty, or contradictory

Do not block on archive mismatch.

Use this fallback order:

1. local algorithm files under `blueprint/`
2. coherent repository code already implementing the same contract
3. the expected outputs implied by prompts `233` to `267`

When an upstream artifact is logically required but physically absent, publish the smallest correct seam or reconstruction note in a machine-readable file named:

- `PHASE3_BATCH_268_275_INTERFACE_GAP_<AREA>.json`

Every such artifact must include:

- `taskId`
- `missingSurface`
- `expectedOwnerTask`
- `temporaryFallback`
- `riskIfUnresolved`
- `followUpAction`

Do not weaken fairness, decision fencing, continuity, accessibility, replay restore, communication truth, or reopen law just because an upstream file is missing.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may improve accessibility technique, telemetry hygiene, UI test structure, and concurrency-test discipline, but they must never override the local model.

Use this priority order:

1. `blueprint/phase-3-the-human-checkpoint.md`
2. `blueprint/staff-workspace-interface-architecture.md`
3. `blueprint/callback-and-clinician-messaging-loop.md`
4. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
5. `blueprint/patient-account-and-communications-blueprint.md`
6. `blueprint/patient-portal-experience-architecture-blueprint.md`
7. `blueprint/staff-operations-and-support-blueprint.md`
8. `blueprint/platform-frontend-blueprint.md`
9. `blueprint/canonical-ui-contract-kernel.md`
10. `blueprint/design-token-foundation.md`
11. `blueprint/phase-0-the-foundation-protocol.md`
12. `blueprint/platform-runtime-and-release-blueprint.md`
13. `blueprint/phase-9-the-assurance-ledger.md`
14. validated prompt outputs from `220` to `267` when physically present and internally coherent

## 3. Batch dependency map

### 3.1 `268` owns accessibility and ergonomic hardening for the clinical workspace

Task `268` owns:

- `AccessibleSurfaceContract`
- `KeyboardInteractionContract`
- `FocusTransitionContract`
- `AssistiveAnnouncementContract`
- `FreshnessAccessibilityContract`
- `AssistiveTextPolicy`
- `AccessibilitySemanticCoverageProfile`
- workspace-wide semantic, focus, zoom, reduced-motion, and ergonomic refinement

Task `268` hardens all Phase 3 workspace surfaces from `255` to `267`.
It may refine structure and interaction, but it may not rewrite route ownership or consequence truth.

### 3.2 `269` owns frontend observability, validation hooks, and PHI-safe internal inspection

Task `269` owns:

- `UIEventEnvelope`
- `UITransitionSettlementRecord`
- `UITelemetryDisclosureFence`
- governed event catalogs for workspace and support flows
- internal validation surfaces for clinical beta and support quality
- machine-readable contract manifests, event bundles, and drift inspection outputs

Task `269` must preserve the distinction between local acknowledgement, authoritative settlement, publication posture, recovery posture, and redaction posture.

### 3.3 `270` owns the merge of queue, callback, and self-care/admin execution surfaces

Task `270` owns:

- queue-to-callback launch integration
- queue-to-self-care launch integration
- queue-to-admin-resolution launch integration
- same-shell stage continuity across those consequence paths
- orchestration-layer joins between queue truth, route truth, and consequence truth
- settlement chaining and next-task gating for this merged surface family

Task `270` is integration work.
It may fix wiring gaps, but it must not invent new endpoint families or widen Phase 3 into booking or pharmacy scope.

### 3.4 `271` owns the merge between staff actions and patient conversation surfaces

Task `271` owns:

- the last-mile route and projection wiring between staff more-info, callback, and message actions and patient-facing surfaces
- same-lineage continuity across staff shell and patient shell
- secure-link and signed-in parity for more-info and communication journeys
- patient reply, staff resume, repair, supersession, and recovery parity

Task `271` must not create a detached message-center product or redesign the patient shell IA.

### 3.5 `272` owns queue-governance assurance for fairness, duplicate, and stale-owner behavior

Task `272` owns:

- deterministic queue replay proof
- fairness-floor and overload-behavior proof
- duplicate clustering, duplicate review, and duplicate supersession suites
- claim, release, stale-owner recovery, supervisor takeover, and next-task continuity suites
- machine-readable queue-governance assurance output

Task `272` must run real repository suites and either fix repository-owned defects or honestly gate them.

### 3.6 `273` owns decision-cycle assurance for more-info, re-safety, endpoint decision, and approval

Task `273` owns:

- more-info checkpoint, reminder, reply, and supersession suites
- material-delta and re-safety suites
- `DecisionEpoch` and `EndpointDecisionBinding` fence validation
- approval and urgent-escalation bypass-prevention suites
- machine-readable decision-cycle assurance output

Task `273` must prove that approval, preview, and submit stay bound to the current authority chain.

### 3.7 `274` owns communication-integrity assurance for callback, messaging, and repair

Task `274` owns:

- callback scheduling, attempts, outcomes, and callback-window truth suites
- clinician-message dispatch, delivery evidence, dispute, and repair suites
- reachability repair, bounce handling, resend, channel change, and attachment recovery suites
- parity assertions across patient, staff, and support communication posture
- machine-readable communication-integrity assurance output

Task `274` must preserve the rule that provider transport success is not the same thing as authoritative communication outcome.

### 3.8 `275` owns self-care/admin consequence and reopen regression assurance

Task `275` owns:

- self-care versus bounded admin boundary suites
- advice render, content approval, dependency gate, waiting, and completion-artifact suites
- reopen suites for new symptoms, material evidence, invalidated advice, repair blockers, and dependency drift
- parity assertions across patient, staff, and support consequence summaries
- machine-readable consequence-family assurance output

Task `275` must prove that reopened consequence paths are not prematurely calmed or relabeled.

## 4. Mandatory interpretation laws for this batch

### 4.1 Accessibility is a product contract, not a polishing layer

Semantic structure, keyboard traversal, focus recovery, zoom resilience, reduced-motion behavior, and assistive announcements must be first-class and durable.
Do not patch accessibility with route-local ARIA improvisation or one-off fixes that drift from the shell contract.

### 4.2 Telemetry must preserve authority boundaries

Instrumentation may observe local input, local acknowledgement, and authoritative settlement, but it must never blur them together.
UI metrics must remain PHI-safe, redaction-aware, and explicit about what was local versus canonical.

### 4.3 Merge tasks may join surfaces, not redefine truth

`270` and `271` are integration tasks.
They may connect queue, callback, self-care, admin, patient conversation, and support flows, but they may not rewrite canonical object ownership or invent new state machines.

### 4.4 Same-lineage continuity remains mandatory

Staff queue actions, callback or message work, self-care/admin consequence, patient more-info and communication surfaces, and support replay must all preserve one request lineage and one current authority chain.
Do not fork detached journeys or hide return context.

### 4.5 `DecisionEpoch`, approval gates, callback/message truth, and dependency gates remain authoritative

UI calmness, enabled actions, merge transitions, and visible summaries must freeze when the live canonical fence, delivery truth, or dependency truth drifts.
No stale, replayed, or optimistic client state may bypass those guards.

### 4.6 Testing tasks are executable assurance, not narrative review

Tasks `272` to `275` must run real repository suites, produce machine-readable evidence, and fix repository-owned defects where appropriate.
If a defect cannot be fixed within task scope, it must remain explicit as a gating failure.

### 4.7 Machine-readable proof is required

Every assurance family in this batch must emit deterministic, repository-owned outputs.
Do not leave proof as screenshots, ad hoc notes, or terminal-only logs.

## 5. Shared engineering and proof requirements

### 5.1 Playwright is mandatory across this batch

Every task in this batch must use Playwright as the primary browser proof harness.
Another browser tool may supplement it, but it may not replace Playwright as the main proof surface.

### 5.2 Stable selectors and landmarks are required

Shell regions, queue rows, changed-work surfaces, callback and message timelines, approval and escalation stages, patient conversation routes, support replay regions, and internal validation surfaces must expose deterministic selectors and stable DOM structure.

### 5.3 Accessibility and telemetry hardening must be regression-tested

Keyboard flows, focus return, announcement behavior, reduced-motion posture, zoom/reflow layouts, and redaction-aware telemetry paths must all be covered by repeatable suites.

### 5.4 Internal validation surfaces are support-grade, not public product surfaces

Any inspection UI added by `269` must be PHI-safe, role-bounded, and explicit about disclosure fences.
It must not become a substitute for canonical audit or operational truth.

### 5.5 Assurance artifacts must be deterministic and check-in friendly

Prefer repository-owned JSON, CSV, markdown, screenshots, and traces with stable naming and deterministic ordering.
Re-running the same suite should update evidence cleanly rather than scramble filenames or identifiers.

### 5.6 Sequential execution law applies strictly to `270` to `275`

Tasks `268` and `269` are parallel hardening tasks.
Once `270` begins, no later sequential task in this batch may be claimed until the current one is complete.
Testing tasks `272` to `275` must execute in order because each consumes the integrated surface and proof outputs from the prior step.
