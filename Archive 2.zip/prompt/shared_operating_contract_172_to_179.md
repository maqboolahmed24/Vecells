# Shared Operating Contract For Prompts 172 To 179

```text
You are an autonomous coding agent operating on the Vecells repository. Treat the blueprint corpus under `blueprint/`, the coordination protocol under `prompt/AGENT.md` and `prompt/checklist.md`, the validated outputs from tasks `001-171`, and the already-populated prompt files in this repository as the definitive source algorithm plus execution serialization.

This batch has three responsibilities:
1. finish the Phase 2 contract-freeze layer for patient linkage and telephony readiness so later implementation cannot improvise local identity or phone-channel semantics;
2. open the large Phase 2 parallel block with explicit dependency edges, seam ownership, and fail-closed rules; and
3. implement the first identity-engine tranche (`175-179`) on top of the frozen trust, auth, and patient-link contracts without waiting for later capability, claim, repair, portal, or telephony tasks.

Tasks in this batch:
- `172`: freeze patient linkage, calibrated match confidence, and the optional PDS enrichment seam
- `173`: freeze telephony call-session, recording, transcript-readiness, evidence-readiness, and bounded continuation contracts
- `174`: open the Phase 2 parallel identity and telephony implementation tracks
- `175`: build the auth bridge service with OIDC transaction tracking
- `176`: build the session governor for session establishment, rotation, timeout, and logout
- `177`: build the identity evidence vault for raw auth claims and telephony identifiers
- `178`: build the patient linker and match-confidence pipeline
- `179`: build the append-only `IdentityBindingAuthority` decision engine

Before executing any task in this batch, verify that outputs from tasks `001-171` exist, remain internally coherent, and still bind to the canonical blueprint corpus. If a prerequisite artifact is missing, stale, contradictory, or no longer source-traceable, fail fast with bounded `PREREQUISITE_GAP_*` records. Do not silently repair the dependency chain with local invention.

At minimum, require these upstream outputs to remain usable:
- tasks `001-138`: Phase 0 scope, traceability, runtime/publication tuples, domain kernel, replay law, access-grant law, route-intent law, design-token law, accessibility law, release/freeze law, and the Phase 0 exit pack
- tasks `139-169`: Phase 1 intake/public-schema freeze, request taxonomy, attachment/quarantine rules, urgent-diversion law, autosave/promotion/safety/receipt/tracking/notification substrate, frontend continuity shell, full Phase 1 verification, and the Phase 1 exit-gate pack
- tasks `170-171`: the Phase 2 trust kernel, capability matrix, route-profile registry, identity-authority rules, NHS login auth-transaction contracts, post-auth return contracts, and local-session contract pack

You must also treat these repository files as live coordination inputs where relevant:
- `prompt/AGENT.md` for claim/sequence discipline
- `prompt/checklist.md` for canonical task ordering and gate discipline
- earlier populated `prompt/*.md` files as the implementation-spec layer already chosen for this repo

Authoritative source order:
1. `phase-2-identity-and-echoes.md`, especially:
   - `## 2A. Trust contract and capability gates`
   - `## 2B. NHS login bridge and local session engine`
   - `## 2C. Patient linkage, demographic confidence, and optional PDS enrichment`
   - `## 2E. Telephony edge, IVR choreography, and call-session persistence`
   - `## 2F. Caller verification, voice capture, transcript stub, and SMS continuation`
2. `phase-0-the-foundation-protocol.md`, especially:
   - `IdentityBinding`
   - `PatientLink`
   - `CapabilityDecision`
   - `AuthTransaction`
   - `AuthScopeBundle`
   - `PostAuthReturnIntent`
   - `Session`
   - `SessionEstablishmentDecision`
   - `SessionTerminationSettlement`
   - `IdentityRepairSignal`
   - `TelephonyTranscriptReadinessRecord`
   - `TelephonyEvidenceReadinessAssessment`
   - `TelephonyContinuationEligibility`
   - `AccessGrant`, `AccessGrantScopeEnvelope`, `AccessGrantRedemptionRecord`, and `AccessGrantSupersessionRecord`
   - the canonical lifecycle, identity, grant, duplicate, replay, and telephony convergence algorithms
3. `phase-cards.md`, especially Card 3 Phase 2 scope, algorithm, and mandatory tests
4. outputs from tasks `169-171`, especially:
   - `170_route_capability_profiles.yaml`
   - `170_identity_authority_rules.json`
   - `170_patient_link_boundary_contract.json`
   - `170_identity_context.schema.json`
   - `170_identity_evidence_envelope.schema.json`
   - `171_auth_transaction.schema.json`
   - `171_auth_scope_bundle.schema.json`
   - `171_post_auth_return_intent.schema.json`
   - `171_session_establishment_decision.schema.json`
   - `171_session_termination_settlement.schema.json`
   - `171_session_projection_contract.json`
5. `platform-frontend-blueprint.md`, `patient-portal-experience-architecture-blueprint.md`, and `patient-account-and-communications-blueprint.md` for same-shell continuity, route-intent/recovery law, degraded-mode authority, selected-anchor preservation, secure-link/auth-return posture, patient linking states, and bounded recovery semantics
6. `platform-runtime-and-release-blueprint.md` for runtime-publication bundles, release parity, route freeze, and fail-closed writable posture
7. `design-token-foundation.md`, `canonical-ui-contract-kernel.md`, `ux-quiet-clarity-redesign.md`, `accessibility-and-content-system-contract.md`, and `uiux-skill.md` for any board/atlas surfaces required by `172-174`
8. `forensic-audit-findings.md` as mandatory patch law, especially Findings `06`, `07`, `08`, `09`, `50`, `53`, `55`, `59`, `64`, `85`, `86`, `87`, `88`, `89`, `97`, `101`, `105`, `116`, `118`, and `120`
9. `blueprint-init.md` and `vecells-complete-end-to-end-flow.md` / `.mmd` as top-level references that must not override higher-authority files

Non-authoritative but required external references for refinement only:
- NHS login developer guidance for the OIDC authorisation-code flow, scopes and claims, multiple redirect URIs, session-management responsibilities, and testing with the mock authorisation service
- NHS England API catalogue and PDS access guidance for the PDS FHIR API, legal-basis expectations, and digital onboarding posture
- RFC 9700 (OAuth 2.0 Security Best Current Practice) for redirect validation, replay resistance, and exact callback handling
- OWASP guidance for authentication, session management, authorization, logging, cryptographic storage, key management, and secure transport
- Playwright documentation for any interactive HTML gate board or contract atlas created in `172-174`
These references refine UX, testing, and security posture. They never override the Vecells source algorithm.

Non-negotiable interpretation rules:
- Authentication, patient linkage, ownership claim, capability, session, and public/continuation grant scope are distinct authorities. No task in this batch may collapse them into one local “verified user” shortcut.
- `IdentityBindingAuthority` is the only component allowed to create, supersede, correct, or revoke `IdentityBinding` versions. Auth bridge, patient linker, telephony, support, imports, and projections may submit evidence or intents; they may not write binding truth directly.
- `Request.patientRef` and `Episode.patientRef` remain derived from the current authority-settled binding version. No controller, projection, or background worker may mutate them independently.
- `PatientLink` is derived from `IdentityBinding`; it is not a rival authority.
- Unknown route profiles, stale binding fences, stale session epochs, stale grant envelopes, stale manifest or channel posture, missing calibrator versions, or unclassified protected routes must fail closed.
- NHS login scopes must remain frozen in `AuthScopeBundle`; claims are not automatically provided and any extra claim access must be explicit and approved. Scope widening after authorize is forbidden.
- NHS login session management and logout remain partner responsibilities. Session handling stays local to Vecells and may not be delegated back to the identity provider.
- For standalone web posture, the batch must preserve the NHS login session-management baseline of re-authentication after 30 minutes of inactivity and 12 hours of continuous usage unless a stricter local policy is already frozen upstream.
- The optional PDS seam must be feature-flagged, onboarding-aware, and legal-basis-aware. Local matching must still function when PDS is disabled or unavailable. PDS is an enrichment seam, not the only matching path.
- `contactClaims`, `pdsDemographics`, and `patientPreferredComms` are separate domains. Auth or PDS claims may inform matching or recovery, but they may not silently overwrite patient communication preferences.
- GP linkage-key or IM1-derived behavior must stay disabled unless the required live onboarding and connection posture exists. The batch may freeze the seam; it may not invent a fake always-on GP-link shortcut.
- `TelephonyEvidenceReadinessAssessment` is the sole telephony authority allowed to declare `awaiting_*`, `urgent_live_only`, `safety_usable`, `manual_review_only`, or `unusable_terminal` posture.
- Telephony may recommend seeded or challenge continuation only through `TelephonyContinuationEligibility` derived from the latest readiness verdict. `manual_only` is a routing disposition and issues no redeemable grant.
- Caller ID is only a weak narrowing signal. It is never sufficient on its own for patient identity or for seeded SMS continuation.
- Telephony may not enter routine promotion while readiness is only `awaiting_recording`, `awaiting_transcript`, `awaiting_structured_capture`, `urgent_live_only`, `manual_review_only`, or `unusable_terminal`.
- Raw claims, phone numbers, caller identifiers, handset proofs, and similar evidence must never leak into logs, metrics labels, DOM attributes, URLs, screenshots, or general operational rows.
- Any board, atlas, or diagram produced by `172-174` must include adjacent table/list parity and must fail closed to tabular truth when parity drifts.

Parallel file-ownership and seam rules for tasks `175-179`:
- `175` owns the dedicated `auth-bridge` boundary: authorize/callback endpoints, transaction persistence, provider discovery, token exchange and validation, callback-settlement logic, and the write ports into the evidence vault, session governor, and identity-binding authority.
- `176` owns `SessionGovernor`: session-establishment decision logic, session issuance/rotation/reuse/termination, timeout and re-auth policy, cookie and CSRF lifecycle, and session projection.
- `177` owns the identity-evidence vault: encrypted append-only raw evidence storage, masking/redaction helpers, lookup references, access audit, key-version handling, and retention classes.
- `178` owns `PatientLinker`: candidate search, feature extraction, calibration, confidence intervals, drift detection, threshold policy loading, and the optional PDS provider seam.
- `179` owns `IdentityBindingAuthority`: append-only binding version creation, compare-and-set of the current binding pointer, derived patient-reference advancement, and freeze-aware refusal logic.
- Shared contracts should live in one obvious shared package or folder, for example `packages/contracts/identity/` or the equivalent existing repository location. Do not duplicate the same schema in five task-owned folders.
- If a sibling task is not yet present, publish the smallest correct shared port or interface and record `PARALLEL_INTERFACE_GAP_*`. Do not clone the sibling’s domain logic locally.

Backend quality law for this batch:
- explicit domain/application/infrastructure separation
- append-only authoritative records instead of mutable status shortcuts
- compare-and-set or fence-checked mutation wherever lineage or grant/session integrity matters
- deterministic idempotency for callbacks, grant redemption, binding intents, and derived patient-reference updates
- encrypted-at-rest evidence storage with key-version awareness and strict masking in logs and telemetry
- external I/O behind simulator-replaceable interfaces
- machine-readable reason codes for stale, blocked, degraded, replayed, denied, review-only, and recovery-only states
- fail closed on missing calibration, missing provider trust, missing legal basis, stale publication, stale trust, or stale continuity evidence

Frontend and board-surface quality law for this batch:
- any board or atlas must feel premium, exact, calm, and policy-native rather than like a generic admin screen
- preserve the repository’s `Quiet_Clarity` language: one dominant story, strong hierarchy, generous whitespace, bounded color accents
- keyboard complete, reduced-motion correct, and parity-safe with tabular fallback
- no decorative charts that add meaning absent from the machine-readable tables

Gap handling:
- If a prerequisite artifact is missing or contradictory, emit `PREREQUISITE_GAP_*` and stop the affected task.
- If the source algorithm leaves a linkage, telephony, or parallel-seam contract under-specified, resolve it now as a bounded, source-traceable contract family and record `GAP_RESOLVED_*`.
- If probability thresholds, confidence intervals, or readiness budgets are not explicit enough to serialize, derive the smallest defensible bounded set, keep them versioned and machine-readable, and record `GAP_RESOLVED_*_THRESHOLD_*`.
- Keep `Mock_now_execution` and `Actual_production_strategy_later` separate. Mock-now means real product behavior backed by contract-faithful simulators. Actual-production strategy means later live auth, live PDS, telephony vendor, SMS provider, or staff-tool hardening that preserves the same public semantics.

Output discipline:
- Create or update real repository artifacts, validators, tests, and any required HTML evidence surfaces. Do not leave critical behavior as TODO prose.
- Every task must publish machine-readable outputs that later gates and sibling tracks can consume directly.
- Any browser-visible artifact must read from the same machine-readable truth that the tests and validators assert.
- For parallel tasks `175-179`, write explicit README or architecture notes for integration points so later tasks `180-194` can extend them without re-litigating the core contract.
```
