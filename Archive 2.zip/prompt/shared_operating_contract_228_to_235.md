# Shared Operating Contract For Prompts 228 To 235

Read this file before executing any prompt in this batch.

These prompts continue the established roadmap immediately after prompts `220` to `227`.
This batch has three linked jobs:

1. finish the remaining Phase 3 contract freezes for endpoint consequence, approval, escalation, callback, clinician messaging, self-care, and admin-resolution boundaries
2. open the real parallel implementation gate for the Phase 3 human-checkpoint program
3. deliver the first concrete backend implementation wave for triage state, workspace trust, deterministic queueing, duplicate review, and review-bundle assembly

The tasks covered here are:

- `seq_228_phase3_freeze_endpoint_decision_approval_and_escalation_contracts`
- `seq_229_phase3_freeze_callback_clinician_messaging_and_admin_resolution_boundaries`
- `seq_230_phase3_open_parallel_triage_callback_and_resolution_tracks_gate`
- `par_231_phase3_track_backend_build_triage_task_state_machine_and_lease_fencing`
- `par_232_phase3_track_backend_build_workspace_consistency_projection_and_workspace_trust_envelope`
- `par_233_phase3_track_backend_build_deterministic_queue_engine_queue_rank_snapshots_and_assignment_suggestions`
- `par_234_phase3_track_backend_build_duplicate_pair_evidence_duplicate_review_snapshot_and_resolution_decisions`
- `par_235_phase3_track_backend_build_review_bundle_assembler_deterministic_summaries_and_suggestion_seam`

## 1. Guaranteed upstream inputs

Treat outputs from tasks `001` to `227` as the guaranteed completed foundation for this batch.

You must assume the following earlier work is authoritative and available:

- the Phase 0 lifecycle, duplicate, idempotency, route-intent, command-settlement, access-grant, release, and recovery kernel
- the Phase 1 intake, safety, notification, and continuity work from `140` to `169`
- the Phase 2 trust, session, identity, telephony, portal, patient-account, support, and cross-cutting work from `170` to `225`
- the first Phase 3 freeze packs from `226` and `227`

The work splits into three internal waves:

### Consequence-freeze wave

- endpoint, approval, and escalation freeze pack: `228`
- callback, clinician-message, self-care, and admin-resolution freeze pack: `229`

### Parallelization gate wave

- cross-contract reconciliation and track-launch gate: `230`

### First backend implementation wave

- triage state machine and lease fencing: `231`
- workspace consistency and trust envelope: `232`
- deterministic queue engine and assignment suggestions: `233`
- duplicate review authority and resolution decisions: `234`
- review-bundle assembly and deterministic summaries: `235`

Do not assume later Phase 3 outputs from `236+` already exist.
Those later tasks are downstream consumers of the contract packs and backend kernels you publish here.

If a sibling or future-track output is absent, stale, contradictory, or underspecified, do not block.
Publish the smallest correct seam, adapter, placeholder contract, or compatibility note in a machine-readable artifact named:

- `PARALLEL_INTERFACE_GAP_PHASE3_<AREA>.json`

Every such artifact must include:
`taskId`, `missingSurface`, `expectedOwnerTask`, `temporaryFallback`, `riskIfUnresolved`, `followUpAction`.

## 2. Source-of-truth order

The local algorithm is the definitive source of truth.
External references may refine implementation quality, security posture, browser-proof technique, accessibility, and operational UI composition patterns, but they must never override the local model.

Use this priority order:

1. `blueprint/phase-3-the-human-checkpoint.md`
2. `blueprint/callback-and-clinician-messaging-loop.md`
3. `blueprint/self-care-content-and-admin-resolution-blueprint.md`
4. `blueprint/staff-workspace-interface-architecture.md`
5. `blueprint/phase-0-the-foundation-protocol.md`
6. `blueprint/staff-operations-and-support-blueprint.md`
7. `blueprint/patient-account-and-communications-blueprint.md`
8. `blueprint/patient-portal-experience-architecture-blueprint.md`
9. `blueprint/platform-runtime-and-release-blueprint.md`
10. `blueprint/platform-frontend-blueprint.md`
11. `blueprint/accessibility-and-content-system-contract.md`
12. `blueprint/canonical-ui-contract-kernel.md`
13. `blueprint/forensic-audit-findings.md`
14. validated prompt outputs from `170` to `227`
15. validated prompt outputs from `228` to `235` when physically present and internally coherent

## 3. Mandatory interpretation laws for this batch

### 3.1 `DecisionEpoch` is the sole consequence fence

Every consequence-bearing review action in this batch must consume one current unsuperseded `DecisionEpoch` or fail closed.
Endpoint submit, preview generation, approval settlement, urgent escalation, booking intent, pharmacy intent, self-care issue, admin completion, callback creation, and clinician-message consequence may not proceed on stale epoch assumptions.

### 3.2 Consequence domains are peers, not status flags

Triage, approval, urgent escalation, callback, clinician messaging, self-care, admin resolution, booking handoff, pharmacy handoff, and reopen are separate governed domains with their own leases, settlements, and recovery paths.
Do not collapse them into ad hoc booleans on one task row.

### 3.3 `LifecycleCoordinator` remains the only request-closure authority

No local UI state, worker, callback service, message service, admin-resolution flow, or triage shortcut may close the request directly.
Every domain may settle its own work, but only `LifecycleCoordinator` may derive or persist final request closure.

### 3.4 Workspace writability derives from trust plus lease, not from route presence

Staff mutation is legal only while the current `ReviewActionLease`, `WorkspaceFocusProtectionLease` where required, `StaffWorkspaceConsistencyProjection`, `WorkspaceSliceTrustProjection`, and `WorkspaceTrustEnvelope` all remain live and internally consistent.
Route visibility alone never implies mutation authority.

### 3.5 Queue order is canonical and reviewer-fit is downstream only

`QueueRankPlan`, `QueueRankSnapshot`, and `QueueRankEntry` define canonical queue order.
`QueueAssignmentSuggestionSnapshot` and reviewer-fit heuristics may propose an operator, but they may not rewrite canonical row order.

### 3.6 Duplicate authority is inherited from Phase 0

Replay, same-request attach, same-episode linkage, related-episode linkage, and duplicate-review clustering are separate authorities.
`IdempotencyRecord` owns replay, `DuplicateResolutionDecision` owns attach or separation decisions, and `DuplicateCluster` owns explicit review work.
No triage-local shortcut may stand in for any of them.

### 3.7 `MoreInfoReplyWindowCheckpoint` is the sole timer truth

More-info due state, reminders, late-review grace, expiry, and reply eligibility derive only from the checkpoint contract.
Client timers, delivery timestamps, or queue refresh times must not redefine actionable windows.

### 3.8 New evidence preempts consequence

Materially new evidence, patient reply, callback outcome, duplicate supersession, reachability repair, trust drift, or publication drift must route through canonical evidence assimilation, material-delta, and safety/contact-risk checks before routine flow resumes.
Stale approvals and stale outcome previews must remain visible as provenance but not as live consequence.

### 3.9 Freeze tasks are contract-publication tasks

Tasks `228` and `229` must publish machine-readable schemas, registries, state vocabularies, event vocabularies, and bounded atlases.
They are not the place to defer core meaning to prose-only notes.

### 3.10 The gate task is a real gate, not a report

Task `230` must reconcile collisions, assign owners, launch the parallel tracks, and either remediate inconsistencies or fail closed.
Do not soften readiness criteria to make the board look green.

### 3.11 Backend build tasks must ship working repository code

Tasks `231` to `235` are implementation tasks.
They must land production-shaped code, migrations, validators, and tests in the repository.
Architecture prose is required but not sufficient.

### 3.12 Mock-now and actual-later must remain explicit

Repository-runnable proof, simulator-backed proof, and browser-board proof are valid when the task explicitly allows them.
Do not mislabel simulator, fixture, or dry-run evidence as live production evidence.

### 3.13 Security, audit, and clinical-safety posture are mandatory

Across this batch:

- use deny-by-default authorization and mutation gating
- keep append-only audit and supersession chains
- redact logs and telemetry
- keep session and lease takeover explicit
- verify signed or authenticated provider callbacks at the edge
- maintain evidence provenance and replay resistance
- record any clinical-safety-impacting behaviour changes in the project’s risk or hazard evidence so later DCB0129/DCB0160 and go-live assurance work has a clean trace

### 3.14 Playwright is mandatory for interactive browser artifacts

Playwright is mandatory for:

- interactive atlases in `228` and `229`
- the gate board in `230`

Other tooling may supplement Playwright, but it may not replace it as the primary browser-proof mechanism.

## 4. Shared design, content, and accessibility laws for any browser-visible artifact

### 4.1 Browser-visible artifacts in this batch are operational atlases, not dashboards

Any atlas or gate board must feel like a premium, calm, exact control surface.
Use dense but quiet structure, high contrast, clear labels, and restrained motion.
Do not ship neon, speculative “AI copilot” motifs, or decorative analytics.

### 4.2 Diagrams are allowed only with parity surfaces

Allowed diagram classes include:

- endpoint-decision lattices
- epoch and supersession braids
- callback or message lifecycle ladders
- boundary triads
- launch-readiness matrices
- dependency maps

Every diagram must have adjacent table or list parity.
No diagram may carry meaning absent from a machine-readable or screen-reader-safe parity surface.

### 4.3 Browser artifacts must preserve keyboard and reduced-motion discipline

Across interactive artifacts:

- keyboard traversal must be complete
- landmarks and headings must be explicit
- `data-testid` markers must be deterministic
- reduced-motion mode must preserve meaning
- filters must synchronize both diagrams and parity tables

## 5. Batch dependency map

### 5.1 `228` freezes consequence semantics for the review rail

`228` consumes `226` and `227` and establishes the only legal endpoint taxonomy, decision-epoch fence, approval checkpoint rules, urgent-escalation rules, and direct-resolution/handoff seed boundaries for Phase 3.
Later tasks `238`, `239`, and `240` must implement against these contracts rather than redefining them.

### 5.2 `229` freezes callback, message, self-care, and admin-resolution peer domains

`229` consumes `226`, `227`, and `228`.
It must define callback, clinician-message, patient-conversation, self-care, and admin-resolution boundary contracts so later tasks `243` to `254` can implement without semantic drift.

### 5.3 `230` launches the parallel implementation program

`230` reconciles `226` to `229`, opens the implementation gate, and publishes explicit launch packets for `231` to `235` plus readiness rows for the later Phase 3 tracks.
It must expose any remaining seam or missing owner explicitly.

### 5.4 `231` implements triage state and lease law

`231` depends primarily on `226` and `230`, while respecting consequence entry points and supersession hooks frozen by `228`.

### 5.5 `232` implements workspace truth and trust

`232` depends primarily on `226`, `228`, and `230`.
It must convert drift, publication mismatch, trust downgrade, and continuity evidence into one canonical workspace-trust output family.

### 5.6 `233` implements deterministic queueing

`233` depends primarily on `227`, plus claim and lease hooks from `231` and projection-read hooks from `232`.
It must not reopen the queue semantics frozen in `227`.

### 5.7 `234` implements duplicate review authority

`234` depends primarily on Phase 0 duplicate law, `227`, `228`, and `230`.
It must emit the invalidations and supersession effects that later consequence flows consume.

### 5.8 `235` implements review-bundle assembly and suggestion seams

`235` depends primarily on `226`, `227`, `228`, `229`, and `230`.
It must assemble deterministic review bundles and suggestion envelopes that later workspace frontend tasks can render directly.

## 6. Validation and artifact expectations

Every task in this batch must:

1. cite the exact local source sections it is implementing
2. publish machine-readable contracts where the roadmap implies a durable interface
3. record every important assumption as either:
   - authoritative source trace
   - explicit temporary seam artifact
   - explicit risk or gate finding
4. keep browser-visible artifacts and machine-readable parity surfaces semantically aligned
5. fail closed when a required authority, publication tuple, trust slice, lineage fence, or ownership epoch is missing
6. keep production code and analysis artifacts in sync with the frozen vocabularies
7. preserve append-only lineage, supersession, and audit history

## 7. Definition of success for this batch

This batch succeeds only when:

- Phase 3 consequence domains are frozen with machine-readable contracts instead of prose-only intent
- the implementation gate cleanly opens and assigns the first backend wave without unresolved semantic collisions
- the repository contains production-shaped backend kernels for triage state, workspace trust, deterministic queueing, duplicate review, and review-bundle assembly
- later Phase 3 tasks can extend these kernels and contracts rather than re-litigating core meaning
